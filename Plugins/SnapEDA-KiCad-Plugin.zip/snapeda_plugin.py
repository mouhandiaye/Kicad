import sys #line:1
import threading #line:2
import subprocess #line:3
import base64 #line:4
import shutil #line:5
import zipfile #line:6
import webbrowser #line:7
import urllib #line:8
import io #line:9
import json #line:10
import os #line:11
import platform #line:12
import time #line:13
from shutil import copyfile #line:14
import re #line:15
import ctypes #line:16
import random #line:17
import ssl #line:18
if sys .version_info [0 ]==3 :#line:20
    import urllib .parse #line:22
    import urllib .request #line:23
    import tkinter as tk #line:24
    from tkinter import filedialog as fd #line:25
    import tkinter .messagebox as tkMessageBox #line:26
    from io import StringIO as StringIO #line:27
    from tkinter import ttk #line:28
else :#line:30
    import Tkinter as tk #line:32
    import tkFileDialog as fd #line:33
    import tkMessageBox #line:34
    from StringIO import StringIO #line:35
    import ttk #line:36
    import urllib2 #line:37
IS_SETTING_WINDOW_OPEN =False #line:40
IS_GLOBAL =True #line:41
IS_PROJECT =False #line:42
IS_PROMOTED =False #line:43
IS_UPDATED =False #line:44
IS_3D_TAB_OPEN =False #line:45
CONST_DEFAULT_GEOMETRY ="458x721"#line:48
CONST_DEFAULT_WINDOW_WIDTH =458 #line:49
CONST_DEFAULT_GEOMETRY_HEIGHT =721 #line:50
CONST_INSTALL_WINDOW_GEOMETRY ="1150x828"#line:52
CONST_INSTALL_WINDOW_WIDTH =1150 #line:53
CONST_INSTALL_GEOMETRY_HEIGHT =828 #line:54
CONST_LOGIN_GEOMETRY =CONST_DEFAULT_GEOMETRY #line:56
CONST_LOGIN_WINDOW_WIDTH =CONST_DEFAULT_WINDOW_WIDTH #line:57
CONST_LOGIN_GEOMETRY_HEIGHT =CONST_DEFAULT_GEOMETRY_HEIGHT #line:58
class Observer :#line:60
    def __init__ (OOOO0000OO000000O ,initial_value =0 ):#line:61
        OOOO0000OO000000O ._value =initial_value #line:62
        OOOO0000OO000000O ._callbacks =[]#line:63
    @property #line:65
    def value (O0000O0O0O0OO0OO0 ):#line:66
        return O0000O0O0O0OO0OO0 ._value #line:67
    @value .setter #line:69
    def value (OO00OOO0O00O0O0OO ,O000OO00O00OO000O ):#line:70
        OO00000O0O0O00O0O =OO00OOO0O00O0O0OO ._value #line:71
        OO00OOO0O00O0O0OO ._value =O000OO00O00OO000O #line:72
        OO00OOO0O00O0O0OO ._notify_observers (OO00000O0O0O00O0O ,O000OO00O00OO000O )#line:73
    def _notify_observers (OO0000000O0OOOOO0 ,OOOOOO00OOO0OOO0O ,O000OOO00OOOOO0OO ):#line:75
        for O0000OOO00O0000OO in OO0000000O0OOOOO0 ._callbacks :#line:76
            O0000OOO00O0000OO (OOOOOO00OOO0OOO0O ,O000OOO00OOOOO0OO )#line:77
    def register_callback (O0O0O000000000OOO ,OO00OO00O0O0O0O0O ):#line:79
        O0O0O000000000OOO ._callbacks .append (OO00OO00O0O0O0O0O )#line:80
class AfterDownloadView (tk .Frame ):#line:82
    def __init__ (OOO0O00000O0OOOO0 ,O00O0000000OOOO00 ,flip_table_dir =None ,proj_flip_table_dir =None ,snapeda_library_abs_dir =None ,kicad_mod_filename =None ):#line:83
        OOO0O00000O0OOOO0 .flip_table_dir =flip_table_dir #line:84
        OOO0O00000O0OOOO0 .proj_flip_table_dir =proj_flip_table_dir #line:85
        OOO0O00000O0OOOO0 .snapeda_library_abs_dir =snapeda_library_abs_dir #line:86
        OOO0O00000O0OOOO0 .kicad_mod_filename =kicad_mod_filename #line:87
        OOO0O00000O0OOOO0 .is_download_complete =O00O0000000OOOO00 .is_download_complete #line:88
        OOO0O00000O0OOOO0 .is_help_me_window =O00O0000000OOOO00 .is_help_me_window #line:89
        OOO0O00000O0OOOO0 .parent =tk .Toplevel ()#line:90
        O0O0O000O0O00O0O0 =int ((O00O0000000OOOO00 .winfo_screenwidth ()/2 )-(458 /2 ))+(O00O0000000OOOO00 .winfo_x ()/2 )#line:91
        OO00OOOO0OO0OOO00 =int ((O00O0000000OOOO00 .winfo_screenheight ()/2 )-(275 /2 ))+(O00O0000000OOOO00 .winfo_y ()/2 )#line:92
        OOO0O00000O0OOOO0 .parent .geometry ('%dx%d+%d+%d'%(458 ,275 ,O0O0O000O0O00O0O0 ,OO00OOOO0OO0OOO00 ))#line:93
        OOO0O00000O0OOOO0 .parent .grab_set ()#line:94
        global IS_SETTING_WINDOW_OPEN #line:95
        IS_SETTING_WINDOW_OPEN =True #line:96
        OOO0O00000O0OOOO0 .parent .resizable (False ,False )#line:97
        OOO0O00000O0OOOO0 .parent .minsize (width =458 ,height =275 )#line:98
        OOO0O00000O0OOOO0 .is_windows =(os .name =='nt')#line:99
        OOO0O00000O0OOOO0 .dir_path =os .path .dirname (os .path .realpath (__file__ ))#line:100
        if OOO0O00000O0OOOO0 .is_windows :#line:101
            OOO0O00000O0OOOO0 .windata_dir =os .path .join (os .getenv ('HOMEDRIVE'),os .getenv ('HOMEPATH'),"SnapEDA Kicad Plugin")#line:104
            OOO0O00000O0OOOO0 .appdata_dir =os .path .join (OOO0O00000O0OOOO0 .windata_dir ,"App")#line:105
        else :#line:106
            OOO0O00000O0OOOO0 .appdata_dir =os .path .join (OOO0O00000O0OOOO0 .dir_path ,"assets")#line:107
        OOO0O00000O0OOOO0 .powered_image_dir =os .path .join (OOO0O00000O0OOOO0 .appdata_dir ,"orb6glbv.png")#line:109
        OOO0O00000O0OOOO0 .icon_bitmap_dir =os .path .join (OOO0O00000O0OOOO0 .appdata_dir ,"32x32.ico")#line:110
        OOO0O00000O0OOOO0 .info_label_img_dir =os .path .join (OOO0O00000O0OOOO0 .appdata_dir ,'info_button.png')#line:111
        OOO0O00000O0OOOO0 .folder_label_img_dir =os .path .join (OOO0O00000O0OOOO0 .appdata_dir ,'folder_label.png')#line:112
        OOO0O00000O0OOOO0 .save_button_img_dir =os .path .join (OOO0O00000O0OOOO0 .appdata_dir ,'save_button.png')#line:113
        if OOO0O00000O0OOOO0 .is_windows :#line:114
            OOO0O00000O0OOOO0 .parent .iconbitmap (OOO0O00000O0OOOO0 .icon_bitmap_dir )#line:115
        OOO0O00000O0OOOO0 .initialize_user_interface ()#line:116
        OOO0O00000O0OOOO0 .parent .protocol ("WM_DELETE_WINDOW",lambda :OOO0O00000O0OOOO0 .on_closing (O00O0000000OOOO00 ))#line:118
    def on_closing (O0000OO00OOO00000 ,O0000O0OOO0O00OO0 ):#line:120
        O0OOOOO0O00O000O0 =os .path .join (O0000OO00OOO00000 .appdata_dir ,"info.json")#line:122
        with open (O0OOOOO0O00O000O0 )as OO00O0OOOO000OO0O :#line:123
            O00000OOO00O00OO0 =json .load (OO00O0OOOO000OO0O )#line:124
        if O0000OO00OOO00000 .flip_table_dir is not None or O0000OO00OOO00000 .proj_flip_table_dir is not None or O0000OO00OOO00000 .snapeda_library_abs_dir is not None :#line:126
            try :#line:128
                if O00000OOO00O00OO0 ['setting_autoplace_footprint']:#line:129
                    O00OOO0O00OOOO0OO =pcbnew .GetBoard ()#line:130
                    O0O0OO000O000OO0O =pcbnew .FootprintLoad (O0000OO00OOO00000 .snapeda_library_abs_dir ,O0000OO00OOO00000 .kicad_mod_filename )#line:131
                    O00OOO0O00OOOO0OO .Add (O0O0OO000O000OO0O )#line:132
                    wx .CallAfter (pcbnew .Refresh )#line:133
            except :#line:134
                O00OOO0O00OOOO0OO =pcbnew .GetBoard ()#line:135
                O0O0OO000O000OO0O =pcbnew .FootprintLoad (O0000OO00OOO00000 .snapeda_library_abs_dir ,O0000OO00OOO00000 .kicad_mod_filename )#line:136
                O00OOO0O00OOOO0OO .Add (O0O0OO000O000OO0O )#line:137
                wx .CallAfter (pcbnew .Refresh )#line:138
            global IS_GLOBAL #line:141
            global IS_PROJECT #line:142
            if (IS_GLOBAL is False )and (IS_PROJECT is False ):#line:145
                IS_GLOBAL =True #line:146
            if IS_GLOBAL :#line:148
                with open (O0000OO00OOO00000 .flip_table_dir ,"r+")as O0OO00OO00O000O00 :#line:149
                    O000O00O0O0OO0O00 =O0OO00OO00O000O00 .read ()#line:150
                    if ("(lib (name \""+O00000OOO00O00OO0 ['kicad_library_name']+"\")(type KiCad)(uri \""+O0000OO00OOO00000 .snapeda_library_abs_dir +"\")")not in O000O00O0O0OO0O00 :#line:151
                        OOOOO00000000OO0O =('  (lib (name "'+O00000OOO00O00OO0 ['kicad_library_name']+'")(type KiCad)(uri "'+O0000OO00OOO00000 .snapeda_library_abs_dir +'")(options "")(descr ""))')+"\n\n)"#line:152
                        OOOOO00000000OO0O =OOOOO00000000OO0O .replace ("'","")#line:153
                        OO0OO0O0O00O0O0OO =O000O00O0O0OO0O00 [:-2 ]+OOOOO00000000OO0O #line:154
                        O0OO00OO00O000O00 .seek (0 )#line:155
                        O0OO00OO00O000O00 .write (OO0OO0O0O00O0O0OO )#line:156
                        O0OO00OO00O000O00 .truncate ()#line:157
            if IS_PROJECT :#line:159
                with open (O0000OO00OOO00000 .proj_flip_table_dir ,"r+")as O0OO00OO00O000O00 :#line:160
                    O000O00O0O0OO0O00 =O0OO00OO00O000O00 .read ()#line:161
                    if ("(lib (name \""+O00000OOO00O00OO0 ['kicad_library_name']+"\")(type KiCad)(uri \""+O0000OO00OOO00000 .snapeda_library_abs_dir +"\")")not in O000O00O0O0OO0O00 :#line:162
                        OOOOO00000000OO0O =('  (lib (name "'+O00000OOO00O00OO0 ['kicad_library_name']+'")(type KiCad)(uri "'+O0000OO00OOO00000 .snapeda_library_abs_dir +'")(options "")(descr ""))')+"\n\n)"#line:163
                        OOOOO00000000OO0O =OOOOO00000000OO0O .replace ("'","")#line:164
                        OO0OO0O0O00O0O0OO =O000O00O0O0OO0O00 [:-2 ]+OOOOO00000000OO0O #line:165
                        O0OO00OO00O000O00 .seek (0 )#line:166
                        O0OO00OO00O000O00 .write (OO0OO0O0O00O0O0OO )#line:167
                        O0OO00OO00O000O00 .truncate ()#line:168
        print ('aferdownloadview closed')#line:170
        global IS_SETTING_WINDOW_OPEN #line:171
        IS_SETTING_WINDOW_OPEN =False #line:172
        O0000OO00OOO00000 .parent .destroy ()#line:173
    def resize (O00000OOO000OOOO0 ,OO0O00O0O00O000O0 ,OO0OO0O0000O00000 ,OO00O0OO000OO00O0 ):#line:175
        ""#line:179
        if sys .version_info [0 ]==3 :#line:180
            O00O0OOO0O00O0O00 =OO0O00O0O00O000O0 .width ()#line:181
            O000O0O0OO0O00OOO =OO0O00O0O00O000O0 .height ()#line:182
            O000O00OO0OO0O00O =max (O00O0OOO0O00O0O00 ,O000O0O0OO0O00OOO )#line:183
            OO0O000O0OOO00O00 =max (OO0OO0O0000O00000 ,OO00O0OO000OO00O0 )#line:184
            if O000O00OO0OO0O00O >OO0O000O0OOO00O00 :#line:185
                return OO0O00O0O00O000O0 .subsample (int (O000O00OO0OO0O00O /OO0O000O0OOO00O00 ))#line:186
            else :#line:187
                return OO0O00O0O00O000O0 .zoom (int (OO0O000O0OOO00O00 /O000O00OO0OO0O00O ))#line:188
        else :#line:189
            O00O0OOO0O00O0O00 =OO0O00O0O00O000O0 .width ()#line:190
            O000O0O0OO0O00OOO =OO0O00O0O00O000O0 .height ()#line:191
            O000O00OO0OO0O00O =max (O00O0OOO0O00O0O00 ,O000O0O0OO0O00OOO )#line:192
            OO0O000O0OOO00O00 =max (OO0OO0O0000O00000 ,OO00O0OO000OO00O0 )#line:193
            if O000O00OO0OO0O00O >OO0O000O0OOO00O00 :#line:194
                return OO0O00O0O00O000O0 .subsample (O000O00OO0OO0O00O /OO0O000O0OOO00O00 )#line:195
            else :#line:196
                return OO0O00O0O00O000O0 .zoom (OO0O000O0OOO00O00 /O000O00OO0OO0O00O )#line:197
    def save_settings_callback (O0O0000O0O0O00OOO ,OO0OO0O00O000000O ):#line:199
        print ('info closed')#line:200
        global IS_SETTING_WINDOW_OPEN #line:201
        IS_SETTING_WINDOW_OPEN =False #line:202
        O0O0000O0O0O00OOO .parent .destroy ()#line:203
    def open_folder_callback (O0OOOO0O0O00O00OO ,OO0000O0O0000OO00 ):#line:205
        print ('Opening directory: '+O0OOOO0O0O00O00OO .open_dir )#line:206
        open (O0OOOO0O0O00O00OO .open_dir ,"r+")#line:207
    def global_checkbox_callback (O0OOO00O0O0O0OO00 ,OOOOOOOOO0O000OO0 ):#line:209
        global IS_GLOBAL #line:210
        if O0OOO00O0O0O0OO00 .global_var .get ()==0 :#line:211
            IS_GLOBAL =True #line:212
        else :#line:213
            IS_GLOBAL =False #line:214
    def project_checkbox_callback (O000OOO00O0000OOO ,O0O00OOO0O0OO0000 ):#line:217
        global IS_PROJECT #line:218
        if O000OOO00O0000OOO .project_var .get ()==0 :#line:219
            IS_PROJECT =True #line:220
        else :#line:221
            IS_PROJECT =False #line:222
    def initialize_user_interface (OOO0OOO00000O000O ):#line:225
        OOO0OOO00000O000O .parent .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:226
        OOO0OOO00000O000O .parent .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:227
        OOO0OOO00000O000O .parent_container =tk .Frame (OOO0OOO00000O000O .parent ,bg ="white")#line:228
        OOO0OOO00000O000O .parent_container .grid (row =0 ,column =0 ,sticky ="NEWS")#line:229
        OOO0OOO00000O000O .parent_container .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:230
        OOO0OOO00000O000O .parent_container .grid_rowconfigure (0 ,weight =1 )#line:231
        OOO0OOO00000O000O .main_frame =tk .Frame (OOO0OOO00000O000O .parent_container ,bg ="white")#line:232
        OOO0OOO00000O000O .main_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:233
        for OO00OO00O0O00O000 in range (5 ):#line:234
            OOO0OOO00000O000O .main_frame .grid_rowconfigure (OO00OO00O0O00O000 ,weight =1 ,uniform ="foo")#line:235
        OOO0OOO00000O000O .main_frame .grid (row =0 ,column =0 ,sticky ="NEWS")#line:236
        O00O0000O00OOO0OO ="Done"#line:238
        if OOO0OOO00000O000O .is_download_complete is False :#line:239
            O00O0000O00OOO0OO ="No models available."#line:240
            OOO0OOO00000O000O .done_button =tk .Label (OOO0OOO00000O000O .main_frame ,cursor ="hand2",bg ="#FF761A",fg ="white",text =O00O0000O00OOO0OO ,font =("Open Sans",13 ,"bold"))#line:241
            OOO0OOO00000O000O .done_button .grid (row =4 ,column =0 ,sticky ="NEWS")#line:242
            OOO0OOO00000O000O .done_button .bind ('<Button-1>',OOO0OOO00000O000O .on_closing )#line:243
            return #line:244
        if OOO0OOO00000O000O .flip_table_dir is not None or OOO0OOO00000O000O .proj_flip_table_dir is not None or OOO0OOO00000O000O .snapeda_library_abs_dir is not None :#line:246
            OO000OOOOO0O00OO0 =os .path .join (OOO0OOO00000O000O .appdata_dir ,"info.json")#line:248
            with open (OO000OOOOO0O00OO0 )as O00OO0O00O000OO0O :#line:249
                OO00OOO0OO0000O00 =json .load (O00OO0O00O000OO0O )#line:250
            OOO0OOO00000O000O .open_dir =OO00OOO0OO0000O00 ['kicad_library_dir']#line:251
            if len (OOO0OOO00000O000O .open_dir )>48 :#line:252
                OOO0OOO00000O000O .open_dir ='...'+OOO0OOO00000O000O .open_dir [len (OOO0OOO00000O000O .open_dir )-45 :]#line:253
            OOO0OOO00000O000O .folder_container =tk .Frame (OOO0OOO00000O000O .main_frame ,bg ="white")#line:255
            OOO0OOO00000O000O .folder_container .grid_columnconfigure (0 ,weight =2 ,uniform ="foo")#line:256
            OOO0OOO00000O000O .folder_container .grid_columnconfigure (1 ,weight =6 ,uniform ="foo")#line:257
            OOO0OOO00000O000O .folder_container .grid_rowconfigure (1 ,weight =1 ,uniform ="foo")#line:258
            OOO0OOO00000O000O .folder_container .grid (row =1 ,column =0 ,sticky ="NEWS")#line:259
            OOO0OOO00000O000O .folder_label_img =tk .PhotoImage (file =OOO0OOO00000O000O .folder_label_img_dir )#line:260
            OOO0OOO00000O000O .folder_label =tk .Label (OOO0OOO00000O000O .folder_container ,bg ="white",image =OOO0OOO00000O000O .folder_label_img )#line:261
            OOO0OOO00000O000O .folder_label .grid (row =0 ,column =0 ,sticky ="NEWS")#line:262
            OOO0OOO00000O000O .folder_input_label =tk .Label (OOO0OOO00000O000O .folder_container ,bg ="white",text =OOO0OOO00000O000O .open_dir )#line:263
            OOO0OOO00000O000O .folder_input_label .grid (row =0 ,column =1 ,sticky ="NWS",padx =(0 ,15 ))#line:264
        OOO0OOO00000O000O .checkbox_frame =tk .Frame (OOO0OOO00000O000O .main_frame ,bg ="white")#line:268
        OOO0OOO00000O000O .checkbox_frame .grid (row =2 ,column =0 ,sticky ="NEWS")#line:269
        OOO0OOO00000O000O .checkbox_frame .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:270
        for OO00OO00O0O00O000 in range (2 ):#line:271
            OOO0OOO00000O000O .checkbox_frame .grid_columnconfigure (OO00OO00O0O00O000 ,weight =1 ,uniform ="foo")#line:272
        OOO0OOO00000O000O .global_var =tk .IntVar ()#line:273
        OOO0OOO00000O000O .global_checkbox =tk .Checkbutton (OOO0OOO00000O000O .checkbox_frame ,variable =OOO0OOO00000O000O .global_var ,bg ="white",fg ="#FF761A",text ="Global",borderwidth =0 ,highlightthickness =0 )#line:274
        OOO0OOO00000O000O .global_checkbox .grid (row =0 ,column =0 ,sticky ="NES",padx =(0 ,20 ))#line:275
        OOO0OOO00000O000O .project_var =tk .IntVar ()#line:276
        OOO0OOO00000O000O .project_checkbox =tk .Checkbutton (OOO0OOO00000O000O .checkbox_frame ,variable =OOO0OOO00000O000O .project_var ,bg ="white",fg ="#FF761A",text ="Project Specific",borderwidth =0 ,highlightthickness =0 )#line:277
        OOO0OOO00000O000O .project_checkbox .grid (row =0 ,column =1 ,sticky ="NWS",padx =(20 ,0 ))#line:278
        global IS_GLOBAL #line:279
        global IS_PROJECT #line:280
        if IS_GLOBAL :#line:281
            OOO0OOO00000O000O .global_checkbox .select ()#line:282
        else :#line:283
            OOO0OOO00000O000O .global_checkbox .deselect ()#line:284
        if IS_PROJECT :#line:285
            OOO0OOO00000O000O .project_checkbox .select ()#line:286
        else :#line:287
            OOO0OOO00000O000O .project_checkbox .deselect ()#line:288
        OOO0OOO00000O000O .global_checkbox .bind ('<Button-1>',OOO0OOO00000O000O .global_checkbox_callback )#line:289
        OOO0OOO00000O000O .project_checkbox .bind ('<Button-1>',OOO0OOO00000O000O .project_checkbox_callback )#line:290
        try :#line:292
            if OO00OOO0OO0000O00 ['setting_autoplace_footprint']:#line:293
                tk .Label (OOO0OOO00000O000O .main_frame ,bg ="white",text ="Note: Autoplacement feature is on.\nYou should see the footprint on the board after download.").grid (row =3 ,column =0 ,sticky ="NEW")#line:294
        except :#line:295
            tk .Label (OOO0OOO00000O000O .main_frame ,bg ="white",text ="Note: Autoplacement feature is on.\nYou should see the footprint on the board after download.").grid (row =3 ,column =0 ,sticky ="NEW")#line:296
        OOO0OOO00000O000O .footer_frame =tk .Frame (OOO0OOO00000O000O .main_frame ,bg ="white")#line:299
        OOO0OOO00000O000O .footer_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:300
        OOO0OOO00000O000O .footer_frame .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:301
        OOO0OOO00000O000O .footer_frame .grid (row =4 ,column =0 ,sticky ="NEWS")#line:302
        OOO0OOO00000O000O .save_button_img =tk .PhotoImage (file =OOO0OOO00000O000O .save_button_img_dir )#line:303
        OOO0OOO00000O000O .save_button =tk .Label (OOO0OOO00000O000O .footer_frame ,cursor ="hand2",image =OOO0OOO00000O000O .save_button_img )#line:304
        OOO0OOO00000O000O .save_button .grid (row =0 ,column =0 ,sticky ="ES",padx =(0 ,25 ),pady =(0 ,25 ))#line:305
        OOO0OOO00000O000O .save_button .bind ('<Button-1>',OOO0OOO00000O000O .on_closing )#line:306
class InfoView (tk .Frame ):#line:309
    def __init__ (O0O0O00000O00000O ,OO00OOO0O0O0OO000 ):#line:310
        O0O0O00000O00000O .is_help_me_window =OO00OOO0O0O0OO000 .is_help_me_window #line:311
        O0O0O00000O00000O .parent =tk .Toplevel ()#line:312
        O000O00O000OO0O00 =int ((OO00OOO0O0O0OO000 .winfo_screenwidth ()/2 )-(393 /2 ))+(OO00OOO0O0O0OO000 .winfo_x ()/2 )#line:313
        O00OO00O000000O0O =int ((OO00OOO0O0O0OO000 .winfo_screenheight ()/2 )-(495 /2 ))+(OO00OOO0O0O0OO000 .winfo_y ()/2 )#line:314
        O0O0O00000O00000O .parent .geometry ('%dx%d+%d+%d'%(393 ,495 ,O000O00O000OO0O00 ,O00OO00O000000O0O ))#line:315
        O0O0O00000O00000O .parent .wait_visibility ()#line:316
        O0O0O00000O00000O .parent .grab_set ()#line:317
        global IS_SETTING_WINDOW_OPEN #line:318
        IS_SETTING_WINDOW_OPEN =True #line:319
        O0O0O00000O00000O .parent .resizable (False ,False )#line:320
        O0O0O00000O00000O .parent .minsize (width =393 ,height =495 )#line:321
        O0O0O00000O00000O .is_windows =(os .name =='nt')#line:322
        O0O0O00000O00000O .dir_path =os .path .dirname (os .path .realpath (__file__ ))#line:323
        if O0O0O00000O00000O .is_windows :#line:324
            O0O0O00000O00000O .windata_dir =os .path .join (os .getenv ('HOMEDRIVE'),os .getenv ('HOMEPATH'),"SnapEDA Kicad Plugin")#line:327
            O0O0O00000O00000O .appdata_dir =os .path .join (O0O0O00000O00000O .windata_dir ,"App")#line:328
        else :#line:329
            O0O0O00000O00000O .appdata_dir =os .path .join (O0O0O00000O00000O .dir_path ,"assets")#line:330
        O0O0O00000O00000O .powered_image_dir =os .path .join (O0O0O00000O00000O .appdata_dir ,"orb6glbv.png")#line:332
        O0O0O00000O00000O .icon_bitmap_dir =os .path .join (O0O0O00000O00000O .appdata_dir ,"32x32.ico")#line:333
        O0O0O00000O00000O .info_placeholder_img_dir =os .path .join (O0O0O00000O00000O .appdata_dir ,'info_placeholder.png')#line:334
        O0O0O00000O00000O .info_label_img_dir =os .path .join (O0O0O00000O00000O .appdata_dir ,'info_button.png')#line:335
        O0O0O00000O00000O .talk_to_us_button_image_dir =os .path .join (O0O0O00000O00000O .appdata_dir ,'talk_to_us_button.png')#line:336
        if O0O0O00000O00000O .is_windows :#line:338
            O0O0O00000O00000O .parent .iconbitmap (O0O0O00000O00000O .icon_bitmap_dir )#line:339
        O0O0O00000O00000O .initialize_user_interface ()#line:340
        O0O0O00000O00000O .parent .protocol ("WM_DELETE_WINDOW",lambda :O0O0O00000O00000O .on_closing (OO00OOO0O0O0OO000 ))#line:342
    def on_closing (O0O00OO0O00OO00O0 ,OO0O00O000OOO0OOO ):#line:344
        print ('closed info')#line:345
        global IS_SETTING_WINDOW_OPEN #line:346
        IS_SETTING_WINDOW_OPEN =False #line:347
        O0O00OO0O00OO00O0 .parent .destroy ()#line:348
    def resize (OO00O0OO00O0000OO ,OO0OOOOO0O00OO000 ,OO00O00OO0O0OO0OO ,OO0000O0O0O000O0O ):#line:350
        ""#line:354
        if sys .version_info [0 ]==3 :#line:355
            OOO0OO0OO0OO0OOO0 =OO0OOOOO0O00OO000 .width ()#line:356
            O0O000OO0OO0OOO00 =OO0OOOOO0O00OO000 .height ()#line:357
            OOO000O00OO00OOO0 =max (OOO0OO0OO0OO0OOO0 ,O0O000OO0OO0OOO00 )#line:358
            OOO00OO0O00O0000O =max (OO00O00OO0O0OO0OO ,OO0000O0O0O000O0O )#line:359
            if OOO000O00OO00OOO0 >OOO00OO0O00O0000O :#line:360
                return OO0OOOOO0O00OO000 .subsample (int (OOO000O00OO00OOO0 /OOO00OO0O00O0000O ))#line:361
            else :#line:362
                return OO0OOOOO0O00OO000 .zoom (int (OOO00OO0O00O0000O /OOO000O00OO00OOO0 ))#line:363
        else :#line:364
            OOO0OO0OO0OO0OOO0 =OO0OOOOO0O00OO000 .width ()#line:365
            O0O000OO0OO0OOO00 =OO0OOOOO0O00OO000 .height ()#line:366
            OOO000O00OO00OOO0 =max (OOO0OO0OO0OO0OOO0 ,O0O000OO0OO0OOO00 )#line:367
            OOO00OO0O00O0000O =max (OO00O00OO0O0OO0OO ,OO0000O0O0O000O0O )#line:368
            if OOO000O00OO00OOO0 >OOO00OO0O00O0000O :#line:369
                return OO0OOOOO0O00OO000 .subsample (OOO000O00OO00OOO0 /OOO00OO0O00O0000O )#line:370
            else :#line:371
                return OO0OOOOO0O00OO000 .zoom (OOO00OO0O00O0000O /OOO000O00OO00OOO0 )#line:372
    def save_settings_callback (O00OOOO000O0O00OO ,O000O0OOO00OO0OO0 ):#line:374
        print ('info closed')#line:375
        global IS_SETTING_WINDOW_OPEN #line:376
        IS_SETTING_WINDOW_OPEN =False #line:377
        O00OOOO000O0O00OO .parent .destroy ()#line:378
    def talk_to_us_button_callback (O000OOOO00OO000OO ,OOOO0OO0OO000OO00 ):#line:380
        webbrowser .open ('mailto:?to=info@snapeda.com',new =1 )#line:381
    def initialize_user_interface (O00OOO00000O000OO ):#line:383
        O00OOO00000O000OO .parent .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:384
        O00OOO00000O000OO .parent .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:385
        O00OOO00000O000OO .parent_container =tk .Frame (O00OOO00000O000OO .parent ,bg ="white")#line:386
        O00OOO00000O000OO .parent_container .grid (row =0 ,column =0 ,sticky ="NEWS")#line:387
        O00OOO00000O000OO .parent_container .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:388
        O00OOO00000O000OO .parent_container .grid_rowconfigure (0 ,weight =1 )#line:389
        O00OOO00000O000OO .main_frame =tk .Frame (O00OOO00000O000OO .parent_container ,bg ="white")#line:390
        O00OOO00000O000OO .main_frame .grid (row =0 ,column =0 ,columnspan =1 ,sticky ="NEWS")#line:391
        O00OOO00000O000OO .main_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:393
        for O000OO000000O0000 in range (20 ):#line:394
            O00OOO00000O000OO .main_frame .grid_rowconfigure (O000OO000000O0000 ,weight =1 ,uniform ="foo")#line:395
        O00OOO00000O000OO .navbar_frame =tk .Frame (O00OOO00000O000OO .main_frame ,bg ="white")#line:398
        O00OOO00000O000OO .navbar_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:399
        O00OOO00000O000OO .navbar_frame .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:400
        O00OOO00000O000OO .navbar_frame .grid (row =0 ,column =0 ,rowspan =2 ,sticky ="NEWS")#line:401
        O00OOO00000O000OO .info_label_img =tk .PhotoImage (file =O00OOO00000O000OO .info_label_img_dir )#line:402
        O00OOO00000O000OO .setting_label =tk .Label (O00OOO00000O000OO .navbar_frame ,bg ="white",fg ="#FF761B",image =O00OOO00000O000OO .info_label_img )#line:403
        O00OOO00000O000OO .setting_label .grid (row =0 ,column =0 ,sticky ="W",padx =(20 ,0 ))#line:404
        O00OOO00000O000OO .info_frame =tk .Frame (O00OOO00000O000OO .main_frame ,bg ="white")#line:407
        O00OOO00000O000OO .info_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:408
        O00OOO00000O000OO .info_frame .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:409
        O00OOO00000O000OO .info_frame .grid (row =3 ,column =0 ,rowspan =14 ,sticky ="NEWS")#line:410
        O00OOO00000O000OO .info_placeholder_img =tk .PhotoImage (file =O00OOO00000O000OO .info_placeholder_img_dir )#line:411
        O00OOO00000O000OO .info_placeholder =tk .Label (O00OOO00000O000OO .info_frame ,bg ="white",image =O00OOO00000O000OO .info_placeholder_img )#line:412
        O00OOO00000O000OO .info_placeholder .grid (row =0 ,column =0 ,sticky ="NEWS")#line:413
        O0OO0O0OO0OOO0OOO ='1. Search for the part\n\n2. Click on Download\n\n3. Go to Place > Footprint or >  Symbol\n\n4. Find the part in your "SnapEDA Library"\n\n5. Use it in your design\n'#line:415
        if (O00OOO00000O000OO .is_help_me_window is True ):#line:416
            O0OO0O0OO0OOO0OOO ='For any concerns or suggestions in using\nthis plugin, kindly contact us at\ninfo@snapeda.com.'#line:417
        O00OOO00000O000OO .instruction_label =tk .Label (O00OOO00000O000OO .info_placeholder ,justify =tk .LEFT ,bg ="#E5E5E5",fg ="#304E70",text =O0OO0O0OO0OOO0OOO ,font =("Open Sans",10 ))#line:418
        O00OOO00000O000OO .instruction_label .grid (row =0 ,column =0 ,sticky ="NWS",padx =(30 ,0 ),pady =(80 ,0 ))#line:419
        O00OOO00000O000OO .footer_frame =tk .Frame (O00OOO00000O000OO .main_frame ,bg ="white")#line:422
        O00OOO00000O000OO .footer_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:423
        O00OOO00000O000OO .footer_frame .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:424
        O00OOO00000O000OO .footer_frame .grid (row =18 ,column =0 ,rowspan =2 ,columnspan =2 ,sticky ="NEWS")#line:425
        O00OOO00000O000OO .talk_to_us_button_image =tk .PhotoImage (file =O00OOO00000O000OO .talk_to_us_button_image_dir )#line:426
        O00OOO00000O000OO .talk_to_us_button =tk .Label (O00OOO00000O000OO .footer_frame ,bg ="white",cursor ="hand2",image =O00OOO00000O000OO .talk_to_us_button_image )#line:427
        O00OOO00000O000OO .talk_to_us_button .grid (row =0 ,column =0 ,sticky ="E",padx =(0 ,25 ),pady =(0 ,10 ))#line:428
        O00OOO00000O000OO .talk_to_us_button .bind ('<Button-1>',O00OOO00000O000OO .talk_to_us_button_callback )#line:429
class SettingsView (tk .Frame ):#line:431
    def __init__ (OOO000000000O0000 ,O0O0OO0OO00O00O00 ):#line:432
        OOO000000000O0000 .parent =tk .Toplevel ()#line:433
        O0OO0OO000OOOO000 =int ((O0O0OO0OO00O00O00 .winfo_screenwidth ()/2 )-(458 /2 ))+(O0O0OO0OO00O00O00 .winfo_x ()/2 )#line:434
        O0OO00OOO0OO0OOO0 =int ((O0O0OO0OO00O00O00 .winfo_screenheight ()/2 )-(600 /2 ))+(O0O0OO0OO00O00O00 .winfo_y ()/2 )#line:435
        OOO000000000O0000 .parent .geometry ('%dx%d+%d+%d'%(458 ,600 ,O0OO0OO000OOOO000 ,O0OO00OOO0OO0OOO0 ))#line:436
        OOO000000000O0000 .parent .wait_visibility ()#line:437
        OOO000000000O0000 .parent .grab_set ()#line:438
        global IS_SETTING_WINDOW_OPEN #line:439
        IS_SETTING_WINDOW_OPEN =True #line:440
        OOO000000000O0000 .parent .resizable (False ,False )#line:441
        OOO000000000O0000 .parent .minsize (width =458 ,height =600 )#line:442
        OOO000000000O0000 .is_windows =(os .name =='nt')#line:443
        OOO000000000O0000 .dir_path =os .path .dirname (os .path .realpath (__file__ ))#line:444
        if OOO000000000O0000 .is_windows :#line:445
            OOO000000000O0000 .windata_dir =os .path .join (os .getenv ('HOMEDRIVE'),os .getenv ('HOMEPATH'),"SnapEDA Kicad Plugin")#line:448
            OOO000000000O0000 .appdata_dir =os .path .join (OOO000000000O0000 .windata_dir ,"App")#line:449
            OOO000000000O0000 .flip_table_dir =os .path .join (os .getenv ('APPDATA'),'kicad','fp-lib-table')#line:452
        else :#line:453
            OOO000000000O0000 .appdata_dir =os .path .join (OOO000000000O0000 .dir_path ,"assets")#line:454
            OOO000000000O0000 .flip_table_dir =os .path .join (os .path .expanduser ("~"),'.config','kicad','fp-lib-table')#line:458
        OOO000000000O0000 .powered_image_dir =os .path .join (OOO000000000O0000 .appdata_dir ,"orb6glbv.png")#line:460
        OOO000000000O0000 .icon_bitmap_dir =os .path .join (OOO000000000O0000 .appdata_dir ,"32x32.ico")#line:461
        OOO000000000O0000 .settings_label_img_dir =os .path .join (OOO000000000O0000 .appdata_dir ,'settings_button.png')#line:462
        OOO000000000O0000 .setting_placeholder_img_dir =os .path .join (OOO000000000O0000 .appdata_dir ,'settings_placeholder.png')#line:463
        OOO000000000O0000 .settings_input_placeholder_dir =os .path .join (OOO000000000O0000 .appdata_dir ,'settings_input_placeholder.png')#line:464
        OOO000000000O0000 .save_button_img_dir =os .path .join (OOO000000000O0000 .appdata_dir ,'save_button.png')#line:465
        if OOO000000000O0000 .is_windows :#line:467
            OOO000000000O0000 .parent .iconbitmap (OOO000000000O0000 .icon_bitmap_dir )#line:468
        OOO000000000O0000 .initialize_user_interface ()#line:469
        OOO000000000O0000 .parent .protocol ("WM_DELETE_WINDOW",lambda :OOO000000000O0000 .on_closing (O0O0OO0OO00O00O00 ))#line:471
    def on_closing (OO000OO0OOO000OO0 ,O0OOO0OO0OOO0O0O0 ):#line:473
        print ('closed settings')#line:474
        global IS_SETTING_WINDOW_OPEN #line:475
        IS_SETTING_WINDOW_OPEN =False #line:476
        OO000OO0OOO000OO0 .parent .destroy ()#line:477
    def resize (OO0O0OOO0O00O00O0 ,OOO000000OO00O000 ,OO0O0000OOO000000 ,OOO0OO00OO000OOO0 ):#line:479
        ""#line:483
        if sys .version_info [0 ]==3 :#line:484
            OOO000O0000O00O0O =OOO000000OO00O000 .width ()#line:485
            O0OO00O0O00OOOOOO =OOO000000OO00O000 .height ()#line:486
            O0OOOO0O0O00OO0OO =max (OOO000O0000O00O0O ,O0OO00O0O00OOOOOO )#line:487
            O0O0O0OOO00O000O0 =max (OO0O0000OOO000000 ,OOO0OO00OO000OOO0 )#line:488
            if O0OOOO0O0O00OO0OO >O0O0O0OOO00O000O0 :#line:489
                return OOO000000OO00O000 .subsample (int (O0OOOO0O0O00OO0OO /O0O0O0OOO00O000O0 ))#line:490
            else :#line:491
                return OOO000000OO00O000 .zoom (int (O0O0O0OOO00O000O0 /O0OOOO0O0O00OO0OO ))#line:492
        else :#line:493
            OOO000O0000O00O0O =OOO000000OO00O000 .width ()#line:494
            O0OO00O0O00OOOOOO =OOO000000OO00O000 .height ()#line:495
            O0OOOO0O0O00OO0OO =max (OOO000O0000O00O0O ,O0OO00O0O00OOOOOO )#line:496
            O0O0O0OOO00O000O0 =max (OO0O0000OOO000000 ,OOO0OO00OO000OOO0 )#line:497
            if O0OOOO0O0O00OO0OO >O0O0O0OOO00O000O0 :#line:498
                return OOO000000OO00O000 .subsample (O0OOOO0O0O00OO0OO /O0O0O0OOO00O000O0 )#line:499
            else :#line:500
                return OOO000000OO00O000 .zoom (O0O0O0OOO00O000O0 /O0OOOO0O0O00OO0OO )#line:501
    def save_settings_callback (OOO0OO00O0OOO0OOO ,OOOO0000OO00000O0 ):#line:503
        OO0OO000O00OO00O0 =os .path .join (OOO0OO00O0OOO0OOO .appdata_dir ,"info.json")#line:504
        with open (OO0OO000O00OO00O0 )as O000O000000OO0OO0 :#line:505
            O0O00000O0OOOOOO0 =json .load (O000O000000OO0OO0 )#line:506
        OOOOO000O00000OOO =False #line:509
        with open (OOO0OO00O0OOO0OOO .flip_table_dir ,"r+")as OO0O00O0O0O0O0O00 :#line:510
            O00000O00O0OO00O0 =OO0O00O0O0O0O0O00 .read ()#line:511
            O0O0OO0O0O0O000OO ="(lib (name \""+OOO0OO00O0OOO0OOO .kicad_dir_name_entry .get ()#line:512
            if O0O0OO0O0O0O000OO in O00000O00O0OO00O0 :#line:513
                O0O0OO0O0O0O000OO =("(lib (name \""+OOO0OO00O0OOO0OOO .kicad_dir_name_entry .get ()+"\")(type KiCad)(uri \""+os .path .join (OOO0OO00O0OOO0OOO .selected_dir ,OOO0OO00O0OOO0OOO .kicad_dir_name_entry .get ())+'.pretty\"')#line:514
                print (O0O0OO0O0O0O000OO )#line:515
                if O0O0OO0O0O0O000OO not in O00000O00O0OO00O0 :#line:516
                    print ('invalid')#line:517
                    OOOOO000O00000OOO =True #line:518
                    OO0O00O0O0O0O0O00 .close ()#line:519
                else :#line:520
                    print ('valid')#line:521
        if (OOOOO000O00000OOO ):#line:523
            tkMessageBox .showwarning ("Warning","Duplicate library name.\n Please choose a different lib name.")#line:524
            return #line:525
        if OOO0OO00O0OOO0OOO .auto_place_value .get ()==0 :#line:527
            O0O00000O0OOOOOO0 ['setting_autoplace_footprint']=False #line:528
        else :#line:529
            O0O00000O0OOOOOO0 ['setting_autoplace_footprint']=True #line:530
        O0O00000O0OOOOOO0 ['kicad_library_dir']=OOO0OO00O0OOO0OOO .selected_dir #line:532
        O0O00000O0OOOOOO0 ['kicad_library_name']=OOO0OO00O0OOO0OOO .kicad_dir_name_entry .get ()#line:533
        with open (OO0OO000O00OO00O0 ,'w')as OO0O0O0OOO0O0OO00 :#line:534
            json .dump (O0O00000O0OOOOOO0 ,OO0O0O0OOO0O0OO00 )#line:535
        print ('Settings saved: '+OOO0OO00O0OOO0OOO .selected_dir +', lib name: '+OOO0OO00O0OOO0OOO .kicad_dir_name_entry .get ())#line:536
        global IS_SETTING_WINDOW_OPEN #line:537
        IS_SETTING_WINDOW_OPEN =False #line:538
        OOO0OO00O0OOO0OOO .parent .destroy ()#line:539
    def file_input_callback (OOOO0OO0000O00O00 ,O00O000O00O0000OO ):#line:541
        O00O00O0OO0OO0000 =os .path .expanduser (os .path .join (OOOO0OO0000O00O00 .selected_dir ,''))#line:542
        OOOO0OO0000O00O00 .selected_dir =fd .askdirectory (initialdir =O00O00O0OO0OO0000 ).replace ('/','\\')#line:543
        if (OOOO0OO0000O00O00 .selected_dir is None )or (OOOO0OO0000O00O00 .selected_dir ==''):#line:544
            OOOO0OO0000O00O00 .selected_dir =str (O00O00O0OO0OO0000 )#line:545
        if len (OOOO0OO0000O00O00 .selected_dir )>35 :#line:546
            OOOO0OO0000O00O00 .download_dir .set ('...'+OOOO0OO0000O00O00 .selected_dir [len (OOOO0OO0000O00O00 .selected_dir )-33 :])#line:547
        else :#line:548
            OOOO0OO0000O00O00 .download_dir .set (OOOO0OO0000O00O00 .selected_dir )#line:549
        print (OOOO0OO0000O00O00 .selected_dir )#line:550
    def initialize_user_interface (O0OO00O00OOO0O000 ):#line:552
        O0OO00O00OOO0O000 .parent .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:553
        O0OO00O00OOO0O000 .parent .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:554
        O0OO00O00OOO0O000 .parent_container =tk .Frame (O0OO00O00OOO0O000 .parent ,bg ="white")#line:555
        O0OO00O00OOO0O000 .parent_container .grid (row =0 ,column =0 ,sticky ="NEWS")#line:556
        O0OO00O00OOO0O000 .parent_container .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:557
        O0OO00O00OOO0O000 .parent_container .grid_rowconfigure (0 ,weight =1 )#line:558
        O0OO00O00OOO0O000 .main_frame =tk .Frame (O0OO00O00OOO0O000 .parent_container ,bg ="white")#line:559
        O0OO00O00OOO0O000 .main_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:560
        O0OO00O00OOO0O000 .main_frame .grid_rowconfigure (0 ,weight =3 ,uniform ="foo")#line:561
        O0OO00O00OOO0O000 .main_frame .grid_rowconfigure (1 ,weight =5 ,uniform ="foo")#line:562
        O0OO00O00OOO0O000 .main_frame .grid_rowconfigure (2 ,weight =5 ,uniform ="foo")#line:563
        O0OO00O00OOO0O000 .main_frame .grid_rowconfigure (3 ,weight =3 ,uniform ="foo")#line:564
        O0OO00O00OOO0O000 .main_frame .grid (row =0 ,column =0 ,columnspan =1 ,sticky ="NEWS")#line:565
        O0OO00O00OOO0O000 .navbar_frame =tk .Frame (O0OO00O00OOO0O000 .main_frame ,bg ="white")#line:569
        O0OO00O00OOO0O000 .navbar_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:570
        O0OO00O00OOO0O000 .navbar_frame .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:571
        O0OO00O00OOO0O000 .navbar_frame .grid (row =0 ,column =0 ,sticky ="NEWS")#line:572
        O0OO00O00OOO0O000 .settings_label_img =tk .PhotoImage (file =O0OO00O00OOO0O000 .settings_label_img_dir )#line:573
        O0OO00O00OOO0O000 .setting_label =tk .Label (O0OO00O00OOO0O000 .navbar_frame ,bg ="white",fg ="#FF761B",image =O0OO00O00OOO0O000 .settings_label_img )#line:574
        O0OO00O00OOO0O000 .setting_label .grid (row =0 ,column =0 ,sticky ="W",padx =(25 ,0 ))#line:575
        O0OO00O00OOO0O000 .body_frame =tk .Frame (O0OO00O00OOO0O000 .main_frame ,bg ="white")#line:578
        O0OO00O00OOO0O000 .body_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:579
        O0OO00O00OOO0O000 .body_frame .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:580
        O0OO00O00OOO0O000 .body_frame .grid (row =1 ,column =0 ,sticky ="NEWS")#line:581
        O0OO00O00OOO0O000 .setting_placeholder_img =tk .PhotoImage (file =O0OO00O00OOO0O000 .setting_placeholder_img_dir )#line:582
        O0OO00O00OOO0O000 .setting_001_placeholder =tk .Label (O0OO00O00OOO0O000 .body_frame ,bg ="white",image =O0OO00O00OOO0O000 .setting_placeholder_img )#line:583
        O0OO00O00OOO0O000 .setting_001_placeholder .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:584
        O0OO00O00OOO0O000 .setting_001_placeholder .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:585
        O0OO00O00OOO0O000 .setting_001_placeholder .grid_rowconfigure (1 ,weight =3 ,uniform ="foo")#line:586
        O0OO00O00OOO0O000 .setting_001_placeholder .grid_rowconfigure (2 ,weight =3 ,uniform ="foo")#line:587
        O0OO00O00OOO0O000 .setting_001_placeholder .grid_rowconfigure (3 ,weight =1 ,uniform ="foo")#line:588
        O0OO00O00OOO0O000 .setting_001_placeholder .grid (row =0 ,column =0 ,sticky ="NEWS")#line:589
        O0OO00O00OOO0O000 .form_top =tk .Frame (O0OO00O00OOO0O000 .setting_001_placeholder ,bg ="#E5E5E5")#line:591
        O0OO00O00OOO0O000 .form_top .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:592
        O0OO00O00OOO0O000 .form_top .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:593
        O0OO00O00OOO0O000 .form_top .grid_columnconfigure (1 ,weight =2 ,uniform ="foo")#line:594
        O0OO00O00OOO0O000 .form_top .grid (row =1 ,column =0 ,sticky ="NEWS",padx =(30 ,30 ),pady =(1 ,0 ))#line:595
        O0OO00O00OOO0O000 .settings_input_placeholder =tk .PhotoImage (file =O0OO00O00OOO0O000 .settings_input_placeholder_dir )#line:598
        O0OO00O00OOO0OO00 =os .path .join (O0OO00O00OOO0O000 .appdata_dir ,"info.json")#line:599
        with open (O0OO00O00OOO0OO00 )as O0OOOO0OO0O00O0O0 :#line:600
            O00000O00OOOO000O =json .load (O0OOOO0OO0O00O0O0 )#line:601
        tk .Label (O0OO00O00OOO0O000 .form_top ,bg ="#E5E5E5",fg ="#666460",text ="Libraries Path",font =("Open Sans",11 ,"bold")).grid (row =0 ,column =0 ,sticky ="NEWS")#line:603
        tk .Label (O0OO00O00OOO0O000 .form_top ,bg ="#E5E5E5",image =O0OO00O00OOO0O000 .settings_input_placeholder ,cursor ="hand2").grid (row =0 ,column =1 ,sticky ="NEWS")#line:604
        O0O00O0O0OO0OOOO0 =O00000O00OOOO000O ['kicad_library_dir']#line:605
        O0OO00O00OOO0O000 .selected_dir =O0O00O0O0OO0OOOO0 #line:606
        if len (O0O00O0O0OO0OOOO0 )>35 :#line:607
            O0O00O0O0OO0OOOO0 ='...'+O0O00O0O0OO0OOOO0 [len (O0O00O0O0OO0OOOO0 )-33 :]#line:608
        O0OO00O00OOO0O000 .download_dir =tk .StringVar ()#line:609
        O0OO00O00OOO0O000 .download_dir .set (O0O00O0O0OO0OOOO0 )#line:610
        O0OO00O00OOO0O000 .file_input =tk .Label (O0OO00O00OOO0O000 .form_top ,bg ="white",textvariable =O0OO00O00OOO0O000 .download_dir ,cursor ="hand2",font =("Open Sans",8 ))#line:611
        O0OO00O00OOO0O000 .file_input .grid (row =0 ,column =1 ,sticky ="NEWS",padx =(20 ,20 ),pady =(20 ,20 ))#line:612
        O0OO00O00OOO0O000 .file_input .bind ('<Button-1>',O0OO00O00OOO0O000 .file_input_callback )#line:613
        O0OO00O00OOO0O000 .form_bottom =tk .Frame (O0OO00O00OOO0O000 .setting_001_placeholder ,bg ="#E5E5E5")#line:616
        O0OO00O00OOO0O000 .form_bottom .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:617
        O0OO00O00OOO0O000 .form_bottom .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:618
        O0OO00O00OOO0O000 .form_bottom .grid_columnconfigure (1 ,weight =2 ,uniform ="foo")#line:619
        O0OO00O00OOO0O000 .form_bottom .grid (row =2 ,column =0 ,sticky ="NEWS",padx =(30 ,30 ),pady =(0 ,1 ))#line:620
        tk .Label (O0OO00O00OOO0O000 .form_bottom ,bg ="#E5E5E5",fg ="#666460",text ="Library Name",font =("Open Sans",11 ,"bold")).grid (row =0 ,column =0 ,sticky ="NEWS")#line:622
        tk .Label (O0OO00O00OOO0O000 .form_bottom ,bg ="#E5E5E5",image =O0OO00O00OOO0O000 .settings_input_placeholder ,cursor ="hand2").grid (row =0 ,column =1 ,sticky ="NEWS")#line:623
        O0OO00O00OOO0O000 .entry_value =tk .StringVar ()#line:624
        O0OO00O00OOO0O000 .entry_value .set (O00000O00OOOO000O ['kicad_library_name'])#line:625
        O0OO00O00OOO0O000 .kicad_dir_name_entry =tk .Entry (O0OO00O00OOO0O000 .form_bottom ,textvariable =O0OO00O00OOO0O000 .entry_value ,bg ="white",font =("Open Sans",8 ),borderwidth =0 ,highlightthickness =0 )#line:626
        O0OO00O00OOO0O000 .kicad_dir_name_entry .grid (row =0 ,column =1 ,sticky ="NEWS",padx =(20 ,20 ),pady =(20 ,20 ))#line:627
        O0OO00O00OOO0O000 .body_auto_place_frame =tk .Frame (O0OO00O00OOO0O000 .main_frame ,bg ="white")#line:630
        O0OO00O00OOO0O000 .body_auto_place_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:631
        O0OO00O00OOO0O000 .body_auto_place_frame .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:632
        O0OO00O00OOO0O000 .body_auto_place_frame .grid (row =2 ,column =0 ,sticky ="NEW")#line:633
        O0OO00O00OOO0O000 .auto_place_value =tk .IntVar ()#line:634
        O0OO00O00OOO0O000 .auto_place_checkbox =tk .Checkbutton (O0OO00O00OOO0O000 .body_auto_place_frame ,variable =O0OO00O00OOO0O000 .auto_place_value ,fg ="#FF761A",bg ="white",text ="Auto place footprints",borderwidth =0 ,highlightthickness =0 )#line:635
        try :#line:636
            if O00000O00OOOO000O ['setting_autoplace_footprint']:#line:637
                O0OO00O00OOO0O000 .auto_place_checkbox .select ()#line:638
            else :#line:639
                O0OO00O00OOO0O000 .auto_place_checkbox .deselect ()#line:640
        except :#line:641
            O0OO00O00OOO0O000 .auto_place_checkbox .select ()#line:642
        O0OO00O00OOO0O000 .auto_place_checkbox .grid (row =0 ,column =0 ,sticky ="NEW")#line:643
        O0OO00O00OOO0O000 .footer_frame =tk .Frame (O0OO00O00OOO0O000 .main_frame ,bg ="white")#line:646
        O0OO00O00OOO0O000 .footer_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:647
        O0OO00O00OOO0O000 .footer_frame .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:648
        O0OO00O00OOO0O000 .footer_frame .grid (row =3 ,column =0 ,sticky ="NEWS")#line:649
        O0OO00O00OOO0O000 .save_button_img =tk .PhotoImage (file =O0OO00O00OOO0O000 .save_button_img_dir )#line:650
        O0OO00O00OOO0O000 .save_button =tk .Label (O0OO00O00OOO0O000 .footer_frame ,cursor ="hand2",image =O0OO00O00OOO0O000 .save_button_img )#line:651
        O0OO00O00OOO0O000 .save_button .grid (row =0 ,column =0 ,sticky ="ES",padx =(0 ,25 ),pady =(0 ,25 ))#line:652
        O0OO00O00OOO0O000 .save_button .bind ('<Button-1>',O0OO00O00OOO0O000 .save_settings_callback )#line:653
class TableView (tk .Frame ):#line:655
    ""#line:658
    def __init__ (O0OOO00O000O0O00O ,O00O0O000000O0000 ):#line:660
        tk .Frame .__init__ (O0OOO00O000O0O00O ,O00O0O000000O0000 )#line:661
        O0OOO00O000O0O00O .parent =O00O0O000000O0000 #line:662
        O0OOO00O000O0O00O .dir_path =os .path .dirname (os .path .realpath (__file__ ))#line:663
        O0OOO00O000O0O00O .is_mac =platform .mac_ver ()[0 ]!=""#line:664
        O0OOO00O000O0O00O .is_windows =(os .name =='nt')#line:665
        if O0OOO00O000O0O00O .is_windows :#line:666
            O0OOO00O000O0O00O .windata_dir =os .path .join (os .getenv ('HOMEDRIVE'),os .getenv ('HOMEPATH'),"SnapEDA Kicad Plugin")#line:669
            O0OOO00O000O0O00O .flip_table_dir =os .path .join (os .getenv ('APPDATA'),'kicad','fp-lib-table')#line:672
            O0OOO00O000O0O00O .proj_flip_table_dir =os .path .join (os .getenv ('APPDATA'),'kicad','prj-fp-lib-table')#line:675
            if not os .path .exists (O0OOO00O000O0O00O .proj_flip_table_dir ):#line:677
                OOO0OO0O0OOO00O0O ='(fp_lib_table\n\n)'#line:678
                with open (O0OOO00O000O0O00O .proj_flip_table_dir ,'w')as O0OO0O000O00000O0 :#line:679
                    O0OO0O000O00000O0 .write (OOO0OO0O0OOO00O0O )#line:680
                    O0OO0O000O00000O0 .close #line:681
            O0OOO00O000O0O00O .appdata_dir =os .path .join (O0OOO00O000O0O00O .windata_dir ,"App")#line:683
            if not os .path .exists (O0OOO00O000O0O00O .windata_dir ):#line:685
                os .makedirs (O0OOO00O000O0O00O .windata_dir )#line:686
            if not os .path .exists (O0OOO00O000O0O00O .appdata_dir ):#line:687
                os .makedirs (O0OOO00O000O0O00O .appdata_dir )#line:688
            O0OOO00O000O0O00O .kicad_library_dir =os .path .join (O0OOO00O000O0O00O .windata_dir ,'KiCad Library')#line:690
            O0OOO00O000O0O00O .snapeda_library_abs_dir =os .path .join (O0OOO00O000O0O00O .kicad_library_dir ,'SnapEDA Library.pretty')#line:692
            O0OOO00O000O0O00O .snapeda_threedee_models_dir =os .path .join (O0OOO00O000O0O00O .kicad_library_dir ,'SnapEDA 3D Models')#line:694
            if not os .path .exists (O0OOO00O000O0O00O .kicad_library_dir ):#line:696
                os .makedirs (O0OOO00O000O0O00O .kicad_library_dir )#line:697
            if not os .path .exists (O0OOO00O000O0O00O .snapeda_library_abs_dir ):#line:698
                os .makedirs (O0OOO00O000O0O00O .snapeda_library_abs_dir )#line:699
            if not os .path .exists (O0OOO00O000O0O00O .snapeda_threedee_models_dir ):#line:700
                os .makedirs (O0OOO00O000O0O00O .snapeda_threedee_models_dir )#line:701
        elif O0OOO00O000O0O00O .is_mac :#line:702
            O0OOO00O000O0O00O .macdata_dir =os .path .join (os .path .expanduser ("~"),"Documents","SnapEDA Kicad Plugin")#line:703
            O0OOO00O000O0O00O .appdata_dir =os .path .join (O0OOO00O000O0O00O .macdata_dir ,"App")#line:704
            O0OOO00O000O0O00O .flip_table_dir =os .path .join (os .getenv ('HOME'),'library','preferences','kicad','fp-lib-table')#line:705
            O0OOO00O000O0O00O .proj_flip_table_dir =os .path .join (os .getenv ('HOME'),'library','preferences','kicad','prj-fp-lib-table')#line:706
            O0OOO00O000O0O00O .kicad_common_dir =os .path .join (os .getenv ('HOME'),'library','preferences','kicad','kicad_common')#line:707
            O0OOO00O000O0O00O .kicad_library_dir =os .path .join (O0OOO00O000O0O00O .macdata_dir ,'KiCad Library')#line:708
            O0OOO00O000O0O00O .snapeda_library_dir =os .path .join (O0OOO00O000O0O00O .kicad_library_dir ,'SnapEDA Library')#line:710
            O0OOO00O000O0O00O .snapeda_library_abs_dir =os .path .join (O0OOO00O000O0O00O .kicad_library_dir ,'SnapEDA Library.pretty')#line:712
            O0OOO00O000O0O00O .snapeda_threedee_models_dir =os .path .join (O0OOO00O000O0O00O .kicad_library_dir ,'SnapEDA 3D Models')#line:714
            if not os .path .exists (O0OOO00O000O0O00O .appdata_dir ):#line:715
                os .makedirs (O0OOO00O000O0O00O .appdata_dir )#line:716
            if not os .path .exists (O0OOO00O000O0O00O .kicad_library_dir ):#line:717
                os .makedirs (O0OOO00O000O0O00O .kicad_library_dir )#line:718
            if not os .path .exists (O0OOO00O000O0O00O .snapeda_library_dir ):#line:719
                os .makedirs (O0OOO00O000O0O00O .snapeda_library_dir )#line:720
            if not os .path .exists (O0OOO00O000O0O00O .snapeda_library_abs_dir ):#line:721
                os .makedirs (O0OOO00O000O0O00O .snapeda_library_abs_dir )#line:722
            if not os .path .exists (O0OOO00O000O0O00O .snapeda_threedee_models_dir ):#line:723
                os .makedirs (O0OOO00O000O0O00O .snapeda_threedee_models_dir )#line:724
            if not os .path .exists (O0OOO00O000O0O00O .proj_flip_table_dir ):#line:726
                OOO0OO0O0OOO00O0O ='(fp_lib_table\n\n)'#line:727
                with open (O0OOO00O000O0O00O .proj_flip_table_dir ,'w')as O0OO0O000O00000O0 :#line:728
                    O0OO0O000O00000O0 .write (OOO0OO0O0OOO00O0O )#line:729
                    O0OO0O000O00000O0 .close #line:730
        else :#line:731
            O0OOO00O000O0O00O .appdata_dir =os .path .join (O0OOO00O000O0O00O .dir_path ,"assets")#line:732
            if not os .path .exists (O0OOO00O000O0O00O .appdata_dir ):#line:733
                os .makedirs (O0OOO00O000O0O00O .appdata_dir )#line:734
            O0OOO00O000O0O00O .flip_table_dir =os .path .join (os .path .expanduser ("~"),'.config','kicad','fp-lib-table')#line:738
            O0OOO00O000O0O00O .proj_flip_table_dir =os .path .join (os .path .expanduser ("~"),'.config','kicad','prj-fp-lib-table')#line:743
            if not os .path .exists (O0OOO00O000O0O00O .proj_flip_table_dir ):#line:745
                OOO0OO0O0OOO00O0O ='(fp_lib_table\n\n)'#line:746
                with open (O0OOO00O000O0O00O .proj_flip_table_dir ,'w')as O0OO0O000O00000O0 :#line:747
                    O0OO0O000O00000O0 .write (OOO0OO0O0OOO00O0O )#line:748
                    O0OO0O000O00000O0 .close #line:749
            OOO000000OOO0OOO0 =os .path .expanduser ("~")#line:751
            O0OOO00O000O0O00O .kicad_library_dir =os .path .join (OOO000000OOO0OOO0 ,'KiCad Library')#line:752
            O0OOO00O000O0O00O .snapeda_library_abs_dir =os .path .join (O0OOO00O000O0O00O .kicad_library_dir ,'SnapEDA Library.pretty')#line:754
            O0OOO00O000O0O00O .snapeda_threedee_models_dir =os .path .join (O0OOO00O000O0O00O .kicad_library_dir ,'SnapEDA 3D Models')#line:756
            if not os .path .exists (O0OOO00O000O0O00O .kicad_library_dir ):#line:757
                os .makedirs (O0OOO00O000O0O00O .kicad_library_dir )#line:758
            if not os .path .exists (O0OOO00O000O0O00O .snapeda_library_abs_dir ):#line:759
                os .makedirs (O0OOO00O000O0O00O .snapeda_library_abs_dir )#line:760
            if not os .path .exists (O0OOO00O000O0O00O .snapeda_threedee_models_dir ):#line:761
                os .makedirs (O0OOO00O000O0O00O .snapeda_threedee_models_dir )#line:762
        O0OOO00O000O0O00O .icon_bitmap_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"32x32.ico")#line:764
        O0OOO00O000O0O00O .filter_button_image_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"neeo2s8g.png")#line:765
        O0OOO00O000O0O00O .settings_button_image_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"7svfoe57.png")#line:766
        O0OOO00O000O0O00O .about_button_image_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"2kdtezsl.png")#line:767
        O0OOO00O000O0O00O .passive_components_image_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"t3gwhnzh.png")#line:768
        O0OOO00O000O0O00O .all_button_image_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"dsyrvfl9.png")#line:769
        O0OOO00O000O0O00O .powered_image_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"orb6glbv.png")#line:770
        O0OOO00O000O0O00O .datasheet_button_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"oxfarxz8.png")#line:771
        O0OOO00O000O0O00O .datasheet_available_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"m4lamm2w.png")#line:772
        O0OOO00O000O0O00O .datasheet_not_available_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"4cnn9kkf.png")#line:773
        O0OOO00O000O0O00O .symbol_available_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"huaxvbtm.png")#line:774
        O0OOO00O000O0O00O .symbol_not_available_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"tmuhgmxh.png")#line:775
        O0OOO00O000O0O00O .footprint_available_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"3ruuehki.png")#line:776
        O0OOO00O000O0O00O .footprint_not_available_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"62r7iuz7.png")#line:777
        O0OOO00O000O0O00O .available_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"uku4ceuv.png")#line:778
        O0OOO00O000O0O00O .not_available_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"zah3n8r4.png")#line:779
        O0OOO00O000O0O00O .prev_bg_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"iu2ma3jp.png")#line:780
        O0OOO00O000O0O00O .next_bg_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"witafnjf.png")#line:781
        O0OOO00O000O0O00O .selected_page_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"izif2qd8.png")#line:782
        O0OOO00O000O0O00O .download_button_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"download+orange.png")#line:783
        O0OOO00O000O0O00O .view_button_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"viewonsnapeda+white.png")#line:784
        O0OOO00O000O0O00O .search_button_image_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"4i2efbui.png")#line:785
        O0OOO00O000O0O00O .loading_image_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"jwhk6qck.gif")#line:786
        O0OOO00O000O0O00O .avatar_image_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"avatar1.png")#line:787
        O0OOO00O000O0O00O .settings_menu_img =os .path .join (O0OOO00O000O0O00O .appdata_dir ,'home_menu.png')#line:788
        O0OOO00O000O0O00O .home_menu_img_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,'home_menu.png')#line:789
        O0OOO00O000O0O00O .how_it_works_menu_img_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,'how_it_works_menu.png')#line:790
        O0OOO00O000O0O00O .info_menu_img_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,'info_menu.png')#line:791
        O0OOO00O000O0O00O .logout_menu_img_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,'logout_menu.png')#line:792
        O0OOO00O000O0O00O .settings_menu_img_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,'settings_menu.png')#line:793
        O0OOO00O000O0O00O .not_available_img_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,'not_available.png')#line:794
        O0OOO00O000O0O00O .request_now_button_img_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,'request_now_button.png')#line:795
        O0OOO00O000O0O00O .threedee_model_not_available_img_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"3d_model_not_available_img.png")#line:796
        O0OOO00O000O0O00O .threedee_available_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"threedee_model_available.png")#line:797
        O0OOO00O000O0O00O .threedee_unavailable_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,"threedee_model_unavailable.png")#line:798
        if IS_UPDATED :#line:800
            O0OOO00O000O0O00O .update_menu_img_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,'update_menu.png')#line:801
        else :#line:802
            O0OOO00O000O0O00O .update_menu_img_dir =os .path .join (O0OOO00O000O0O00O .appdata_dir ,'notif_update_menu+(2).png')#line:803
        O0OOO00O000O0O00O .initialize_user_interface ()#line:805
    def download_component (O0O00O0OOO000OO0O ,O0000OOOOOOOO0OO0 ):#line:807
        global IS_PROMOTED #line:809
        if bool (random .getrandbits (1 ))and not IS_PROMOTED :#line:810
            IS_PROMOTED =True #line:811
            webbrowser .open ("https://delighted.com/t/JxbeJK7q",new =2 )#line:812
        if not O0O00O0OOO000OO0O .is_downloading :#line:813
            O0O00O0OOO000OO0O .is_downloading =True #line:814
            OO0O000O000OO00O0 =threading .Thread (target =O0O00O0OOO000OO0O .download_data )#line:815
            OO0O000O000OO00O0 .start ()#line:816
            O0O00O0OOO000OO0O .download_button .config (state ="disabled")#line:817
    def download_data (OO0OOOO00O000OOOO ):#line:820
        global IS_SETTING_WINDOW_OPEN #line:821
        OO0OOOO00O000OOOO .parent .is_download_complete =True #line:822
        O0O00O0O00OOO0OOO =""#line:824
        O0O0OOO0OO0OOO000 =os .path .dirname (os .path .realpath (__file__ ))#line:825
        if OO0OOOO00O000OOOO .is_windows or OO0OOOO00O000OOOO .is_mac :#line:827
            with open (os .path .join (OO0OOOO00O000OOOO .appdata_dir ,".token"),"r")as O00O0OOO0O0O0O00O :#line:828
                O0O00O0O00OOO0OOO =str (O00O0OOO0O0O0O00O .readline ())#line:829
        else :#line:830
            with open (os .path .join (O0O0OOO0OO0OOO000 ,".token"),"r")as O00O0OOO0O0O0O00O :#line:831
                O0O00O0O00OOO0OOO =str (O00O0OOO0O0O0O00O .readline ())#line:832
        O00OO0O0OO0000O00 ="https://www.snapeda.com/api/v1/parts/download_part"#line:833
        OOOOOOO00O0000OOO ={'User-Agent':"Kicad"}#line:834
        O000OO00O00O0O0O0 ={'part_number':str (OO0OOOO00O000OOOO .part_number ),'manufacturer':str (OO0OOOO00O000OOOO .manufacturer ),'has_symbol':OO0OOOO00O000OOOO .has_symbol ,'has_footprint':OO0OOOO00O000OOOO .has_footprint ,'uniqueid':OO0OOOO00O000OOOO .uniqueid ,'token':O0O00O0O00OOO0OOO ,'format':"kicad_mod",'ref':"kicad-plugin",}#line:844
        try :#line:846
            if sys .version_info [0 ]==3 :#line:847
                O0O0OO0O000O00OO0 =urllib .parse .urlencode (O000OO00O00O0O0O0 ).encode ("utf-8")#line:848
                O0OOO00O00O0O0O00 =urllib .request .Request (O00OO0O0OO0000O00 ,O0O0OO0O000O00OO0 ,headers =OOOOOOO00O0000OOO )#line:849
                O0O000O0O0OO000OO =urllib .request .urlopen (O0OOO00O00O0O0O00 ).read ()#line:850
            else :#line:851
                O0O0OO0O000O00OO0 =urllib .urlencode (O000OO00O00O0O0O0 )#line:852
                O0OOO00O00O0O0O00 =urllib2 .Request (O00OO0O0OO0000O00 ,O0O0OO0O000O00OO0 ,headers =OOOOOOO00O0000OOO )#line:853
                O0O000O0O0OO000OO =urllib2 .urlopen (O0OOO00O00O0O0O00 ).read ()#line:854
        except :#line:855
            OO0OOOO00O000OOOO .download_button .config (state ="normal",text ="Download")#line:857
            OO0OOOO00O000OOOO .is_downloading =False #line:858
            OO0OOOO00O000OOOO .parent .is_download_complete =False #line:859
            if IS_SETTING_WINDOW_OPEN is False :#line:860
                OO0OOOO00O000OOOO .parent .is_help_me_window =False #line:861
                AfterDownloadView (OO0OOOO00O000OOOO .parent )#line:862
            return #line:863
        OO0OOOO00O000OOOO .download_url =json .loads (O0O000O0O0OO000OO )["url"]#line:864
        print (OO0OOOO00O000OOOO .download_url )#line:865
        OOOOOOO00O0000OOO ={'User-Agent':"Kicad"}#line:866
        if len (OO0OOOO00O000OOOO .download_url )==0 :#line:867
            OO0OOOO00O000OOOO .download_button .config (state ="normal",text ="Download")#line:869
            OO0OOOO00O000OOOO .is_downloading =False #line:870
            OO0OOOO00O000OOOO .parent .is_download_complete =False #line:871
            if IS_SETTING_WINDOW_OPEN is False :#line:872
                OO0OOOO00O000OOOO .parent .is_help_me_window =False #line:873
                AfterDownloadView (OO0OOOO00O000OOOO .parent )#line:874
            return #line:875
        OO0OOOO00O000OOOO .part_number =OO0OOOO00O000OOOO .part_number .replace ('/','_')#line:876
        if sys .version_info [0 ]==3 :#line:877
            OOO0OOOOO0O0000OO =urllib .request .Request (OO0OOOO00O000OOOO .download_url ,headers =OOOOOOO00O0000OOO )#line:878
            O0OO00000OO00O0O0 =urllib .request .urlopen (OOO0OOOOO0O0000OO )#line:879
        else :#line:880
            OOO0OOOOO0O0000OO =urllib2 .Request (OO0OOOO00O000OOOO .download_url ,headers =OOOOOOO00O0000OOO )#line:881
            O0OO00000OO00O0O0 =urllib2 .urlopen (OOO0OOOOO0O0000OO )#line:882
        OO000OO0OO0OO0O0O =os .path .join (OO0OOOO00O000OOOO .appdata_dir ,"info.json")#line:884
        O0O0OO0O000O00OO0 ={}#line:885
        with open (OO000OO0OO0OO0O0O )as O000OO0OO00O0O0O0 :#line:886
            O0O0OO0O000O00OO0 =json .load (O000OO0OO00O0O0O0 )#line:887
        OO0OOOO00O000OOOO .kicad_library_dir =O0O0OO0O000O00OO0 ['kicad_library_dir']#line:889
        OO0OOOO00O000OOOO .snapeda_library_dir =os .path .join (OO0OOOO00O000OOOO .kicad_library_dir ,O0O0OO0O000O00OO0 ['kicad_library_name'])#line:890
        OO0OOOO00O000OOOO .snapeda_library_abs_dir =os .path .join (OO0OOOO00O000OOOO .kicad_library_dir ,O0O0OO0O000O00OO0 ['kicad_library_name']+'.pretty')#line:891
        O00000O00000O0OOO =os .path .join (OO0OOOO00O000OOOO .kicad_library_dir ,'temp')#line:892
        OOO000OO000O00000 =os .path .join (O00000O00000O0OOO ,str (OO0OOOO00O000OOOO .part_number ))#line:893
        if not os .path .exists (OO0OOOO00O000OOOO .kicad_library_dir ):#line:894
            os .makedirs (OO0OOOO00O000OOOO .kicad_library_dir )#line:895
        if not os .path .exists (OO0OOOO00O000OOOO .snapeda_library_dir ):#line:896
            os .makedirs (OO0OOOO00O000OOOO .snapeda_library_dir )#line:897
        if not os .path .exists (OOO000OO000O00000 ):#line:898
            os .makedirs (OOO000OO000O00000 )#line:899
        if not os .path .exists (OO0OOOO00O000OOOO .snapeda_library_abs_dir ):#line:900
            os .makedirs (OO0OOOO00O000OOOO .snapeda_library_abs_dir )#line:901
        with open (os .path .join (OOO000OO000O00000 ,OO0OOOO00O000OOOO .part_number +".zip"),"wb")as O00O0OOO0O0O0O00O :#line:902
            shutil .copyfileobj (O0OO00000OO00O0O0 ,O00O0OOO0O0O0O00O )#line:903
        with zipfile .ZipFile (os .path .join (OOO000OO000O00000 ,OO0OOOO00O000OOOO .part_number +".zip"))as OO00000000OO0O0O0 :#line:905
            OO00000000OO0O0O0 .extractall (OOO000OO000O00000 )#line:906
        for O00000OO000O000OO in os .listdir (OOO000OO000O00000 ):#line:938
            if O00000OO000O000OO .endswith (".step"):#line:940
                OO0O000000O000OOO =os .path .join (OOO000OO000O00000 ,O00000OO000O000OO )#line:942
                copyfile (OO0O000000O000OOO ,os .path .join (OO0OOOO00O000OOOO .snapeda_threedee_models_dir ,O00000OO000O000OO ))#line:943
            if O00000OO000O000OO .endswith (".kicad_mod"):#line:945
                OO0OOOO00O000OOOO .kicad_mod_filename =O00000OO000O000OO [:-10 ]#line:946
                O0O0O00O0OO00O0O0 =os .path .join (OOO000OO000O00000 ,O00000OO000O000OO )#line:947
                copyfile (O0O0O00O0OO00O0O0 ,os .path .join (OO0OOOO00O000OOOO .snapeda_library_abs_dir ,O00000OO000O000OO ))#line:948
            if O00000OO000O000OO .endswith (".lib"):#line:950
                O00OO0O0O0O00OOO0 =False #line:952
                with open (os .path .join (OOO000OO000O00000 ,O00000OO000O000OO ),"r+")as O00O0OOO0O0O0O00O :#line:953
                    O0O000O0O0OO000OO =O00O0OOO0O0O0O00O .readlines ()#line:954
                    OOOOO0OO0OOOO00O0 =[]#line:955
                    for OO00000OOOOOO0O00 in O0O000O0O0OO000OO :#line:956
                        if 'F2 "'in OO00000OOOOOO0O00 :#line:957
                            O0O000O0O00O0OO00 =OO00000OOOOOO0O00 .split ('"')#line:958
                            OO0O0O00OO000O0OO =O0O000O0O00O0OO00 [0 ]+'"'+O0O0OO0O000O00OO0 ['kicad_library_name']+':'+O0O000O0O00O0OO00 [1 ]+'"'+O0O000O0O00O0OO00 [2 ]#line:959
                            OO00000OOOOOO0O00 =OO0O0O00OO000O0OO #line:960
                            O00OO0O0O0O00OOO0 =True #line:961
                        OOOOO0OO0OOOO00O0 +=OO00000OOOOOO0O00 #line:962
                if O00OO0O0O0O00OOO0 :#line:963
                    with open (os .path .join (OOO000OO000O00000 ,O00000OO000O000OO ),"w")as O00O0OOO0O0O0O00O :#line:964
                        O00O0OOO0O0O0O00O .writelines (OOOOO0OO0OOOO00O0 )#line:965
                O0OOO000O00000OO0 =os .path .join (OOO000OO000O00000 ,O00000OO000O000OO )#line:967
                copyfile (O0OOO000O00000OO0 ,os .path .join (OO0OOOO00O000OOOO .snapeda_library_dir ,O00000OO000O000OO ))#line:968
                if OO0OOOO00O000OOOO .is_windows :#line:970
                    OO0OOOO00O000OOOO .sym_lib_table_dir =os .path .join (os .getenv ('APPDATA'),'kicad','sym-lib-table')#line:973
                else :#line:974
                    OO0OOOO00O000OOOO .sym_lib_table_dir =os .path .join (os .path .expanduser ("~"),'.config','kicad','sym-lib-table')#line:978
                if (os .path .exists (OO0OOOO00O000OOOO .sym_lib_table_dir )!=True ):#line:980
                    O0OO0OOO0O00O00O0 ='(sym_lib_table\n\n)'#line:981
                    with open (OO0OOOO00O000OOOO .sym_lib_table_dir ,'w')as O0O0OOO0O0O0O00OO :#line:982
                        O0O0OOO0O0O0O00OO .write (O0OO0OOO0O00O00O0 )#line:983
                        O0O0OOO0O0O0O00OO .close #line:984
                with open (OO0OOOO00O000OOOO .sym_lib_table_dir ,"r+")as O00O0OOO0O0O0O00O :#line:986
                    O0000O00OOOOOO00O =O00O0OOO0O0O0O00O .read ()#line:987
                    OO0O0O00OO000O0OO =('  (lib (name '+os .path .splitext (O00000OO000O000OO )[0 ]+')(type Legacy)(uri "'+OO0OOOO00O000OOOO .snapeda_library_dir +'\\'+str (O00000OO000O000OO )+'")(options "")(descr ""))')#line:988
                    OO0O0O00OO000O0OO =OO0O0O00OO000O0OO .replace ("'","")#line:989
                    OO0O0O00OO000O0OO =OO0O0O00OO000O0OO .replace ("\\","/")#line:990
                    if OO0O0O00OO000O0OO not in O0000O00OOOOOO00O :#line:991
                        OO0O0O00OO000O0OO =('  (lib (name '+os .path .splitext (O00000OO000O000OO )[0 ]+')(type Legacy)(uri "'+OO0OOOO00O000OOOO .snapeda_library_dir +'\\'+str (O00000OO000O000OO )+'")(options "")(descr ""))')+"\n\n)"#line:992
                        OO0O0O00OO000O0OO =OO0O0O00OO000O0OO .replace ("'","")#line:993
                        OO0O0O00OO000O0OO =OO0O0O00OO000O0OO .replace ("\\","/")#line:994
                        OO000O0O000000OO0 =O0000O00OOOOOO00O [:-2 ]+OO0O0O00OO000O0OO #line:995
                        O00O0OOO0O0O0O00O .seek (0 )#line:996
                        O00O0OOO0O0O0O00O .write (OO000O0O000000OO0 )#line:997
                        O00O0OOO0O0O0O00O .truncate ()#line:998
        shutil .rmtree (O00000O00000O0OOO )#line:1000
        OO0OOOO00O000OOOO .download_button .config (state ="normal",text ="Download")#line:1152
        OO0OOOO00O000OOOO .is_downloading =False #line:1153
        if IS_SETTING_WINDOW_OPEN is False :#line:1154
            OO0OOOO00O000OOOO .parent .is_help_me_window =False #line:1155
            AfterDownloadView (OO0OOOO00O000OOOO .parent ,OO0OOOO00O000OOOO .flip_table_dir ,OO0OOOO00O000OOOO .proj_flip_table_dir ,OO0OOOO00O000OOOO .snapeda_library_abs_dir ,OO0OOOO00O000OOOO .kicad_mod_filename )#line:1156
    def winapi_path (OO000000OOO000OOO ,O0O00O0O0000O00O0 ,encoding =None ):#line:1158
        if (not isinstance (O0O00O0O0000O00O0 ,unicode )and encoding is not None ):#line:1159
            O0O00O0O0000O00O0 =O0O00O0O0000O00O0 .decode (encoding )#line:1160
        OO00O0O00OO00O0O0 =os .path .abspath (O0O00O0O0000O00O0 )#line:1161
        if OO00O0O00OO00O0O0 .startswith (u"\\\\"):#line:1162
            return u"\\\\?\\UNC\\"+OO00O0O00OO00O0O0 [2 :]#line:1163
        return u"\\\\?\\"+OO00O0O00OO00O0O0 #line:1164
    def contact_us (O00OO0O0OOOOOOOOO ):#line:1166
        webbrowser .open ("https://www.snapeda.com/about/#contact_us",new =2 )#line:1167
    def about_snapeda (OOOO0OO000O0OO0O0 ):#line:1169
        webbrowser .open ("https://www.snapeda.com/about/",new =2 )#line:1170
    def view_on_snapeda (OO00O00OO00OOO0O0 ,O00O0O000000OO00O ):#line:1172
        webbrowser .open ("https://www.snapeda.com%s?ref=kicad"%(O00O0O000000OO00O [:-10 ]+'datasheet/'),new =2 )#line:1173
    def how_it_works_callback (O0O0O00O00OO00000 ,O0O0OO0000OO000OO ):#line:1175
        global IS_SETTING_WINDOW_OPEN #line:1176
        if IS_SETTING_WINDOW_OPEN is False :#line:1177
            O0O0O00O00OO00000 .parent .is_help_me_window =False #line:1178
            InfoView (O0O0O00O00OO00000 .parent )#line:1179
    def logout_callback (O0OO0OOOOOOO00OO0 ,OO0O00OOOOOO00000 ):#line:1191
        try :#line:1192
            if O0OO0OOOOOOO00OO0 .is_windows :#line:1193
                O0OO0OOOOOOO00OO0 .windata_dir =os .path .join (os .getenv ('HOMEDRIVE'),os .getenv ('HOMEPATH'),"SnapEDA Kicad Plugin")#line:1196
                O0OO0OOOOOOO00OO0 .appdata_dir =os .path .join (O0OO0OOOOOOO00OO0 .windata_dir ,"App")#line:1197
                OO0000OO000O000OO =os .path .join (O0OO0OOOOOOO00OO0 .appdata_dir ,".token")#line:1198
                os .remove (OO0000OO000O000OO )#line:1199
            elif O0OO0OOOOOOO00OO0 .is_mac :#line:1200
                O0OO0OOOOOOO00OO0 .macdata_dir =os .path .join (os .path .expanduser ("~"),"Documents","SnapEDA Kicad Plugin")#line:1201
                O0OO0OOOOOOO00OO0 .appdata_dir =os .path .join (O0OO0OOOOOOO00OO0 .macdata_dir ,"App")#line:1202
                OO0000OO000O000OO =os .path .join (O0OO0OOOOOOO00OO0 .appdata_dir ,".token")#line:1203
                os .remove (OO0000OO000O000OO )#line:1204
            else :#line:1205
                O0OO0OOOOOOO00OO0 .dir_path =os .path .dirname (os .path .realpath (__file__ ))#line:1206
                OO0000OO000O000OO =os .path .join (O0OO0OOOOOOO00OO0 .dir_path ,".token")#line:1207
                os .remove (OO0000OO000O000OO )#line:1208
        except :#line:1209
            print ('Error removing token.')#line:1210
        for OOOO000OO0O000000 in range (5 ):#line:1211
            for OO00O0OO000O0OOOO in O0OO0OOOOOOO00OO0 .parent .grid_slaves (row =OOOO000OO0O000000 ,column =0 ):#line:1212
                OO00O0OO000O0OOOO .destroy ()#line:1213
        LoginScreen (O0OO0OOOOOOO00OO0 .master )#line:1214
        return #line:1215
    def update_process (OO00O0000OO0OOO00 ):#line:1217
        OO00O0000OO0OOO00 .status_text .set ("Downloading update...")#line:1219
        O0O00OOO0000OO000 =os .path .join (OO00O0000OO0OOO00 .kicad_library_dir ,'temp')#line:1220
        if not os .path .exists (O0O00OOO0000OO000 ):#line:1221
                os .makedirs (O0O00OOO0000OO000 )#line:1222
        if sys .version_info [0 ]==3 :#line:1223
            with urllib .request .urlopen ('https://snapeda.s3.amazonaws.com/plugins/kicad/SnapEDA-KiCad-Plugin.zip')as OO00O0O0OO0O00000 ,open (os .path .join (O0O00OOO0000OO000 ,'SnapEDA-KiCad-Plugin.zip'),'wb')as O0OOO0OOOO0O0O0O0 :#line:1224
                shutil .copyfileobj (OO00O0O0OO0O00000 ,O0OOO0OOOO0O0O0O0 )#line:1225
        else :#line:1226
            OO0OO000O0000O000 =urllib2 .urlopen ('https://snapeda.s3.amazonaws.com/plugins/kicad/SnapEDA-KiCad-Plugin.zip')#line:1227
            with open (os .path .join (O0O00OOO0000OO000 ,'SnapEDA-KiCad-Plugin.zip'),"wb")as OO0O0O00O00O0OO00 :#line:1228
                shutil .copyfileobj (OO0OO000O0000O000 ,OO0O0O00O00O0OO00 )#line:1229
        OO00O0000OO0OOO00 .status_text .set ("Extracting package...")#line:1231
        with zipfile .ZipFile (os .path .join (O0O00OOO0000OO000 ,'SnapEDA-KiCad-Plugin.zip'))as O0000OO0OOOO0OO00 :#line:1233
            O0000OO0OOOO0OO00 .extractall (O0O00OOO0000OO000 )#line:1234
        OO00O0000OO0OOO00 .status_text .set ("Copying files...")#line:1236
        for OOOO00O0OO00OOO0O in os .listdir (O0O00OOO0000OO000 ):#line:1238
            if OOOO00O0OO00OOO0O .endswith (".py"):#line:1239
                copyfile (os .path .join (O0O00OOO0000OO000 ,OOOO00O0OO00OOO0O ),os .path .join (os .path .dirname (os .path .realpath (__file__ )),OOOO00O0OO00OOO0O ))#line:1240
        shutil .rmtree (O0O00OOO0000OO000 )#line:1242
        OO00O0000OO0OOO00 .status_text .set ("Update complete.")#line:1244
        OO00O0000OO0OOO00 .header_text .set ("UPDATE COMPLETE")#line:1246
        OO00O0000OO0OOO00 .subheader_text .set ("Update successful. Please restart SnapEDA, refresh the plugins, then open SnapEDA.")#line:1247
        OO00O0000OO0OOO00 .status_text .set ("")#line:1248
    def update_callback (OO0O00O0O0000OO0O ,OO00000000OO0OOOO ):#line:1251
        try :#line:1253
            OO00O0OOO0OOOO0O0 =os .getuid ()==0 #line:1254
        except AttributeError :#line:1255
            OO00O0OOO0OOOO0O0 =ctypes .windll .shell32 .IsUserAnAdmin ()!=0 #line:1256
        if not OO00O0OOO0OOOO0O0 :#line:1258
            if OO0O00O0O0000OO0O .is_windows :#line:1259
                tkMessageBox .showwarning ("Update","Please restart KiCAD as administrator, then update again.")#line:1260
                return #line:1261
        OO0O00O0O0000OO0O .update_container =tk .Frame (OO0O00O0O0000OO0O .parent ,bg ="#ff761a")#line:1266
        OO0O00O0O0000OO0O .update_container .grid (row =0 ,column =0 ,sticky ="NEWS")#line:1267
        OO0O00O0O0000OO0O .update_container .grid_columnconfigure (0 ,weight =1 )#line:1268
        for OOOO000O00OO0O000 in range (4 ):#line:1269
            OO0O00O0O0000OO0O .update_container .grid_rowconfigure (OOOO000O00OO0O000 ,weight =1 ,uniform ="foo")#line:1270
        OO0O00O0O0000OO0O .header_container =tk .Frame (OO0O00O0O0000OO0O .update_container ,bg ="#ff761a")#line:1272
        OO0O00O0O0000OO0O .header_container .grid (row =1 ,column =0 ,columnspan =1 ,sticky ="NEWS")#line:1273
        OO0O00O0O0000OO0O .header_container .grid_columnconfigure (0 ,weight =1 )#line:1274
        for OOOO000O00OO0O000 in range (3 ):#line:1275
            OO0O00O0O0000OO0O .header_container .grid_rowconfigure (OOOO000O00OO0O000 ,weight =1 ,uniform ="foo")#line:1276
        OO0O00O0O0000OO0O .header_text =tk .StringVar ()#line:1278
        OO0O00O0O0000OO0O .header_text .set ("UPDATING...")#line:1279
        OO0O00O0O0000OO0O .header_label =tk .Label (OO0O00O0O0000OO0O .header_container ,bg ="#ff761a",fg ="white",textvariable =OO0O00O0O0000OO0O .header_text ,justify =tk .CENTER ,font =("Open Sans","18","bold"))#line:1280
        OO0O00O0O0000OO0O .header_label .grid (row =0 ,column =0 ,columnspan =1 ,sticky ="NEWS")#line:1281
        OO0O00O0O0000OO0O .subheader_text =tk .StringVar ()#line:1283
        OO0O00O0O0000OO0O .subheader_text .set ("This may take a while, about 3-5 minutes. Mind to have a coffee break?")#line:1284
        OO0O00O0O0000OO0O .subheader_label =tk .Label (OO0O00O0O0000OO0O .header_container ,textvariable =OO0O00O0O0000OO0O .subheader_text ,fg ="white",bg ="#ff761a",font =("Open Sans","13"))#line:1285
        OO0O00O0O0000OO0O .subheader_label .grid (row =1 ,column =0 ,sticky ="NEW")#line:1286
        OO0O00O0O0000OO0O .status_text =tk .StringVar ()#line:1288
        OO0O00O0O0000OO0O .status_text .set ("Starting update...")#line:1289
        OO0O00O0O0000OO0O .status_label =tk .Label (OO0O00O0O0000OO0O .header_container ,textvariable =OO0O00O0O0000OO0O .status_text ,fg ="white",bg ="#ff761a",font =("Open Sans","13","italic"))#line:1290
        OO0O00O0O0000OO0O .status_label .grid (row =2 ,column =0 ,sticky ="NEW")#line:1291
        OO0O00O0O0000OO0O .update_thread =threading .Thread (target =OO0O00O0O0000OO0O .update_process )#line:1293
        OO0O00O0O0000OO0O .update_thread .setDaemon (True )#line:1294
        OO0O00O0O0000OO0O .update_thread .start ()#line:1295
    def help_me_callback (OO0O0O0O00000OOO0 ,OO000OO0OO0OO0O00 ):#line:1297
        global IS_SETTING_WINDOW_OPEN #line:1298
        if IS_SETTING_WINDOW_OPEN is False :#line:1299
            OO0O0O0O00000OOO0 .parent .is_help_me_window =True #line:1300
            InfoView (OO0O0O0O00000OOO0 .parent )#line:1301
    def home_callback (OOO000O000O00OOO0 ,O0O0OO000O0OO0OO0 ):#line:1305
        for OO00O00O00O0O0000 in range (5 ):#line:1306
            for O0OO0OOOO00O00O00 in OOO000O000O00OOO0 .parent .grid_slaves (row =OO00O00O00O0O0000 ,column =0 ):#line:1307
                O0OO0OOOO00O00O00 .destroy ()#line:1308
        WelcomeScreen (OOO000O000O00OOO0 .parent )#line:1309
    def setting_callback (OO0O0OO000OO000OO ,O00OOOO0OO00OO00O ):#line:1311
        global IS_SETTING_WINDOW_OPEN #line:1312
        if IS_SETTING_WINDOW_OPEN is False :#line:1313
            SettingsView (OO0O0OO000OO000OO .parent )#line:1314
    def next_page (O0O00O00OO0O0O00O ,OO00O0O00OOOOOO0O ):#line:1316
        if O0O00O00OO0O0O00O .current_page <O0O00O00OO0O0O00O .max_page :#line:1317
            O0O00O00OO0O0O00O .current_page +=1 #line:1318
            O0O00O00OO0O0O00O .search_data (OO00O0O00OOOOOO0O ,current_page =O0O00O00OO0O0O00O .current_page )#line:1319
    def prev_page (O00OOO00OOOO0O0O0 ,OOO0000OOOOO00O0O ):#line:1321
        if O00OOO00OOOO0O0O0 .current_page >1 :#line:1322
            O00OOO00OOOO0O0O0 .current_page -=1 #line:1323
            O00OOO00OOOO0O0O0 .search_data (OOO0000OOOOO00O0O ,current_page =O00OOO00OOOO0O0O0 .current_page )#line:1324
    def on_tree_select (OOOO00O0O0O0O000O ,OOOO0OO00O00OOOOO ,index =None ):#line:1327
        if not OOOO00O0O0O0O000O .is_loading :#line:1332
            OOOO00O0O0O0O000O .is_loading =True #line:1333
            OOOO00O0O0O0O000O .get_component_thread =threading .Thread (target =OOOO00O0O0O0O000O .get_component ,args =(OOOO0OO00O00OOOOO ,index ))#line:1337
            OOOO00O0O0O0O000O .get_component_thread .start ()#line:1338
    def model_2D_callback (O0O0O0OO000OOOOOO ,O00OO000O0OO0O0OO ,O0O00OO00O00000O0 ):#line:1342
        global IS_3D_TAB_OPEN #line:1343
        IS_3D_TAB_OPEN =False #line:1344
        O0O0O0OO000OOOOOO .model_3D_underline .destroy ()#line:1346
        O0O0O0OO000OOOOOO .model_3D_text .configure (bg ="#EEEEEE",fg ="#333333")#line:1347
        O0O0O0OO000OOOOOO .model_3D_text .grid (row =0 ,column =1 ,sticky ="NEWS",padx =1 ,pady =1 )#line:1348
        O0O0O0OO000OOOOOO .model_3D_text .bind ('<Button-1>',lambda OO0O0O0O00O00000O ,index =O0O00OO00O00000O0 :O0O0O0OO000OOOOOO .model_3D_callback (OO0O0O0O00O00000O ,index ))#line:1349
        O0O0O0OO000OOOOOO .model_2D_underline =tk .Label (O0O0O0OO000OOOOOO .model_tab_frame ,bg ="#FF761A")#line:1351
        O0O0O0OO000OOOOOO .model_2D_underline .grid (row =0 ,column =0 ,sticky ="NEWS",pady =(1 ,0 ),padx =1 )#line:1352
        O0O0O0OO000OOOOOO .model_2D_text .destroy ()#line:1353
        O0O0O0OO000OOOOOO .model_2D_text =tk .Label (O0O0O0OO000OOOOOO .model_tab_frame ,bg ="white",fg ="#FF761A",text ="2D Model",font =("Open Sans",10 ),cursor ="hand2")#line:1354
        O0O0O0OO000OOOOOO .model_2D_text .grid (row =0 ,column =0 ,sticky ="NEWS",padx =1 ,pady =(1 ,4 ))#line:1355
        O0O0O0OO000OOOOOO .symbol_view .destroy ()#line:1358
        O0O0O0OO000OOOOOO .symbol_frame =tk .Frame (O0O0O0OO000OOOOOO .details_frame ,bg ="white")#line:1360
        O0O0O0OO000OOOOOO .symbol_frame .grid (row =4 ,column =0 ,rowspan =3 ,sticky ="NEWS",padx =1 ,pady =(0 ,1 ))#line:1361
        O0O0O0OO000OOOOOO .symbol_frame .grid_columnconfigure (0 ,weight =1 )#line:1362
        O0O0O0OO000OOOOOO .symbol_frame .grid_rowconfigure (0 ,weight =1 )#line:1363
        O0O0O0OO000OOOOOO .model_canvas =tk .Canvas (O0O0O0OO000OOOOOO .symbol_frame ,bg ="white")#line:1365
        O0O0O0OO000OOOOOO .model_canvas .grid (row =0 ,column =0 ,sticky ="NEWS")#line:1366
        OO0O0O0000000O0O0 =ttk .Style ()#line:1367
        OO0O0O0000000O0O0 .theme_use ('clam')#line:1368
        OO0O0O0000000O0O0 .configure ("snapeda.Vertical.TScrollbar",gripcount =0 ,background ="#FF8330",troughcolor ='#C4C4C4',lightcolor ='#C4C4C4',darkcolor ='#C4C4C4',bordercolor ="#C4C4C4",borderwidth =0 ,relief =tk .FLAT )#line:1369
        OO0O0O0000000O0O0 .map ('snapeda.Vertical.TScrollbar',foreground =[('disabled','#C4C4C4'),('pressed','#FF8330'),('active','#FF8330')],background =[('disabled','#C4C4C4'),('pressed','!focus','#FF8330'),('active','#FF8330')],highlightcolor =[('focus','#C4C4C4'),('!focus','#C4C4C4')],)#line:1377
        OO0O0O0000000O0O0 .layout ('snapeda.Vertical.TScrollbar',[('Vertical.Scrollbar.trough',{'children':[('Vertical.Scrollbar.thumb',{'expand':'1','sticky':'nswe'})],'sticky':'ns'})])#line:1379
        O0O0O0OO000OOOOOO .model_scrollbar =ttk .Scrollbar (O0O0O0OO000OOOOOO .symbol_frame ,orient ="vertical",command =O0O0O0OO000OOOOOO .model_canvas .yview ,style ="snapeda.Vertical.TScrollbar")#line:1380
        O0O0O0OO000OOOOOO .model_scrollbar .grid (row =0 ,column =1 ,sticky ='NS')#line:1381
        O0O0O0OO000OOOOOO .model_frame =tk .Frame (O0O0O0OO000OOOOOO .model_canvas ,bg ="white")#line:1382
        O0O0O0OO000OOOOOO .model_frame .bind ("<Configure>",lambda O0O00O0OOOOOOOOO0 :O0O0O0OO000OOOOOO .model_canvas .configure (scrollregion =O0O0O0OO000OOOOOO .model_canvas .bbox ("all")))#line:1383
        O0O0O0OO000OOOOOO .model_canvas .create_window ((0 ,0 ),window =O0O0O0OO000OOOOOO .model_frame ,anchor =tk .CENTER )#line:1384
        O0O0O0OO000OOOOOO .model_canvas .configure (yscrollcommand =O0O0O0OO000OOOOOO .model_scrollbar .set )#line:1385
        if O0O0O0OO000OOOOOO .has_model :#line:1387
            O0O0O0OO000OOOOOO .symbol_view =tk .Label (O0O0O0OO000OOOOOO .model_frame ,bg ="white",image =O0O0O0OO000OOOOOO .symbol_image )#line:1388
            O0O0O0OO000OOOOOO .symbol_view .grid (row =0 ,column =0 ,sticky ="NEWS",padx =(65 ,65 ))#line:1389
        else :#line:1390
            O0O0O0OO000OOOOOO .symbol_view =tk .Frame (O0O0O0OO000OOOOOO .model_frame ,bg ="white")#line:1391
            O0O0O0OO000OOOOOO .symbol_view .columnconfigure (0 ,weight =1 ,uniform ='foo')#line:1392
            O0O0O0OO000OOOOOO .symbol_view .grid (row =0 ,column =0 ,sticky ='NEWS',padx =(60 ,60 ))#line:1393
            tk .Label (O0O0O0OO000OOOOOO .symbol_view ,bg ="white",image =O0O0O0OO000OOOOOO .ghost_2D_im ).grid (row =0 ,column =0 ,sticky ="NEWS")#line:1394
            O0O0O0OO000OOOOOO .request_button =tk .Label (O0O0O0OO000OOOOOO .symbol_view ,bg ="white",image =O0O0O0OO000OOOOOO .request_button_img ,cursor ="hand2")#line:1395
            O0O0O0OO000OOOOOO .request_button .grid (row =1 ,column =0 ,sticky ="NEWS",pady =(0 ,60 ))#line:1396
            O0O0O0OO000OOOOOO .request_button .bind ('<Button-1>',O0O0O0OO000OOOOOO .request_now_button_callback )#line:1397
        if O0O0O0OO000OOOOOO .has_package :#line:1399
            O0O0O00000O0O00O0 =tk .Label (O0O0O0OO000OOOOOO .model_frame ,bg ="white",image =O0O0O0OO000OOOOOO .package_image )#line:1400
            O0O0O00000O0O00O0 .grid (row =1 ,column =0 ,sticky ="NEWS")#line:1401
        else :#line:1402
            O0O0O00000O0O00O0 =tk .Frame (O0O0O0OO000OOOOOO .model_frame ,bg ="white")#line:1403
            O0O0O00000O0O00O0 .columnconfigure (0 ,weight =1 ,uniform ='foo')#line:1404
            O0O0O00000O0O00O0 .rowconfigure (0 ,weight =2 ,uniform ='foo')#line:1405
            O0O0O00000O0O00O0 .rowconfigure (0 ,weight =1 ,uniform ='foo')#line:1406
            O0O0O00000O0O00O0 .grid (row =1 ,column =0 ,sticky ='NEWS')#line:1407
            tk .Label (O0O0O00000O0O00O0 ,bg ="white",image =O0O0O0OO000OOOOOO .ghost_im ).grid (row =0 ,column =0 ,sticky ="NEWS")#line:1408
            tk .Label (O0O0O00000O0O00O0 ,bg ="white",text ='No Package',font =("Open Sans",11 )).grid (row =1 ,column =0 ,sticky ="NEWS",pady =(0 ,15 ))#line:1409
        O0O0O0OO000OOOOOO .model_frame .update_idletasks ()#line:1411
        O0O0O0OO000OOOOOO .model_tab_frame .update_idletasks ()#line:1412
    def model_3D_callback (O00O0O00O0O00O000 ,OOOO0OO0O0000O0OO ,O000OOOO0OOOO0000 ):#line:1414
        global IS_3D_TAB_OPEN #line:1415
        IS_3D_TAB_OPEN =True #line:1416
        O00O0O00O0O00O000 .symbol_view .destroy ()#line:1418
        O00O0O00O0O00O000 .symbol_frame =tk .Frame (O00O0O00O0O00O000 .details_frame ,bg ="white")#line:1420
        O00O0O00O0O00O000 .symbol_frame .grid (row =4 ,column =0 ,rowspan =3 ,sticky ="NEWS",padx =1 ,pady =(0 ,1 ))#line:1421
        O00O0O00O0O00O000 .symbol_frame .grid_columnconfigure (0 ,weight =1 )#line:1422
        O00O0O00O0O00O000 .symbol_frame .grid_rowconfigure (0 ,weight =1 )#line:1423
        O00O0O00O0O00O000 .model_canvas =tk .Canvas (O00O0O00O0O00O000 .symbol_frame ,bg ="white")#line:1425
        O00O0O00O0O00O000 .model_canvas .grid (row =0 ,column =0 ,sticky ="NEWS")#line:1426
        O000O0O00OO0OOO00 =ttk .Style ()#line:1427
        O000O0O00OO0OOO00 .theme_use ('clam')#line:1428
        O000O0O00OO0OOO00 .configure ("snapeda.Vertical.TScrollbar",gripcount =0 ,background ="#FF8330",troughcolor ='#C4C4C4',lightcolor ='#C4C4C4',darkcolor ='#C4C4C4',bordercolor ="#C4C4C4",borderwidth =0 ,relief =tk .FLAT )#line:1429
        O000O0O00OO0OOO00 .map ('snapeda.Vertical.TScrollbar',foreground =[('disabled','#C4C4C4'),('pressed','#FF8330'),('active','#FF8330')],background =[('disabled','#C4C4C4'),('pressed','!focus','#FF8330'),('active','#FF8330')],highlightcolor =[('focus','#C4C4C4'),('!focus','#C4C4C4')],)#line:1437
        O000O0O00OO0OOO00 .layout ('snapeda.Vertical.TScrollbar',[('Vertical.Scrollbar.trough',{'children':[('Vertical.Scrollbar.thumb',{'expand':'1','sticky':'nswe'})],'sticky':'ns'})])#line:1439
        O00O0O00O0O00O000 .model_scrollbar =ttk .Scrollbar (O00O0O00O0O00O000 .symbol_frame ,orient ="vertical",command =O00O0O00O0O00O000 .model_canvas .yview ,style ="snapeda.Vertical.TScrollbar")#line:1440
        O00O0O00O0O00O000 .model_scrollbar .grid (row =0 ,column =1 ,sticky ='NS')#line:1441
        O00O0O00O0O00O000 .model_frame =tk .Frame (O00O0O00O0O00O000 .model_canvas ,bg ="white")#line:1442
        O00O0O00O0O00O000 .model_frame .bind ("<Configure>",lambda O00O00O0000O00OOO :O00O0O00O0O00O000 .model_canvas .configure (scrollregion =O00O0O00O0O00O000 .model_canvas .bbox ("all")))#line:1443
        O00O0O00O0O00O000 .model_canvas .create_window ((0 ,0 ),window =O00O0O00O0O00O000 .model_frame ,anchor =tk .CENTER )#line:1444
        O00O0O00O0O00O000 .model_canvas .configure (yscrollcommand =O00O0O00O0O00O000 .model_scrollbar .set )#line:1445
        O00O0O00O0O00O000 .threedee_text =tk .StringVar ()#line:1448
        O00O0O00O0O00O000 .threedee_text .set ("Please wait for the 3D image to load.")#line:1449
        tk .Label (O00O0O00O0O00O000 .model_frame ,bg ="white",textvariable =O00O0O00O0O00O000 .threedee_text ).grid (row =0 ,column =0 ,sticky ="NEWS")#line:1450
        O00O0O00O0O00O000 .model_2D_underline .destroy ()#line:1454
        O00O0O00O0O00O000 .model_2D_text .configure (bg ="#EEEEEE",fg ="#333333")#line:1455
        O00O0O00O0O00O000 .model_2D_text .grid (row =0 ,column =0 ,sticky ="NEWS",padx =1 ,pady =1 )#line:1456
        O00O0O00O0O00O000 .model_2D_text .bind ('<Button-1>',lambda O0OOO0O0O0O00O00O ,index =O000OOOO0OOOO0000 :O00O0O00O0O00O000 .model_2D_callback (O0OOO0O0O0O00O00O ,index ))#line:1457
        O00O0O00O0O00O000 .model_3D_underline =tk .Label (O00O0O00O0O00O000 .model_tab_frame ,bg ="#FF761A")#line:1459
        O00O0O00O0O00O000 .model_3D_underline .grid (row =0 ,column =1 ,sticky ="NEWS",pady =(1 ,0 ),padx =1 )#line:1460
        O00O0O00O0O00O000 .model_3D_text .destroy ()#line:1461
        O00O0O00O0O00O000 .model_3D_text =tk .Label (O00O0O00O0O00O000 .model_tab_frame ,bg ="white",fg ="#FF761A",text ="3D Model",font =("Open Sans",10 ),cursor ="hand2")#line:1462
        O00O0O00O0O00O000 .model_3D_text .grid (row =0 ,column =1 ,sticky ="NEWS",padx =1 ,pady =(1 ,4 ))#line:1463
        O00O0O00O0O00O000 .symbol_view .destroy ()#line:1465
        if O00O0O00O0O00O000 .threedmodel_medium_image :#line:1467
            O00O0O00O0O00O000 .threedee_text .set ("")#line:1468
            O00O0O00O0O00O000 .threedee_model_img =tk .Label (O00O0O00O0O00O000 .model_frame ,bg ="white",image =O00O0O00O0O00O000 .threedmodel_medium_image )#line:1469
            O00O0O00O0O00O000 .threedee_model_img .grid (row =0 ,column =0 ,sticky ="NEWS",padx =(400 ,60 ))#line:1470
            O00O0O00O0O00O000 .model_frame .update_idletasks ()#line:1471
        else :#line:1472
            O00O0O00O0O00O000 .threedee_text .set ("No 3D preview available.")#line:1473
        O00O0O00O0O00O000 .details_frame .update_idletasks ()#line:1475
    def request_now_button_callback (OO000O0O00O000000 ,O000OOOO0OOOOO0OO ):#line:1482
        webbrowser .open ("https://www.snapeda.com/instapart/",new =2 )#line:1483
    def on_button_active (O0OO0OO0OO0OO0O0O ,OO0OOO0OO0O0O000O ,O000000O0OO0OO000 ):#line:1485
        O000000O0OO0OO000 .config (fg ="#ff761a",bg ="white")#line:1486
    def on_button_inactive (OO0OO0O0O0OO0OO00 ,O0O00OOO00OOOOOO0 ,O0OO00O00OOO00OO0 ):#line:1488
        O0OO00O00OOO00OO0 .config (bg ="#ff761a",fg ="white")#line:1489
    def download_threedee_thread (O00OOOOOO0OOO00O0 ,OO0OO00O0OO0OO0OO ):#line:1491
        global IS_3D_TAB_OPEN #line:1493
        if O00OOOOOO0OOO00O0 .intense_caverns_img_dir [OO0OO00O0OO0OO0OO ]is None and not O00OOOOOO0OOO00O0 .intense_caverns_thread_started [OO0OO00O0OO0OO0OO ]:#line:1494
            O00OO00OO00O00O00 =O00OOOOOO0OOO00O0 .intense_caverns_links [OO0OO00O0OO0OO0OO ]#line:1495
            if len (O00OO00OO00O00O00 )!=0 :#line:1496
                O00OOOOOO0OOO00O0 .intense_caverns_thread_started [OO0OO00O0OO0OO0OO ]=True #line:1497
                print ('start download_threedee_thread')#line:1498
                O00OO00OO00O00O00 ="http://screeenly.com/api/v1/fullsize"#line:1499
                OOO00O000OO0OO000 ={'key':'AMln0sZduFx8WVg3v8KVnlZAUgOcYgAhJFBAIJZXB90GZLo2JP','url':O00OO00OO00O00O00 ,'delay':4 ,}#line:1504
                try :#line:1505
                    O0O0O0OO0OO00OO0O =time .time ()#line:1506
                    if sys .version_info [0 ]==3 :#line:1508
                        print ('taking snapshot')#line:1509
                        O00O000O00OO00OOO =urllib .parse .urlencode (OOO00O000OO0OO000 ).encode ("utf-8")#line:1510
                        OOO0000000O00OO00 =urllib .request .Request (O00OO00OO00O00O00 ,O00O000O00OO00OOO )#line:1511
                        OOOO0OOOO0O0OO0O0 =urllib .request .urlopen (OOO0000000O00OO00 ).read ()#line:1512
                        O00O000O00OO00OOO =json .loads (OOOO0OOOO0O0OO0O0 )#line:1513
                        O00OO00OO00O00O00 =O00O000O00OO00OOO ['path']#line:1514
                        OO000OO0000OO0O00 =O00OO00OO00O00O00 [O00OO00OO00O00O00 .rfind ('/')+1 :]#line:1515
                        OO0O0OOOOO0OOOOO0 =os .path .join (O00OOOOOO0OOO00O0 .appdata_dir ,OO000OO0000OO0O00 )#line:1516
                        print ('saving snapshot')#line:1517
                        urllib .request .urlretrieve (O00OO00OO00O00O00 ,OO0O0OOOOO0OOOOO0 )#line:1518
                        O00OOOOOO0OOO00O0 .intense_caverns_img_dir [OO0OO00O0OO0OO0OO ]=OO0O0OOOOO0OOOOO0 #line:1519
                    else :#line:1520
                        print ('taking snapshot')#line:1521
                        O00O000O00OO00OOO =urllib .urlencode (OOO00O000OO0OO000 )#line:1522
                        OOO0000000O00OO00 =urllib2 .Request (O00OO00OO00O00O00 ,O00O000O00OO00OOO )#line:1523
                        OOOO0OOOO0O0OO0O0 =urllib2 .urlopen (OOO0000000O00OO00 ).read ()#line:1524
                        O00O000O00OO00OOO =json .loads (OOOO0OOOO0O0OO0O0 )#line:1525
                        O00OO00OO00O00O00 =O00O000O00OO00OOO ['path']#line:1526
                        OO000OO0000OO0O00 =O00OO00OO00O00O00 [O00OO00OO00O00O00 .rfind ('/')+1 :]#line:1527
                        OO0O0OOOOO0OOOOO0 =os .path .join (O00OOOOOO0OOO00O0 .appdata_dir ,OO000OO0000OO0O00 )#line:1528
                        print ('saving snapshot')#line:1529
                        urllib .urlretrieve (O00OO00OO00O00O00 ,OO0O0OOOOO0OOOOO0 )#line:1530
                        O00OOOOOO0OOO00O0 .intense_caverns_img_dir [OO0OO00O0OO0OO0OO ]=OO0O0OOOOO0OOOOO0 #line:1531
                    print ('end download_threedee_thread')#line:1532
                    O0O0OOO0O0OOOO0O0 =time .time ()#line:1533
                    print ("Execution time: "+str (O0O0OOO0O0OOOO0O0 -O0O0O0OO0OO00OO0O )+"s")#line:1534
                except :#line:1535
                    O00OOOOOO0OOO00O0 .intense_caverns_img_dir [OO0OO00O0OO0OO0OO ]=os .path .join (O00OOOOOO0OOO00O0 .threedee_model_not_available_img_dir )#line:1541
                    print ('timeout exception end download_threedee_thread')#line:1542
            else :#line:1553
                print ('empty url')#line:1554
                O00OOOOOO0OOO00O0 .intense_caverns_img_dir [OO0OO00O0OO0OO0OO ]=os .path .join (O00OOOOOO0OOO00O0 .threedee_model_not_available_img_dir )#line:1555
            if IS_3D_TAB_OPEN and not O00OOOOOO0OOO00O0 .intense_caverns_thread_started [OO0OO00O0OO0OO0OO ]:#line:1556
                O00OOOOOO0OOO00O0 .threedee_text .set ("")#line:1557
                O00OOOOOO0OOO00O0 .threedee_image =tk .PhotoImage (file =O00OOOOOO0OOO00O0 .intense_caverns_img_dir [OO0OO00O0OO0OO0OO ])#line:1558
                O00OOOOOO0OOO00O0 .threedee_model_img =tk .Label (O00OOOOOO0OOO00O0 .model_frame ,bg ="white",image =O00OOOOOO0OOO00O0 .threedee_image )#line:1559
                O00OOOOOO0OOO00O0 .threedee_model_img .grid (row =0 ,column =0 ,sticky ="NEWS",padx =(60 ,60 ))#line:1560
                O00OOOOOO0OOO00O0 .model_frame .update_idletasks ()#line:1561
        if IS_3D_TAB_OPEN and O00OOOOOO0OOO00O0 .intense_caverns_img_dir [OO0OO00O0OO0OO0OO ]is not None :#line:1562
                O00OOOOOO0OOO00O0 .threedee_text .set ("")#line:1563
                O00OOOOOO0OOO00O0 .threedee_image =tk .PhotoImage (file =O00OOOOOO0OOO00O0 .intense_caverns_img_dir [OO0OO00O0OO0OO0OO ])#line:1564
                O00OOOOOO0OOO00O0 .threedee_model_img =tk .Label (O00OOOOOO0OOO00O0 .model_frame ,bg ="white",image =O00OOOOOO0OOO00O0 .threedee_image )#line:1565
                O00OOOOOO0OOO00O0 .threedee_model_img .grid (row =0 ,column =0 ,sticky ="NEWS",padx =(60 ,60 ))#line:1566
                O00OOOOOO0OOO00O0 .model_frame .update_idletasks ()#line:1567
    def get_intense_caverns_link (OO0000000O0O0OO0O ,O0OOOO00O00OO0O00 ):#line:1569
        if OO0000000O0O0OO0O .intense_caverns_links [O0OOOO00O00OO0O00 ]is None :#line:1570
            O00O0000O0O0O0OOO =None #line:1571
            O00000OO000O0000O =None #line:1572
            try :#line:1573
                O00O0000O0O0O0OOO =OO0000000O0O0OO0O .data ["results"][O0OOOO00O00OO0O00 ]["unipart_id"]#line:1574
                print (O00O0000O0O0O0OOO )#line:1575
                OOOO00OO0O0OO0OOO ={'User-Agent':"Kicad"}#line:1576
                OOOO000OOO000OOOO ="https://snapeda.com/api/v1/parts/unipart_3d_viewer_url?unipart_id=%s"%str (O00O0000O0O0O0OOO )#line:1577
                if sys .version_info [0 ]==3 :#line:1578
                    O000OOOO0O0O00O0O =urllib .request .Request (OOOO000OOO000OOOO ,headers =OOOO00OO0O0OO0OOO )#line:1579
                    OOOOO00O0O0O00OOO =urllib .request .urlopen (O000OOOO0O0O00O0O ,timeout =5 ).read ()#line:1580
                else :#line:1581
                    O000OOOO0O0O00O0O =urllib2 .Request (OOOO000OOO000OOOO ,headers =OOOO00OO0O0OO0OOO )#line:1582
                    OOOOO00O0O0O00OOO =urllib2 .urlopen (O000OOOO0O0O00O0O ,timeout =5 ).read ()#line:1583
                O0OO0O000OOOOO000 =json .loads (OOOOO00O0O0O00OOO )#line:1584
                O00000OO000O0000O =O0OO0O000OOOOO000 ["url"]#line:1585
            except :#line:1586
                O00000OO000O0000O =''#line:1587
            if O00000OO000O0000O is not None :#line:1589
                OO0000000O0O0OO0O .intense_caverns_links [O0OOOO00O00OO0O00 ]=O00000OO000O0000O #line:1590
    def get_component (OO0O0OO000O0O0O00 ,OO000O0000000O00O ,OOOO0OOO00O0OO0O0 ):#line:1592
        if not OO0O0OO000O0O0O00 .side_opened :#line:1603
            for OO0O00OOOOOOO0OO0 in OO0O0OO000O0O0O00 .manufacturer_names :#line:1604
                OO0O00OOOOOOO0OO0 .config (fg ="#999999")#line:1605
            for O000000000O0OOOOO in OO0O0OO000O0O0O00 .manufacturer_labels :#line:1606
                O000000000O0OOOOO .grid_forget ()#line:1607
            for O000000000O0OOOOO in OO0O0OO000O0O0O00 .available_labels :#line:1608
                O000000000O0OOOOO .grid_forget ()#line:1609
            OO0O0OO000O0O0O00 .canvas_frame .grid_columnconfigure (0 ,weight =0 )#line:1610
            OO0O0OO000O0O0O00 .canvas_frame .grid_columnconfigure (1 ,weight =2 )#line:1611
            OO0O0OO000O0O0O00 .canvas_frame .grid_columnconfigure (2 ,weight =2 )#line:1612
            OO0O0OO000O0O0O00 .canvas_frame .grid_columnconfigure (3 ,weight =0 )#line:1613
            OO0O0OO000O0O0O00 .canvas_frame .grid_columnconfigure (4 ,weight =2 )#line:1614
            OO0O0OO000O0O0O00 .canvas_frame .grid_columnconfigure (5 ,weight =1 )#line:1615
            OO0O0OO000O0O0O00 .canvas_frame .grid_columnconfigure (6 ,weight =3 )#line:1616
        OO0O0OO000O0O0O00 .side_opened =True #line:1618
        for O00O00O00000OO000 in range (3 ):#line:1619
            OO0O0OO000O0O0O00 .dual_frame .grid_columnconfigure (O00O00O00000OO000 ,weight =1 ,uniform ="foo")#line:1620
        OO0O0OO000O0O0O00 .side_frame =tk .Frame (OO0O0OO000O0O0O00 .dual_frame ,bg ="white")#line:1621
        OO0O0OO000O0O0O00 .side_frame .grid (row =0 ,column =2 ,columnspan =1 ,sticky ="NEWS")#line:1622
        OO0O0OO000O0O0O00 .side_frame .grid_columnconfigure (0 ,weight =1 )#line:1623
        OO0O0OO000O0O0O00 .side_frame .grid_rowconfigure (0 ,weight =1 )#line:1624
        OO0O0OO000O0O0O00 .details_frame =tk .Frame (OO0O0OO000O0O0O00 .side_frame ,bg ="#E1E1E1")#line:1626
        OO0O0OO000O0O0O00 .details_frame .grid (row =0 ,column =0 ,sticky ="NEWS",padx =(10 ,0 ),pady =0 )#line:1627
        for O00O00O00000OO000 in range (7 ):#line:1628
            OO0O0OO000O0O0O00 .details_frame .grid_rowconfigure (O00O00O00000OO000 ,weight =1 ,uniform ="foo")#line:1629
        OO0O0OO000O0O0O00 .details_frame .grid_columnconfigure (0 ,weight =1 )#line:1630
        OO0O0OO000O0O0O00 .load_gif =tk .Label (OO0O0OO000O0O0O00 .side_frame ,bg ='white')#line:1632
        OO0O0OO000O0O0O00 .load_gif .grid (row =0 ,column =0 ,sticky ="NEWS")#line:1633
        OO0O0OO000O0O0O00 .load_gif .lower ()#line:1634
        OO0O0OO000O0O0O00 .side_header =tk .Frame (OO0O0OO000O0O0O00 .details_frame ,bg ="white")#line:1636
        OO0O0OO000O0O0O00 .side_header .grid (row =0 ,column =0 ,rowspan =1 ,sticky ="NEWS",padx =1 ,pady =(1 ,1 ))#line:1637
        OO0O0OO000O0O0O00 .side_header .grid_columnconfigure (0 ,weight =1 )#line:1638
        OO0O0OO000O0O0O00 .side_header .grid_columnconfigure (1 ,weight =1 )#line:1639
        OO0O0OO000O0O0O00 .side_header .grid_rowconfigure (0 ,weight =1 )#line:1640
        OO0O0OO000O0O0O00 .details_label =tk .Label (OO0O0OO000O0O0O00 .side_header ,bg ="white",text ="Details",font =("Open Sans","8","bold"))#line:1642
        OO0O0OO000O0O0O00 .details_label .grid (row =0 ,column =0 ,sticky ="W",padx =(15 ,0 ))#line:1643
        O0OOO0OO000O0OOOO =OO0O0OO000O0O0O00 .data ["results"][OOOO0OOO00O0OO0O0 ]#line:1645
        OO0O0OO000O0O0O00 .part_number =O0OOO0OO000O0OOOO ["part_number"]#line:1647
        OO0O0OO000O0O0O00 .has_symbol =O0OOO0OO000O0OOOO ["has_symbol"]#line:1648
        OO0O0OO000O0O0O00 .has_footprint =O0OOO0OO000O0OOOO ["has_footprint"]#line:1649
        OO0O0OO000O0O0O00 .has_datasheet =O0OOO0OO000O0OOOO ["has_datasheet"]#line:1650
        OO0O0OO000O0O0O00 .uniqueid =O0OOO0OO000O0OOOO ["uniqueid"]#line:1651
        OO0O0OO000O0O0O00 .manufacturer =O0OOO0OO000O0OOOO ["manufacturer"]#line:1652
        OO0O0OO000O0O0O00 .manufacturer_url =O0OOO0OO000O0OOOO ["organization_image_100_20"]#line:1653
        try :#line:1655
            O0OOOO000OOO0OO00 =OO0O0OO000O0O0O00 .organization_images [OOOO0OOO00O0OO0O0 +1 ]#line:1656
            O0OOOOOOO0OOOOO00 =tk .Label (OO0O0OO000O0O0O00 .side_header ,image =O0OOOO000OOO0OO00 ,bg ="white",font =("Open Sans",9 ))#line:1657
            O0OOOOOOO0OOOOO00 .grid (row =0 ,column =1 ,sticky ="E",padx =(0 ,15 ))#line:1658
        except KeyError :#line:1659
            print ("No Organization Image")#line:1660
            O0OOOOOOO0OOOOO00 =tk .Label (OO0O0OO000O0O0O00 .side_header ,text =OO0O0OO000O0O0O00 .manufacturer ,bg ="white",font =("Open Sans",9 ))#line:1661
            O0OOOOOOO0OOOOO00 .grid (row =0 ,column =1 ,sticky ="E",padx =(0 ,15 ))#line:1662
        OO0O0OO000O0O0O00 .part_details =tk .Frame (OO0O0OO000O0O0O00 .details_frame ,bg ="white")#line:1689
        OO0O0OO000O0O0O00 .part_details .grid (row =1 ,column =0 ,rowspan =2 ,sticky ="NEWS",padx =1 )#line:1690
        OO0O0OO000O0O0O00 .part_details .grid_columnconfigure (0 ,weight =1 )#line:1691
        OO0O0OO000O0O0O00 .side_buttons =tk .Frame (OO0O0OO000O0O0O00 .part_details ,bg ="white")#line:1692
        OO0O0OO000O0O0O00 .side_buttons .grid (row =2 ,column =0 ,padx =(15 ,15 ),sticky ="NEWS")#line:1693
        OO0O0OO000O0O0O00 .side_buttons .grid_rowconfigure (0 ,weight =1 )#line:1694
        OO0O0OO000O0O0O00 .side_buttons .grid_columnconfigure (0 ,weight =10 ,uniform ="foo")#line:1695
        OO0O0OO000O0O0O00 .side_buttons .grid_columnconfigure (1 ,weight =1 ,uniform ="foo")#line:1696
        OO0O0OO000O0O0O00 .side_buttons .grid_columnconfigure (2 ,weight =10 ,uniform ="foo")#line:1697
        OO0O0OO000O0O0O00 .model_tab_frame =tk .Frame (OO0O0OO000O0O0O00 .details_frame ,bg ="white")#line:1699
        OO0O0OO000O0O0O00 .model_tab_frame .grid (row =3 ,column =0 ,sticky ="NEWS",padx =1 )#line:1700
        OO0O0OO000O0O0O00 .model_tab_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:1701
        OO0O0OO000O0O0O00 .model_tab_frame .grid_columnconfigure (1 ,weight =1 ,uniform ="foo")#line:1702
        OO0O0OO000O0O0O00 .model_tab_frame .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:1703
        tk .Label (OO0O0OO000O0O0O00 .model_tab_frame ,bg ="#DADADA").grid (row =0 ,column =0 ,sticky ="NEWS")#line:1705
        OO0O0OO000O0O0O00 .model_2D_underline =tk .Label (OO0O0OO000O0O0O00 .model_tab_frame ,bg ="#FF761A")#line:1706
        OO0O0OO000O0O0O00 .model_2D_underline .grid (row =0 ,column =0 ,sticky ="NEWS",pady =(1 ,0 ),padx =1 )#line:1707
        OO0O0OO000O0O0O00 .model_2D_text =tk .Label (OO0O0OO000O0O0O00 .model_tab_frame ,bg ="white",fg ="#FF761A",text ="2D Model",font =("Open Sans",10 ),cursor ="hand2")#line:1708
        OO0O0OO000O0O0O00 .model_2D_text .grid (row =0 ,column =0 ,sticky ="NEWS",padx =1 ,pady =(1 ,4 ))#line:1709
        tk .Label (OO0O0OO000O0O0O00 .model_tab_frame ,bg ="#DADADA").grid (row =0 ,column =1 ,sticky ="NEWS")#line:1711
        OO0O0OO000O0O0O00 .model_3D_text =tk .Label (OO0O0OO000O0O0O00 .model_tab_frame ,bg ="#EEEEEE",fg ="#333333",text ="3D Model",font =("Open Sans",10 ),cursor ="hand2")#line:1712
        OO0O0OO000O0O0O00 .model_3D_text .grid (row =0 ,column =1 ,sticky ="NEWS",padx =1 ,pady =1 )#line:1713
        OO0O0OO000O0O0O00 .side_part_number =tk .Label (OO0O0OO000O0O0O00 .part_details ,bg ="white",fg ="#FF761A",font =("Open Sans",12 ),text =O0OOO0OO000O0OOOO ["part_number"])#line:1715
        OO0O0OO000O0O0O00 .side_part_number .grid (row =0 ,column =0 ,sticky ="NWS",padx =(15 ,0 ),pady =(15 ,0 ))#line:1716
        OO0O0OO000O0O0O00 .description_message =tk .Message (OO0O0OO000O0O0O00 .part_details ,bg ="white",text =O0OOO0OO000O0OOOO ["short_description"],font =("Open Sans",11 ),cursor ="hand2",justify =tk .LEFT ,anchor ='nw')#line:1721
        OO0O0OO000O0O0O00 .description_message .bind ("<Configure>",lambda O0OO0OOOO0O0OOO00 :O0OO0OOOO0O0OOO00 .widget .configure (width =O0OO0OOOO0O0OOO00 .width -8 ))#line:1722
        OO0O0OO000O0O0O00 .description_message .grid (row =1 ,column =0 ,columnspan =1 ,sticky ="NEWS",pady =(0 ,10 ),padx =(10 ,10 ))#line:1723
        OOOO000O00OOO0O0O =tk .PhotoImage (file =OO0O0OO000O0O0O00 .download_button_dir )#line:1728
        O00O000OOOO00OOO0 =OO0O0OO000O0O0O00 .resize (OOOO000O00OOO0O0O ,90 ,24 )#line:1729
        OO0O0OO000O0O0O00 .parent .images .append (O00O000OOOO00OOO0 )#line:1730
        O00OO0O0OOOOO0O00 =tk .PhotoImage (file =OO0O0OO000O0O0O00 .view_button_dir )#line:1731
        O0O00O000O0OO000O =OO0O0OO000O0O0O00 .resize (O00OO0O0OOOOO0O00 ,148 ,39 )#line:1732
        OO0O0OO000O0O0O00 .parent .images .append (O0O00O000O0OO000O )#line:1733
        OO0O0OO000O0O0O00 .is_downloading =False #line:1738
        tk .Label (OO0O0OO000O0O0O00 .side_buttons ,bg ="#ff761a").grid (row =0 ,column =0 ,sticky ="EW",ipady =7 ,ipadx =72 )#line:1744
        OO0O0OO000O0O0O00 .download_button =tk .Label (OO0O0OO000O0O0O00 .side_buttons ,bg ="#ff761a",fg ="white",cursor ="hand2",text ="Download",font =("Open Sans",9 ))#line:1745
        OO0O0OO000O0O0O00 .download_button .grid (row =0 ,column =0 ,sticky ="EW",padx =(1 ,1 ),ipady =6 ,ipadx =10 )#line:1747
        OO0O0OO000O0O0O00 .download_button .bind ("<Button-1>",OO0O0OO000O0O0O00 .download_component )#line:1750
        OO0O0OO000O0O0O00 .download_button .bind ("<Enter>",lambda O0O0O0O0000OO0OOO ,element =OO0O0OO000O0O0O00 .download_button :OO0O0OO000O0O0O00 .on_button_active (O0O0O0O0000OO0OOO ,element ))#line:1751
        OO0O0OO000O0O0O00 .download_button .bind ("<Leave>",lambda O000000O0OOO0OOOO ,element =OO0O0OO000O0O0O00 .download_button :OO0O0OO000O0O0O00 .on_button_inactive (O000000O0OOO0OOOO ,element ))#line:1752
        tk .Label (OO0O0OO000O0O0O00 .side_buttons ,bg ="#ff761a").grid (row =0 ,column =2 ,sticky ="EW",ipady =7 ,ipadx =72 )#line:1756
        OO0O0OO000O0O0O00 .view_button =tk .Label (OO0O0OO000O0O0O00 .side_buttons ,bg ="#ff761a",fg ="white",cursor ="hand2",text ="Datasheet",font =("Open Sans",9 ))#line:1757
        OO0O0OO000O0O0O00 .view_button .grid (row =0 ,column =2 ,sticky ="EW",padx =(1 ,1 ),ipady =6 ,ipadx =10 )#line:1758
        OO0O0OO000O0O0O00 .view_button .bind ("<Button-1>",lambda OO0000000O0O000O0 ,url =O0OOO0OO000O0OOOO ["_links"]["self"]["href"]:OO0O0OO000O0O0O00 .view_on_snapeda (url ))#line:1759
        OO0O0OO000O0O0O00 .view_button .bind ("<Enter>",lambda OOOOOOOOOO0OOOOO0 ,element =OO0O0OO000O0O0O00 .view_button :OO0O0OO000O0O0O00 .on_button_active (OOOOOOOOOO0OOOOO0 ,element ))#line:1760
        OO0O0OO000O0O0O00 .view_button .bind ("<Leave>",lambda O00000O0OOOOOOO00 ,element =OO0O0OO000O0O0O00 .view_button :OO0O0OO000O0O0O00 .on_button_inactive (O00000O0OOOOOOO00 ,element ))#line:1761
        OO0O0OO000O0O0O00 .symbol_frame =tk .Frame (OO0O0OO000O0O0O00 .details_frame ,bg ="white")#line:1789
        OO0O0OO000O0O0O00 .symbol_frame .grid (row =4 ,column =0 ,rowspan =3 ,sticky ="NEWS",padx =1 ,pady =(0 ,1 ))#line:1790
        OO0O0OO000O0O0O00 .symbol_frame .grid_columnconfigure (0 ,weight =1 )#line:1791
        OO0O0OO000O0O0O00 .symbol_frame .grid_rowconfigure (0 ,weight =1 )#line:1792
        OO0O0OO000O0O0O00 .model_canvas =tk .Canvas (OO0O0OO000O0O0O00 .symbol_frame ,bg ="white")#line:1794
        OO0O0OO000O0O0O00 .model_canvas .grid (row =0 ,column =0 ,sticky ="NEWS")#line:1795
        O0OO0OO0000OOO000 =ttk .Style ()#line:1797
        O0OO0OO0000OOO000 .theme_use ('clam')#line:1798
        O0OO0OO0000OOO000 .configure ("snapeda.Vertical.TScrollbar",gripcount =0 ,background ="#FF8330",troughcolor ='#C4C4C4',lightcolor ='#C4C4C4',darkcolor ='#C4C4C4',bordercolor ="#C4C4C4",borderwidth =0 ,relief =tk .FLAT )#line:1799
        O0OO0OO0000OOO000 .map ('snapeda.Vertical.TScrollbar',foreground =[('disabled','#C4C4C4'),('pressed','#FF8330'),('active','#FF8330')],background =[('disabled','#C4C4C4'),('pressed','!focus','#FF8330'),('active','#FF8330')],highlightcolor =[('focus','#C4C4C4'),('!focus','#C4C4C4')],)#line:1807
        O0OO0OO0000OOO000 .layout ('snapeda.Vertical.TScrollbar',[('Vertical.Scrollbar.trough',{'children':[('Vertical.Scrollbar.thumb',{'expand':'1','sticky':'nswe'})],'sticky':'ns'})])#line:1809
        OO0O0OO000O0O0O00 .model_scrollbar =ttk .Scrollbar (OO0O0OO000O0O0O00 .symbol_frame ,orient ="vertical",command =OO0O0OO000O0O0O00 .model_canvas .yview ,style ="snapeda.Vertical.TScrollbar")#line:1810
        OO0O0OO000O0O0O00 .model_scrollbar .grid (row =0 ,column =1 ,sticky ='NS')#line:1812
        OO0O0OO000O0O0O00 .model_frame =tk .Frame (OO0O0OO000O0O0O00 .model_canvas ,bg ="white")#line:1813
        OO0O0OO000O0O0O00 .model_frame .bind ("<Configure>",lambda O00O0O00O000O000O :OO0O0OO000O0O0O00 .model_canvas .configure (scrollregion =OO0O0OO000O0O0O00 .model_canvas .bbox ("all")))#line:1814
        OO0O0OO000O0O0O00 .model_canvas .create_window ((0 ,0 ),window =OO0O0OO000O0O0O00 .model_frame ,anchor =tk .CENTER )#line:1815
        OO0O0OO000O0O0O00 .model_canvas .configure (yscrollcommand =OO0O0OO000O0O0O00 .model_scrollbar .set )#line:1816
        OO0O0OO000O0O0O00 .threedmodel_medium_image =None #line:1820
        if 'models'in OO0O0OO000O0O0O00 .data ["results"][OOOO0OOO00O0OO0O0 ]and len (OO0O0OO000O0O0O00 .data ["results"][OOOO0OOO00O0OO0O0 ]["models"])>0 :#line:1821
            O0O000OO00OOO0OO0 =OO0O0OO000O0O0O00 .data ["results"][OOOO0OOO00O0OO0O0 ]["models"][0 ]#line:1822
            if '3dmodel_medium'in O0O000OO00OOO0OO0 and 'url'in O0O000OO00OOO0OO0 ['3dmodel_medium']:#line:1823
                print ('downloading 3d')#line:1824
                OO0O0OO000O0O0O00 .threedmodel_medium_img_path =OO0O0OO000O0O0O00 .download_image (O0O000OO00OOO0OO0 ['3dmodel_medium']['url'])#line:1825
                OO0O0OO000O0O0O00 .threedmodel_medium_img =tk .PhotoImage (file =OO0O0OO000O0O0O00 .threedmodel_medium_img_path )#line:1826
                OO0O0OO000O0O0O00 .threedmodel_medium_image =OO0O0OO000O0O0O00 .resize (OO0O0OO000O0O0O00 .threedmodel_medium_img ,500 ,500 )#line:1827
                print (OO0O0OO000O0O0O00 .download_image (O0O000OO00OOO0OO0 ['3dmodel_medium']['url']))#line:1828
                print ('done')#line:1829
        try :#line:1831
            OO0O0OO000O0O0O00 .symbol_im_path =OO0O0OO000O0O0O00 .download_image (O0OOO0OO000O0OOOO ["models"][0 ]["symbol_medium"]["url"])#line:1832
            OO0OOOO00OO0O0000 =tk .PhotoImage (file =OO0O0OO000O0O0O00 .symbol_im_path )#line:1833
            OO0O0OO000O0O0O00 .symbol_image =OO0O0OO000O0O0O00 .resize (OO0OOOO00OO0O0000 ,210 ,210 )#line:1834
            OO0O0OO000O0O0O00 .symbol_view =tk .Label (OO0O0OO000O0O0O00 .model_frame ,bg ="white",image =OO0O0OO000O0O0O00 .symbol_image )#line:1836
            OO0O0OO000O0O0O00 .symbol_view .grid (row =0 ,column =0 ,sticky ="NEWS",padx =(65 ,65 ))#line:1837
            OO0O0OO000O0O0O00 .has_model =True #line:1838
        except KeyError :#line:1839
            OO0O0OO000O0O0O00 .symbol_view =tk .Frame (OO0O0OO000O0O0O00 .model_frame ,bg ="white")#line:1840
            OO0O0OO000O0O0O00 .symbol_view .columnconfigure (0 ,weight =1 ,uniform ='foo')#line:1841
            OO0O0OO000O0O0O00 .symbol_view .grid (row =0 ,column =0 ,sticky ='NEWS',padx =(60 ,60 ))#line:1844
            OO0O0OO000O0O0O00 .ghost_2D_im =tk .PhotoImage (file =OO0O0OO000O0O0O00 .not_available_img_dir )#line:1845
            tk .Label (OO0O0OO000O0O0O00 .symbol_view ,bg ="white",image =OO0O0OO000O0O0O00 .ghost_2D_im ).grid (row =0 ,column =0 ,sticky ="NEWS")#line:1848
            OO0O0OO000O0O0O00 .request_button_img =tk .PhotoImage (file =OO0O0OO000O0O0O00 .request_now_button_img_dir )#line:1849
            OO0O0OO000O0O0O00 .request_button =tk .Label (OO0O0OO000O0O0O00 .symbol_view ,bg ="white",image =OO0O0OO000O0O0O00 .request_button_img ,cursor ="hand2")#line:1851
            OO0O0OO000O0O0O00 .request_button .grid (row =1 ,column =0 ,sticky ="NEWS",pady =(0 ,30 ))#line:1852
            OO0O0OO000O0O0O00 .request_button .bind ('<Button-1>',OO0O0OO000O0O0O00 .request_now_button_callback )#line:1853
            OO0O0OO000O0O0O00 .has_model =False #line:1854
        OO0O0OO000O0O0O00 .tab_view =OO0O0OO000O0O0O00 .symbol_view #line:1856
        try :#line:1858
            OOO0O00OO00O0O0O0 =OO0O0OO000O0O0O00 .download_image (O0OOO0OO000O0OOOO ["models"][0 ]["package_medium"]["url"])#line:1859
            O0000O00O00OO000O =tk .PhotoImage (file =OOO0O00OO00O0O0O0 )#line:1860
            OO0O0OO000O0O0O00 .package_image =OO0O0OO000O0O0O00 .resize (O0000O00O00OO000O ,150 ,150 )#line:1861
            OOOO000O00O00O000 =tk .Label (OO0O0OO000O0O0O00 .model_frame ,bg ="white",image =OO0O0OO000O0O0O00 .package_image )#line:1863
            OOOO000O00O00O000 .grid (row =1 ,column =0 ,sticky ="NEWS")#line:1864
            OO0O0OO000O0O0O00 .has_package =True #line:1865
        except KeyError :#line:1866
            OOOO000O00O00O000 =tk .Frame (OO0O0OO000O0O0O00 .model_frame ,bg ="white")#line:1867
            OOOO000O00O00O000 .columnconfigure (0 ,weight =1 ,uniform ='foo')#line:1868
            OOOO000O00O00O000 .rowconfigure (0 ,weight =2 ,uniform ='foo')#line:1869
            OOOO000O00O00O000 .rowconfigure (0 ,weight =1 ,uniform ='foo')#line:1870
            OOOO000O00O00O000 .grid (row =1 ,column =0 ,sticky ='NEWS')#line:1871
            OO0O0OO000O0O0O00 .ghost_im =tk .PhotoImage (file =OO0O0OO000O0O0O00 .avatar_image_dir )#line:1872
            tk .Label (OOOO000O00O00O000 ,bg ="white",image =OO0O0OO000O0O0O00 .ghost_im ).grid (row =0 ,column =0 ,sticky ="NEWS")#line:1875
            tk .Label (OOOO000O00O00O000 ,bg ="white",text ='No Package',font =("Open Sans",11 )).grid (row =1 ,column =0 ,sticky ="NEWS",pady =(0 ,15 ))#line:1876
            print ("No package")#line:1877
            OO0O0OO000O0O0O00 .has_package =False #line:1878
        OO0O0OO000O0O0O00 .model_2D_text .bind ('<Button-1>',lambda O000000000O0O0O00 ,index =OOOO0OOO00O0OO0O0 :OO0O0OO000O0O0O00 .model_2D_callback (O000000000O0O0O00 ,index ))#line:1880
        OO0O0OO000O0O0O00 .model_3D_text .bind ('<Button-1>',lambda O0000OOOO0OOOO0O0 ,index =OOOO0OOO00O0OO0O0 :OO0O0OO000O0O0O00 .model_3D_callback (O0000OOOO0OOOO0O0 ,index ))#line:1881
        OO0O0OO000O0O0O00 .is_loading =False #line:1883
        OO0O0OO000O0O0O00 .description_message .update_idletasks ()#line:1886
        OO0O0OO000O0O0O00 .part_details .update_idletasks ()#line:1887
        OO0O0OO000O0O0O00 .details_frame .lift ()#line:1888
    def canvas_frame_wh (OO0O00O00OO00OO00 ,O0OO00O0OO00O00O0 ):#line:1890
        OO00OOO0O0O0OO00O =OO0O00O00OO00OO00 .canvas .winfo_width ()#line:1891
        print ("break3")#line:1892
        OO0O00O00OO00OO00 .canvas .itemconfigure ("inner_frame",width =OO00OOO0O0O0OO00O -4 )#line:1893
    def initialize_user_interface (OO00OO0O00OOOOOO0 ):#line:1895
        if OO00OO0O00OOOOOO0 .is_windows :#line:1896
            OO00OO0O00OOOOOO0 .parent .iconbitmap (OO00OO0O00OOOOOO0 .icon_bitmap_dir )#line:1897
        OO00OO0O00OOOOOO0 .parent .title ("SnapEDA v"+OO00OO0O00OOOOOO0 .parent .version )#line:1898
        OO00OO0O00OOOOOO0 .parent .geometry ("1150x828")#line:1899
        OO00OO0O00OOOOOO0 .parent .minsize (width =1150 ,height =828 )#line:1900
        OO00OO0O00OOOOOO0 .light_gray ="#FAFAFA"#line:1901
        OO00OO0O00OOOOOO0 .medium_gray ="#E1E1E1"#line:1902
        OO00OO0O00OOOOOO0 .dark_gray ="#696969"#line:1903
        OO00OO0O00OOOOOO0 .parent .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:1904
        OO00OO0O00OOOOOO0 .parent .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:1905
        OO00OO0O00OOOOOO0 .parent_container =tk .Frame (OO00OO0O00OOOOOO0 .parent ,bg =OO00OO0O00OOOOOO0 .dark_gray )#line:1906
        OO00OO0O00OOOOOO0 .parent_container .grid (row =0 ,column =0 ,sticky ="NEWS")#line:1907
        for OO0OOO0OO00000000 in range (6 ):#line:1908
            OO00OO0O00OOOOOO0 .parent_container .grid_columnconfigure (OO0OOO0OO00000000 ,weight =1 ,uniform ="foo")#line:1909
        OO00OO0O00OOOOOO0 .parent_container .grid_rowconfigure (0 ,weight =1 )#line:1910
        OO00OO0O00OOOOOO0 .main_frame =tk .Frame (OO00OO0O00OOOOOO0 .parent_container ,bg ="white")#line:1911
        OO00OO0O00OOOOOO0 .main_frame .grid (row =0 ,column =0 ,columnspan =6 ,sticky ="NEWS")#line:1912
        OO00OO0O00OOOOOO0 .main_frame .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:1916
        for OO0OOO0OO00000000 in range (6 ):#line:1917
            OO00OO0O00OOOOOO0 .main_frame .grid_rowconfigure (OO0OOO0OO00000000 ,weight =1 ,uniform ="foo")#line:1918
        OO00OO0O00OOOOOO0 .parent .images =[]#line:1919
        OO00OO0O00OOOOOO0 .parent .default_images =[]#line:1920
        OO00OO0O00OOOOOO0 .current_page =1 #line:1921
        OO00OO0O00OOOOOO0 .max_page =1 #line:1922
        OO00OO0O00OOOOOO0 .top_wh =75 #line:1923
        OO00OO0O00OOOOOO0 .pages =[]#line:1924
        OO00OO0O00OOOOOO0 .side_opened =False #line:1925
        OO00OO0O00OOOOOO0 .search_frame =tk .Frame (OO00OO0O00OOOOOO0 .main_frame ,bg ="white")#line:1975
        OO00OO0O00OOOOOO0 .search_frame .grid (row =0 ,column =0 ,columnspan =1 ,sticky ="EW",padx =(18 ,0 ))#line:1976
        for OO0OOO0OO00000000 in range (3 ):#line:1977
            OO00OO0O00OOOOOO0 .search_frame .grid_columnconfigure (OO0OOO0OO00000000 +1 ,weight =1 ,uniform ="foo")#line:1978
        OO00OO0O00OOOOOO0 .search_frame .grid_rowconfigure (0 ,weight =0 )#line:1979
        OO00OO0O00OOOOOO0 .home_menu_img =tk .PhotoImage (file =OO00OO0O00OOOOOO0 .home_menu_img_dir )#line:1986
        OO00OO0O00OOOOOO0 .home_button =tk .Label (OO00OO0O00OOOOOO0 .search_frame ,image =OO00OO0O00OOOOOO0 .home_menu_img ,fg ="#FF761B",bg ="white",text ="HOME",cursor ="hand2",font =("Open Sans","8","bold","underline"))#line:1987
        OO00OO0O00OOOOOO0 .home_button .grid (row =0 ,column =0 ,padx =(0 ,15 ),sticky ="W")#line:1988
        OO00OO0O00OOOOOO0 .home_button .bind ("<Button-1>",OO00OO0O00OOOOOO0 .home_callback )#line:1989
        OOOOOO0O00OO000OO =tk .Frame (OO00OO0O00OOOOOO0 .search_frame ,bg ="white")#line:1991
        OOOOOO0O00OO000OO .grid (row =0 ,column =1 ,columnspan =1 ,sticky ="NEWS",pady =2 ,padx =(0 ,0 ))#line:1992
        OOOOOO0O00OO000OO .grid_columnconfigure (0 ,weight =1 )#line:1993
        OOOOOO0O00OO000OO .grid_rowconfigure (0 ,weight =1 )#line:1994
        tk .Label (OOOOOO0O00OO000OO ,bg ="#E1E1E1").grid (row =0 ,column =0 ,sticky ="NEWS",padx =(0 ,0 ),pady =(0 ,0 ))#line:1999
        tk .Label (OOOOOO0O00OO000OO ,bg ="white").grid (row =0 ,column =0 ,sticky ="NEWS",padx =(1 ,0 ),pady =(1 ,1 ))#line:2000
        OO00OO0O00OOOOOO0 .search_entry =tk .Entry (OOOOOO0O00OO000OO ,fg ="#696969",bg ="white",font =("Open Sans",9 ),borderwidth =0 ,highlightthickness =0 )#line:2002
        OO00OO0O00OOOOOO0 .search_entry .insert (0 ,OO00OO0O00OOOOOO0 .parent .search_datum )#line:2003
        OO00OO0O00OOOOOO0 .search_entry .grid (row =0 ,column =0 ,sticky ="NEWS",padx =(25 ,0 ),pady =(1 ,1 ))#line:2004
        O0OO00O00O00OO00O =tk .PhotoImage (file =OO00OO0O00OOOOOO0 .search_button_image_dir )#line:2006
        OOOO0O0OO0000OO0O =OO00OO0O00OOOOOO0 .resize (O0OO00O00O00OO00O ,73 ,55 )#line:2007
        OO00OO0O00OOOOOO0 .parent .images .append (OOOO0O0OO0000OO0O )#line:2008
        OO00OO0O00OOOOOO0 .search_button =tk .Label (OO00OO0O00OOOOOO0 .search_frame ,bg ="white",text ="",cursor ="hand2",image =OOOO0O0OO0000OO0O )#line:2009
        OO00OO0O00OOOOOO0 .is_searching =False #line:2010
        OO00OO0O00OOOOOO0 .search_button .bind ("<Button-1>",OO00OO0O00OOOOOO0 .search_data )#line:2011
        OO00OO0O00OOOOOO0 .search_entry .bind ('<Return>',OO00OO0O00OOOOOO0 .search_data )#line:2012
        OO00OO0O00OOOOOO0 .search_button .grid (row =0 ,column =2 ,sticky ="W")#line:2013
        OO00OO0O00OOOOOO0 .menu_container =tk .Frame (OO00OO0O00OOOOOO0 .search_frame ,bg ="white")#line:2016
        OO00OO0O00OOOOOO0 .menu_container .grid (row =0 ,column =3 ,columnspan =3 ,sticky ="E",padx =(0 ,18 ))#line:2017
        OO00OO0O00OOOOOO0 .menu_container .grid_rowconfigure (0 ,weight =1 )#line:2018
        OO00OO0O00OOOOOO0 .how_it_works_menu_img =tk .PhotoImage (file =OO00OO0O00OOOOOO0 .how_it_works_menu_img_dir )#line:2029
        OO00OO0O00OOOOOO0 .how_it_works_button =tk .Label (OO00OO0O00OOOOOO0 .menu_container ,image =OO00OO0O00OOOOOO0 .how_it_works_menu_img ,fg ="#FF761B",bg ="white",text ="How it works",cursor ="hand2",font =("Open Sans","8","bold","underline"))#line:2030
        OO00OO0O00OOOOOO0 .how_it_works_button .grid (row =0 ,column =0 ,padx =(0 ,15 ),sticky ="W")#line:2031
        OO00OO0O00OOOOOO0 .how_it_works_button .bind ("<Button-1>",OO00OO0O00OOOOOO0 .setting_callback )#line:2032
        OO00OO0O00OOOOOO0 .update_menu_img =tk .PhotoImage (file =OO00OO0O00OOOOOO0 .update_menu_img_dir )#line:2034
        OO00OO0O00OOOOOO0 .update_button =tk .Label (OO00OO0O00OOOOOO0 .menu_container ,image =OO00OO0O00OOOOOO0 .update_menu_img ,fg ="#FF761B",bg ="white",text ="Update",cursor ="hand2",font =("Open Sans","8","bold","underline"))#line:2035
        OO00OO0O00OOOOOO0 .update_button .grid (row =0 ,column =1 ,padx =(0 ,15 ),sticky ="W")#line:2036
        OO00OO0O00OOOOOO0 .update_button .bind ("<Button-1>",OO00OO0O00OOOOOO0 .update_callback )#line:2037
        OO00OO0O00OOOOOO0 .info_menu_img =tk .PhotoImage (file =OO00OO0O00OOOOOO0 .info_menu_img_dir )#line:2039
        OO00OO0O00OOOOOO0 .help_me_button =tk .Label (OO00OO0O00OOOOOO0 .menu_container ,image =OO00OO0O00OOOOOO0 .info_menu_img ,fg ="#FF761B",bg ="white",text ="Help Me",cursor ="hand2",font =("Open Sans","8","bold","underline"))#line:2040
        OO00OO0O00OOOOOO0 .help_me_button .grid (row =0 ,column =2 ,padx =(0 ,15 ),sticky ="W")#line:2041
        OO00OO0O00OOOOOO0 .help_me_button .bind ("<Button-1>",OO00OO0O00OOOOOO0 .how_it_works_callback )#line:2042
        OO00OO0O00OOOOOO0 .logout_menu_img =tk .PhotoImage (file =OO00OO0O00OOOOOO0 .logout_menu_img_dir )#line:2044
        OO00OO0O00OOOOOO0 .logout_button =tk .Label (OO00OO0O00OOOOOO0 .menu_container ,image =OO00OO0O00OOOOOO0 .logout_menu_img ,fg ="#FF761B",bg ="white",text ="Logout",cursor ="hand2",font =("Open Sans","8","bold","underline"))#line:2045
        OO00OO0O00OOOOOO0 .logout_button .grid (row =0 ,column =3 ,padx =(0 ,15 ))#line:2046
        OO00OO0O00OOOOOO0 .logout_button .bind ("<Button-1>",OO00OO0O00OOOOOO0 .logout_callback )#line:2047
        OO00OO0O00OOOOOO0 .table_frame =tk .Frame (OO00OO0O00OOOOOO0 .main_frame ,bg ="white")#line:2049
        OO00OO0O00OOOOOO0 .table_frame .grid (row =1 ,column =0 ,rowspan =5 ,columnspan =1 ,padx =19 ,pady =(0 ,13 ),sticky ="NEWS")#line:2050
        for OO0OOO0OO00000000 in range (7 ):#line:2057
            OO00OO0O00OOOOOO0 .table_frame .grid_rowconfigure (OO0OOO0OO00000000 ,weight =1 ,uniform ="foo")#line:2058
        OO00OO0O00OOOOOO0 .table_frame .grid_columnconfigure (0 ,weight =1 )#line:2059
        OO00OO0O00OOOOOO0 .table_frame .grid_columnconfigure (1 ,weight =1 )#line:2060
        OO00OO0O00OOOOOO0 .dual_frame =tk .Frame (OO00OO0O00OOOOOO0 .table_frame ,bg ="#E1E1E1")#line:2062
        OO00OO0O00OOOOOO0 .dual_frame .grid (row =0 ,column =0 ,columnspan =2 ,rowspan =6 ,sticky ="NEWS")#line:2063
        OO00OO0O00OOOOOO0 .dual_frame .grid_rowconfigure (0 ,weight =1 )#line:2064
        for OO0OOO0OO00000000 in range (2 ):#line:2065
            OO00OO0O00OOOOOO0 .dual_frame .grid_columnconfigure (OO0OOO0OO00000000 ,weight =1 ,uniform ="foo")#line:2066
        OO00OO0O00OOOOOO0 .results_frame =tk .Frame (OO00OO0O00OOOOOO0 .dual_frame ,bg ="white")#line:2067
        OO00OO0O00OOOOOO0 .results_frame .grid (row =0 ,column =0 ,columnspan =2 ,sticky ="NEWS",pady =(0 ,1 ))#line:2068
        OO00OO0O00OOOOOO0 .results_frame .grid_columnconfigure (0 ,weight =1 )#line:2069
        OO00OO0O00OOOOOO0 .results_frame .grid_rowconfigure (0 ,weight =1 )#line:2071
        OO00OO0O00OOOOOO0 .results_frame .update ()#line:2072
        OO00OO0O00OOOOOO0 .canvas =tk .Canvas (OO00OO0O00OOOOOO0 .results_frame ,bg ="white")#line:2073
        OO00OO0O00OOOOOO0 .canvas .grid (row =0 ,column =0 ,sticky ="NEWS")#line:2074
        OOO00OO0OO0OOO0OO =ttk .Style ()#line:2081
        OOO00OO0OO0OOO0OO .theme_use ('clam')#line:2082
        OOO00OO0OO0OOO0OO .configure ("snapeda.Vertical.TScrollbar",gripcount =0 ,background ="#FF8330",troughcolor ='#C4C4C4',lightcolor ='#C4C4C4',darkcolor ='#C4C4C4',bordercolor ="#C4C4C4",borderwidth =0 ,relief =tk .FLAT )#line:2083
        OOO00OO0OO0OOO0OO .map ('snapeda.Vertical.TScrollbar',foreground =[('disabled','#C4C4C4'),('pressed','#FF8330'),('active','#FF8330')],background =[('disabled','#C4C4C4'),('pressed','!focus','#FF8330'),('active','#FF8330')],highlightcolor =[('focus','#C4C4C4'),('!focus','#C4C4C4')],)#line:2091
        OOO00OO0OO0OOO0OO .layout ('snapeda.Vertical.TScrollbar',[('Vertical.Scrollbar.trough',{'children':[('Vertical.Scrollbar.thumb',{'expand':'1','sticky':'nswe'})],'sticky':'ns'})])#line:2093
        OO00OO0O00OOOOOO0 .vsb =ttk .Scrollbar (OO00OO0O00OOOOOO0 .results_frame ,orient ="vertical",command =OO00OO0O00OOOOOO0 .canvas .yview ,style ="snapeda.Vertical.TScrollbar")#line:2094
        OO00OO0O00OOOOOO0 .vsb .grid (row =0 ,column =1 ,sticky ='NS')#line:2095
        OO00OO0O00OOOOOO0 .canvas .configure (yscrollcommand =OO00OO0O00OOOOOO0 .vsb .set )#line:2096
        OO00OO0O00OOOOOO0 .canvas .configure (width =OO00OO0O00OOOOOO0 .results_frame .winfo_width ()/16 )#line:2097
        OO00OO0O00OOOOOO0 .canvas_frame =tk .Frame (OO00OO0O00OOOOOO0 .canvas ,bg ="white")#line:2099
        OO00OO0O00OOOOOO0 .canvas .create_window ((0 ,0 ),window =OO00OO0O00OOOOOO0 .canvas_frame ,anchor ='nw',tag ="inner_frame")#line:2105
        OO00OO0O00OOOOOO0 .canvas .update_idletasks ()#line:2106
        OO00OO0O00OOOOOO0 .canvas_frame .update_idletasks ()#line:2107
        OO00OO0O00OOOOOO0 .canvas .config (scrollregion =OO00OO0O00OOOOOO0 .canvas .bbox ("all"))#line:2108
        OO00OO0O00OOOOOO0 .canvas .bind ('<Configure>',OO00OO0O00OOOOOO0 .canvas_frame_wh )#line:2111
        OO00OO0O00OOOOOO0 .canvas .config (scrollregion =OO00OO0O00OOOOOO0 .canvas .bbox ("all"))#line:2114
        OO00OO0O00OOOOOO0 .pages_frame =tk .Frame (OO00OO0O00OOOOOO0 .table_frame ,bg ="#E1E1E1")#line:2115
        OO00OO0O00OOOOOO0 .pages_frame .grid (row =6 ,column =0 ,sticky ="W",padx =(0 ,0 ))#line:2116
        OO00OO0O00OOOOOO0 .frames =[tk .PhotoImage (file =os .path .join (OO00OO0O00OOOOOO0 .loading_image_dir ),format ='gif -index %i'%(OOOOOOO0O0O0OO0O0 ))for OOOOOOO0O0O0OO0O0 in range (31 )]#line:2119
        OO00OO0O00OOOOOO0 .search_gif =tk .Label (OO00OO0O00OOOOOO0 .results_frame ,bg ='white')#line:2120
        OO00OO0O00OOOOOO0 .search_gif .grid (row =0 ,column =0 ,sticky ="NEWS")#line:2121
        OO00OO0O00OOOOOO0 .search_gif .lower ()#line:2122
        OO00OO0O00OOOOOO0 .vsb .update_idletasks ()#line:2124
        O0O0OOO00OO0OOO00 =tk .PhotoImage (file =OO00OO0O00OOOOOO0 .powered_image_dir )#line:2125
        OO00OO0O00OOOOOO0 .powered_image =OO00OO0O00OOOOOO0 .resize (O0O0OOO00OO0OOO00 ,150 ,33 )#line:2126
        OO00OO0O00OOOOOO0 .parent .images .append (OO00OO0O00OOOOOO0 .powered_image )#line:2127
        OO00OO0O00OOOOOO0 .snapeda_powered =tk .Label (OO00OO0O00OOOOOO0 .table_frame ,image =OO00OO0O00OOOOOO0 .powered_image ,bg ="white")#line:2128
        OO00OO0O00OOOOOO0 .snapeda_powered .grid (row =6 ,column =1 ,sticky ="E",padx =(0 ,OO00OO0O00OOOOOO0 .vsb .winfo_width ()))#line:2129
        OO00OO0O00OOOOOO0 .search_data (OO00OO0O00OOOOOO0 )#line:2130
    def resize (OO0O0O000000O00O0 ,OOO0OOOO00O00OO0O ,OOOO0O00OOO0000OO ,OOOOO00O0OOOO00OO ):#line:2132
        ""#line:2136
        if sys .version_info [0 ]==3 :#line:2137
            OOOOOO000000000OO =OOO0OOOO00O00OO0O .width ()#line:2138
            O000000OO00O0000O =OOO0OOOO00O00OO0O .height ()#line:2139
            OO000O000OOO00OOO =max (OOOOOO000000000OO ,O000000OO00O0000O )#line:2140
            OO0OO000O000O00OO =max (OOOO0O00OOO0000OO ,OOOOO00O0OOOO00OO )#line:2141
            if OO000O000OOO00OOO >OO0OO000O000O00OO :#line:2142
                return OOO0OOOO00O00OO0O .subsample (int (OO000O000OOO00OOO /OO0OO000O000O00OO ))#line:2143
            else :#line:2144
                return OOO0OOOO00O00OO0O .zoom (int (OO0OO000O000O00OO /OO000O000OOO00OOO ))#line:2145
        else :#line:2146
            OOOOOO000000000OO =OOO0OOOO00O00OO0O .width ()#line:2147
            O000000OO00O0000O =OOO0OOOO00O00OO0O .height ()#line:2148
            OO000O000OOO00OOO =max (OOOOOO000000000OO ,O000000OO00O0000O )#line:2149
            OO0OO000O000O00OO =max (OOOO0O00OOO0000OO ,OOOOO00O0OOOO00OO )#line:2150
            if OO000O000OOO00OOO >OO0OO000O000O00OO :#line:2151
                return OOO0OOOO00O00OO0O .subsample (OO000O000OOO00OOO /OO0OO000O000O00OO )#line:2152
            else :#line:2153
                return OOO0OOOO00O00OO0O .zoom (OO0OO000O000O00OO /OO000O000OOO00OOO )#line:2154
    def image_return (OO0O0000OOO00000O ,OOOOO000000000000 ):#line:2156
        return OOOOO000000000000 #line:2157
    def download_image (OO0OOO00O0O0O00O0 ,O0OO0O0OOO000O0OO ):#line:2159
        OO0OOO0000OOO0O00 =O0OO0O0OOO000O0OO [O0OO0O0OOO000O0OO .rfind ('/')+1 :]#line:2161
        OO0OO000OO00O0O00 =os .path .join (OO0OOO00O0O0O00O0 .appdata_dir ,OO0OOO0000OOO0O00 )#line:2162
        OO0O0OOOOOOO0000O =OO0OO000OO00O0O00 [:-3 ]+"png"#line:2163
        OO0OO00O00O000O00 =threading .Timer (2 ,OO0OOO00O0O0O00O0 .image_return ,args =(OO0O0OOOOOOO0000O ,))#line:2164
        OO0OO00O00O000O00 .start ()#line:2165
        if not os .path .exists (OO0O0OOOOOOO0000O )and not OO0OOO00O0O0O00O0 .is_mac :#line:2166
            if OO0OOO00O0O0O00O0 .is_windows :#line:2167
                OO000OOO00OOO0OOO =os .path .join (os .path .dirname (__file__ ),"imagemagick","convert")#line:2168
                subprocess .check_call ([OO000OOO00OOO0OOO ,O0OO0O0OOO000O0OO .replace ("https","http"),OO0O0OOOOOOO0000O ],shell =True )#line:2169
            else :#line:2170
                subprocess .call ("convert "+O0OO0O0OOO000O0OO .replace ("https","http")+" "+OO0O0OOOOOOO0000O ,shell =True )#line:2171
        if OO0OOO00O0O0O00O0 .is_mac :#line:2172
            if not os .path .exists (OO0O0OOOOOOO0000O ):#line:2173
                with open (OO0OO000OO00O0O00 ,"wb")as OOOOOOOO0OO000000 :#line:2174
                    if sys .version_info [0 ]==3 :#line:2175
                        O0O00OOOO0O00OO00 =urllib .request .urlopen (O0OO0O0OOO000O0OO ).read ()#line:2176
                    else :#line:2177
                        O0O00OOOO0O00OO00 =urllib2 .urlopen (O0OO0O0OOO000O0OO ).read ()#line:2178
                    OOOOOOOO0OO000000 .write (O0O00OOOO0O00OO00 )#line:2179
                    OOOOOOOO0OO000000 .close ()#line:2180
                    subprocess .check_call (["sips","-s","format","gif","%s"%OO0OO000OO00O0O00 ,"--out","%s"%OO0O0OOOOOOO0000O ],shell =True )#line:2181
        return OO0O0OOOOOOO0000O #line:2182
    def update_search (OOO0000O0000O0OOO ,O0000O00O00OOOO00 ):#line:2184
        OOO00O000O0OOO0O0 =OOO0000O0000O0OOO .frames [O0000O00O00OOOO00 ]#line:2185
        O0000O00O00OOOO00 +=1 #line:2186
        if O0000O00O00OOOO00 ==30 :#line:2187
            O0000O00O00OOOO00 =0 #line:2188
        OOO0000O0000O0OOO .search_gif .config (image =OOO00O000O0OOO0O0 )#line:2189
        OOO0000O0000O0OOO .search_after =OOO0000O0000O0OOO .parent .after (30 ,OOO0000O0000O0OOO .update_search ,O0000O00O00OOOO00 )#line:2190
    def update_load (OO0OO000OO0O0OOO0 ,OO000OO0O000O00OO ):#line:2192
        O0O0OOOO00O0OOO00 =OO0OO000OO0O0OOO0 .frames [OO000OO0O000O00OO ]#line:2193
        OO000OO0O000O00OO +=1 #line:2194
        if OO000OO0O000O00OO ==30 :#line:2195
            OO000OO0O000O00OO =0 #line:2196
        OO0OO000OO0O0OOO0 .load_gif .config (image =O0O0OOOO00O0OOO00 )#line:2197
        OO0OO000OO0O0OOO0 .load_after =OO0OO000OO0O0OOO0 .parent .after (30 ,OO0OO000OO0O0OOO0 .update_load ,OO000OO0O000O00OO )#line:2198
    def mouse_wheel_callback (O0OO00O0000O0O000 ,OOO00OOO00OOO0OO0 ):#line:2200
        O0OO00O0000O0O000 .canvas .yview_scroll (int (-1 *(OOO00OOO00OOO0OO0 .delta /120 )),"units")#line:2201
    def search_data (OOOO0OO00O00O0OOO ,O0O00O0O00OOOOOOO ,current_page =1 ):#line:2204
        if not OOOO0OO00O00O0OOO .is_searching and len (OOOO0OO00O00O0OOO .search_entry .get ())>0 :#line:2205
            OOOO0OO00O00O0OOO .is_searching =True #line:2206
            OOOO0OO00O00O0OOO .search_button .config (state ="disabled")#line:2207
            OOOO0OO00O00O0OOO .search_entry .config (state ="disabled",disabledbackground ="white")#line:2208
            print ("searched page: %d"%current_page )#line:2211
            OOOO0OO00O00O0OOO .search_thread =threading .Thread (target =OOOO0OO00O00O0OOO .insert_data ,kwargs ={'current_page':current_page })#line:2212
            OOOO0OO00O00O0OOO .search_thread .setDaemon (True )#line:2213
            OOOO0OO00O00O0OOO .search_thread .start ()#line:2214
            OOOO0OO00O00O0OOO .table_frame .lower ()#line:2215
            OOOO0OO00O00O0OOO .pages_frame .destroy ()#line:2216
            OOOO0OO00O00O0OOO .search_gif .lift ()#line:2217
            OOOO0OO00O00O0OOO .search_after =OOOO0OO00O00O0OOO .parent .after (0 ,OOOO0OO00O00O0OOO .update_search ,0 )#line:2218
    def request_callback (O0O0OO0OO00000OO0 ,O0OO0OOOOO0O0OOOO ):#line:2220
        webbrowser .open ("https://www.cognitoforms.com/SnapEDA/PartRequestForm",new =2 )#line:2221
    def insert_data (O000OOOOO0O000OO0 ,current_page =1 ):#line:2223
        ""#line:2226
        O000OOOOO0O000OO0 .intense_caverns_links =[]#line:2228
        O000OOOOO0O000OO0 .intense_caverns_img_dir =[]#line:2229
        O000OOOOO0O000OO0 .intense_caverns_thread_started =[]#line:2230
        OOOOO0OOOO0OO00O0 =os .path .join (O000OOOOO0O000OO0 .appdata_dir ,"info.json")#line:2233
        with open (OOOOO0OOOO0OO00O0 )as O0O00O0OOOO0O000O :#line:2234
            O0000O00O00O0OO00 =json .load (O0O00O0OOOO0O000O )#line:2235
        OOOOOO0O0OO0OO00O =O0000O00O00O0OO00 ['username']#line:2236
        O000OOOOO0O000OO0 .token ="XbBKBKXLpgRYz96cfSaQDpToMmHFg6jH"#line:2238
        OOO000O00OO0OOO0O ={'User-Agent':"Kicad"}#line:2239
        OOO0O00O00O0O0OO0 =str (O000OOOOO0O000OO0 .search_entry .get ()).replace (" ","%20")#line:2240
        O0O0OO00OO00OOO00 ="https://www.snapeda.com/api/v1/parts/search?q=%s&token=%s&page=%s&ref=%s&username=%s"%(OOO0O00O00O0O0OO0 ,O000OOOOO0O000OO0 .token ,str (current_page ),"kicad-plugin",OOOOOO0O0OO0OO00O )#line:2242
        print ('Search URL: '+O0O0OO00OO00OOO00 )#line:2243
        try :#line:2244
            O000OOOOO0O000OO0 .message_frame .destroy ()#line:2245
        except :#line:2246
            pass #line:2247
        try :#line:2248
            if sys .version_info [0 ]==3 :#line:2249
                O0O0OO0O0O000OO0O =urllib .request .Request (O0O0OO00OO00OOO00 ,headers =OOO000O00OO0OOO0O )#line:2250
                O0O0OO0O00OO0O0O0 =urllib .request .urlopen (O0O0OO0O0O000OO0O ,timeout =5 ).read ()#line:2251
            else :#line:2252
                O0O0OO0O0O000OO0O =urllib2 .Request (O0O0OO00OO00OOO00 ,headers =OOO000O00OO0OOO0O )#line:2253
                O0O0OO0O00OO0O0O0 =urllib2 .urlopen (O0O0OO0O0O000OO0O ,timeout =5 ).read ()#line:2254
            O000OOOOO0O000OO0 .data =json .loads (O0O0OO0O00OO0O0O0 )#line:2255
            if len (O000OOOOO0O000OO0 .data ["results"])==0 :#line:2256
                raise KeyError #line:2257
        except :#line:2258
            print ("503 Error")#line:2260
            O000OOOOO0O000OO0 .canvas .yview_moveto (0 )#line:2261
            for O0O0OOOO000OO0OOO in O000OOOOO0O000OO0 .canvas_frame .winfo_children ():#line:2262
                O0O0OOOO000OO0OOO .destroy ()#line:2263
            O000OOOOO0O000OO0 .search_button .config (state ="normal")#line:2264
            O000OOOOO0O000OO0 .parent .after_cancel (O000OOOOO0O000OO0 .search_after )#line:2265
            O000OOOOO0O000OO0 .is_searching =False #line:2266
            O000OOOOO0O000OO0 .search_gif .lower ()#line:2267
            O000OOOOO0O000OO0 .search_gif .config (image ="")#line:2268
            O000OOOOO0O000OO0 .current_page =current_page #line:2269
            O000OOOOO0O000OO0 .message_frame =tk .Label (O000OOOOO0O000OO0 .results_frame ,bg ="white",cursor ="hand2",justify =tk .CENTER ,anchor ='center')#line:2271
            O000OOOOO0O000OO0 .message_frame .grid_columnconfigure (0 ,weight =1 )#line:2272
            O000OOOOO0O000OO0 .message_frame .grid_rowconfigure (0 ,weight =1 )#line:2273
            O000OOOOO0O000OO0 .message_frame .grid (row =0 ,column =0 ,sticky ='NEWS')#line:2274
            O000OOOOO0O000OO0 .empty_result_text =tk .Text (O000OOOOO0O000OO0 .message_frame ,bg ="white",cursor ="hand2",relief =tk .FLAT )#line:2276
            O000OOOOO0O000OO0 .empty_result_text .grid (row =0 ,column =0 ,sticky ="EW")#line:2277
            O000OOOOO0O000OO0 .empty_result_text .tag_configure ('keyword_font',font =('Open Sans',11 ,"bold"))#line:2278
            O000OOOOO0O000OO0 .empty_result_text .tag_configure ('normal_font',font =('Open Sans',11 ))#line:2279
            O000OOOOO0O000OO0 .empty_result_text .tag_configure ('underline_font',font =('Open Sans',11 ,"underline"))#line:2280
            O000OOOOO0O000OO0 .empty_result_text .tag_configure ('justify_center',justify =tk .CENTER )#line:2281
            O000OOOOO0O000OO0 .empty_result_text .insert (tk .END ,"Your search for - ",('normal_font','justify_center'))#line:2282
            O000OOOOO0O000OO0 .empty_result_text .insert (tk .END ,O000OOOOO0O000OO0 .search_entry .get (),('keyword_font','justify_center'))#line:2283
            O000OOOOO0O000OO0 .empty_result_text .insert (tk .END ," - did not match any parts.\nBut, never fear! You can request it ",('normal_font','justify_center'))#line:2284
            O000OOOOO0O000OO0 .empty_result_text .insert (tk .END ,"here",('underline_font','justify_center'))#line:2285
            O000OOOOO0O000OO0 .empty_result_text .config (state =tk .DISABLED )#line:2286
            O000OOOOO0O000OO0 .empty_result_text .bind ('<Button-1>',O000OOOOO0O000OO0 .request_callback )#line:2290
            O000OOOOO0O000OO0 .search_button .config (state ="normal")#line:2293
            O000OOOOO0O000OO0 .parent .after_cancel (O000OOOOO0O000OO0 .search_after )#line:2294
            O000OOOOO0O000OO0 .search_entry .config (state ="normal")#line:2295
            return #line:2297
        O000OOOOO0O000OO0 .page_names =[]#line:2298
        if O000OOOOO0O000OO0 .max_page ==0 :#line:2299
            O000OOOOO0O000OO0 .max_page =1 #line:2300
            O000OOOOO0O000OO0 .page_names .append (1 )#line:2301
            O000OOOOO0O000OO0 .selected_index =0 #line:2302
        else :#line:2303
            for OOOO0O00O000OOO00 in O000OOOOO0O000OO0 .data ["pages"]:#line:2304
                O000OOOOO0O000OO0 .page_names .append (int (OOOO0O00O000OOO00 ["name"]))#line:2305
                if OOOO0O00O000OOO00 ["is_current"]:#line:2306
                    O000OOOOO0O000OO0 .selected_index =len (O000OOOOO0O000OO0 .page_names )-1 #line:2307
            if len (O000OOOOO0O000OO0 .page_names )>0 :#line:2308
                O000OOOOO0O000OO0 .max_page =max (O000OOOOO0O000OO0 .page_names )#line:2309
            else :#line:2310
                O000OOOOO0O000OO0 .max_page =0 #line:2311
        O000OOOOO0O000OO0 .canvas .yview_moveto (0 )#line:2314
        O000OOOOO0O000OO0 .canvas_frame .grid_rowconfigure (0 ,weight =0 )#line:2315
        for O00O0O000000O0OOO in range (19 ):#line:2316
            O000OOOOO0O000OO0 .canvas_frame .grid_rowconfigure (O00O0O000000O0OOO +1 ,weight =0 )#line:2317
        for O0O0OOOO000OO0OOO in O000OOOOO0O000OO0 .canvas_frame .winfo_children ():#line:2318
            O0O0OOOO000OO0OOO .destroy ()#line:2319
        for O00O0O000000O0OOO in range (5 ):#line:2323
            O000OOOOO0O000OO0 .canvas_frame .grid_rowconfigure (O00O0O000000O0OOO +1 ,weight =1 )#line:2324
        for O00O0O000000O0OOO in range (len (O000OOOOO0O000OO0 .data ["results"])):#line:2325
            O000OOOOO0O000OO0 .canvas_frame .grid_rowconfigure (O00O0O000000O0OOO +1 ,weight =1 )#line:2326
        O000OOOOO0O000OO0 .i =1 #line:2327
        O000OOOOO0O000OO0 .manufacturer_labels =[]#line:2328
        O000OOOOO0O000OO0 .available_labels =[]#line:2329
        O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (0 ,weight =2 )#line:2330
        O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (1 ,weight =2 )#line:2331
        O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (2 ,weight =2 )#line:2332
        O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (3 ,weight =2 )#line:2333
        O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (4 ,weight =2 )#line:2334
        O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (5 ,weight =1 )#line:2335
        O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (6 ,weight =3 )#line:2336
        O000OOOOO0O000OO0 .canvas_frame .update ()#line:2354
        OOOO0OO000OO00OOO ="#304E70"#line:2357
        if not O000OOOOO0O000OO0 .side_opened :#line:2359
            O0000O0O000OO0O0O =tk .Frame (O000OOOOO0O000OO0 .canvas_frame ,bg ="#E1E1E1")#line:2360
            O0000O0O000OO0O0O .grid_columnconfigure (0 ,weight =1 )#line:2361
            O0000O0O000OO0O0O .grid_rowconfigure (0 ,weight =1 )#line:2362
            O0000O0O000OO0O0O .grid (row =0 ,column =0 ,columnspan =1 ,sticky ="NEWS",padx =(5 ,0 ))#line:2370
            O0000OOOO0000OOOO =tk .Label (O0000O0O000OO0O0O ,fg =OOOO0OO000OO00OOO ,bg ="white",font =("Open Sans",9 ,"bold"),text ="Manufacturer")#line:2378
            O0000OOOO0000OOOO .grid (row =0 ,column =0 ,columnspan =1 ,sticky ="NEWS",pady =(0 ,1 ))#line:2386
            O000OOOOO0O000OO0 .manufacturer_labels .append (O0000O0O000OO0O0O )#line:2387
        O00OO00OOO00O0OOO =tk .Frame (O000OOOOO0O000OO0 .canvas_frame ,bg ="#E1E1E1")#line:2389
        O00OO00OOO00O0OOO .grid_columnconfigure (0 ,weight =1 )#line:2390
        O00OO00OOO00O0OOO .grid_rowconfigure (0 ,weight =1 )#line:2391
        O00OO00OOO00O0OOO .grid (row =0 ,column =1 ,columnspan =1 ,sticky ="NEWS",padx =(0 ,0 ))#line:2399
        tk .Label (O00OO00OOO00O0OOO ,fg =OOOO0OO000OO00OOO ,bg ="white",height =4 ,font =("Open Sans",9 ,"bold"),text ="Image").grid (row =0 ,column =0 ,sticky ="NEWS",pady =(0 ,1 ))#line:2414
        O000O000O00OO0O00 =tk .Frame (O000OOOOO0O000OO0 .canvas_frame ,bg ="#E1E1E1")#line:2415
        O000O000O00OO0O00 .grid_columnconfigure (0 ,weight =1 )#line:2416
        O000O000O00OO0O00 .grid_rowconfigure (0 ,weight =1 )#line:2417
        O000O000O00OO0O00 .grid (row =0 ,column =2 ,columnspan =2 ,sticky ="NEWS")#line:2422
        tk .Label (O000O000O00OO0O00 ,fg =OOOO0OO000OO00OOO ,bg ="white",font =("Open Sans",9 ,"bold"),text ="Part").grid (row =0 ,column =0 ,columnspan =1 ,pady =(0 ,1 ),sticky ="NEWS")#line:2436
        O00O0O0O00OOO0OOO =tk .Frame (O000OOOOO0O000OO0 .canvas_frame ,bg ="#E1E1E1")#line:2461
        O00O0O0O00OOO0OOO .grid_columnconfigure (0 ,weight =1 )#line:2462
        O00O0O0O00OOO0OOO .grid_rowconfigure (0 ,weight =1 )#line:2463
        O00O0O0O00OOO0OOO .grid (row =0 ,column =4 ,columnspan =1 ,padx =(0 ,0 ),sticky ="NEWS")#line:2469
        tk .Label (O00O0O0O00OOO0OOO ,fg =OOOO0OO000OO00OOO ,bg ="white",anchor ="w",font =("Open Sans",9 ,"bold"),text ="       Description").grid (row =0 ,column =0 ,columnspan =1 ,pady =(0 ,1 ),sticky ="NEWS")#line:2483
        OO000OO00OO0OOO00 =tk .Frame (O000OOOOO0O000OO0 .canvas_frame ,bg ="#E1E1E1")#line:2484
        OO000OO00OO0OOO00 .grid_columnconfigure (0 ,weight =1 )#line:2485
        OO000OO00OO0OOO00 .grid_rowconfigure (0 ,weight =1 )#line:2486
        OO000OO00OO0OOO00 .grid (row =0 ,column =5 ,columnspan =1 ,sticky ="NEWS")#line:2491
        tk .Label (OO000OO00OO0OOO00 ,fg =OOOO0OO000OO00OOO ,bg ="white",font =("Open Sans",9 ,"bold"),text ="Package").grid (row =0 ,column =0 ,pady =(0 ,1 ),sticky ="NEWS")#line:2503
        OO0O0O0OO0O000O0O =tk .Frame (O000OOOOO0O000OO0 .canvas_frame ,bg ="#E1E1E1")#line:2504
        OO0O0O0OO0O000O0O .grid_columnconfigure (0 ,weight =1 )#line:2505
        OO0O0O0OO0O000O0O .grid_rowconfigure (0 ,weight =1 )#line:2506
        OO0O0O0OO0O000O0O .grid (row =0 ,column =6 ,columnspan =1 ,sticky ="NEWS")#line:2511
        tk .Label (OO0O0O0OO0O000O0O ,fg =OOOO0OO000OO00OOO ,bg ="white",font =("Open Sans",9 ,"bold"),text ="Data Available").grid (row =0 ,column =0 ,pady =(0 ,1 ),sticky ="NEWS")#line:2523
        O000OOOOO0O000OO0 .results_frame .update ()#line:2526
        O000OOOOO0O000OO0 .dual_frame .update ()#line:2527
        OO0OO00OOOO0O00OO =len (O000OOOOO0O000OO0 .data ["results"])*O000OOOOO0O000OO0 .results_frame .winfo_height ()/6 #line:2528
        O000OOOOO0O000OO0 .canvas .update ()#line:2529
        O000OOOOO0O000OO0 .canvas .itemconfigure ("inner_frame",height =400 )#line:2532
        O000OOOOO0O000OO0 .canvas_frame .config (height =400 )#line:2533
        if len (O000OOOOO0O000OO0 .data ["results"])>6 :#line:2534
            O000OOOOO0O000OO0 .canvas .itemconfigure ("inner_frame",height =OO0OO00OOOO0O00OO )#line:2535
            OO00O000O0OO00O00 =ttk .Style ()#line:2536
            OO00O000O0OO00O00 .theme_use ('clam')#line:2537
            OO00O000O0OO00O00 .configure ("snapeda.Vertical.TScrollbar",gripcount =0 ,background ="#FF8330",troughcolor ='#C4C4C4',lightcolor ='#C4C4C4',darkcolor ='#C4C4C4',bordercolor ="#C4C4C4",borderwidth =0 ,relief =tk .FLAT )#line:2538
            OO00O000O0OO00O00 .map ('snapeda.Vertical.TScrollbar',foreground =[('disabled','#C4C4C4'),('pressed','#FF8330'),('active','#FF8330')],background =[('disabled','#C4C4C4'),('pressed','!focus','#FF8330'),('active','#FF8330')],highlightcolor =[('focus','#C4C4C4'),('!focus','#C4C4C4')],)#line:2546
            OO00O000O0OO00O00 .layout ('snapeda.Vertical.TScrollbar',[('Vertical.Scrollbar.trough',{'children':[('Vertical.Scrollbar.thumb',{'expand':'1','sticky':'nswe'})],'sticky':'ns'})])#line:2548
            O000OOOOO0O000OO0 .vsb =ttk .Scrollbar (O000OOOOO0O000OO0 .results_frame ,orient ="vertical",command =O000OOOOO0O000OO0 .canvas .yview ,style ="snapeda.Vertical.TScrollbar")#line:2549
            O000OOOOO0O000OO0 .canvas .bind_all ("<MouseWheel>",O000OOOOO0O000OO0 .mouse_wheel_callback )#line:2550
            O000OOOOO0O000OO0 .vsb .grid (row =0 ,column =1 ,sticky ='NS')#line:2551
            O000OOOOO0O000OO0 .canvas .config (yscrollcommand =O000OOOOO0O000OO0 .vsb .set )#line:2552
            O000OOOOO0O000OO0 .canvas .config (scrollregion =O000OOOOO0O000OO0 .canvas .bbox ("all"))#line:2553
        print ("frame height %d"%O000OOOOO0O000OO0 .results_frame .winfo_height ())#line:2555
        print ("height %d"%OO0OO00OOOO0O00OO )#line:2556
        print ("searched")#line:2558
        OO000O0OO0O0O00OO =15 #line:2560
        OO0OO0OOO000000OO =tk .PhotoImage (file =O000OOOOO0O000OO0 .datasheet_available_dir )#line:2561
        OOOO00O00O0000OO0 =O000OOOOO0O000OO0 .resize (OO0OO0OOO000000OO ,OO000O0OO0O0O00OO ,OO000O0OO0O0O00OO )#line:2562
        O000OOOOO0O000OO0 .parent .images .append (OOOO00O00O0000OO0 )#line:2563
        OOO0O0OOO00O00000 =tk .PhotoImage (file =O000OOOOO0O000OO0 .datasheet_not_available_dir )#line:2564
        OO00OO000000O000O =O000OOOOO0O000OO0 .resize (OOO0O0OOO00O00000 ,OO000O0OO0O0O00OO ,OO000O0OO0O0O00OO )#line:2565
        O000OOOOO0O000OO0 .parent .images .append (OO00OO000000O000O )#line:2566
        OO00OO0O00O0OO000 =tk .PhotoImage (file =O000OOOOO0O000OO0 .symbol_available_dir )#line:2568
        OO0O00000O00O0000 =O000OOOOO0O000OO0 .resize (OO00OO0O00O0OO000 ,OO000O0OO0O0O00OO ,OO000O0OO0O0O00OO )#line:2569
        O000OOOOO0O000OO0 .parent .images .append (OO0O00000O00O0000 )#line:2570
        OO00O00O0O00OOOO0 =tk .PhotoImage (file =O000OOOOO0O000OO0 .symbol_not_available_dir )#line:2571
        O0000O00O000000O0 =O000OOOOO0O000OO0 .resize (OO00O00O0O00OOOO0 ,OO000O0OO0O0O00OO ,OO000O0OO0O0O00OO )#line:2572
        O000OOOOO0O000OO0 .parent .images .append (O0000O00O000000O0 )#line:2573
        O0O00O0OO000O0O0O =tk .PhotoImage (file =O000OOOOO0O000OO0 .footprint_available_dir )#line:2575
        O000OOO0OO000OOO0 =O000OOOOO0O000OO0 .resize (O0O00O0OO000O0O0O ,OO000O0OO0O0O00OO ,OO000O0OO0O0O00OO )#line:2576
        O000OOOOO0O000OO0 .parent .images .append (O000OOO0OO000OOO0 )#line:2577
        O0O0OO00O00OO0O0O =tk .PhotoImage (file =O000OOOOO0O000OO0 .footprint_not_available_dir )#line:2578
        O0O0O0000O0000O00 =O000OOOOO0O000OO0 .resize (O0O0OO00O00OO0O0O ,OO000O0OO0O0O00OO ,OO000O0OO0O0O00OO )#line:2579
        O000OOOOO0O000OO0 .parent .images .append (O0O0O0000O0000O00 )#line:2580
        OO00OO0O00OOO00OO =tk .PhotoImage (file =O000OOOOO0O000OO0 .threedee_available_dir )#line:2582
        OO0000O00O00O0000 =O000OOOOO0O000OO0 .resize (OO00OO0O00OOO00OO ,OO000O0OO0O0O00OO ,OO000O0OO0O0O00OO )#line:2583
        O000OOOOO0O000OO0 .parent .images .append (OO0000O00O00O0000 )#line:2584
        OO000O0OOO0O000OO =tk .PhotoImage (file =O000OOOOO0O000OO0 .threedee_unavailable_dir )#line:2585
        O0000000OO0OO0O0O =O000OOOOO0O000OO0 .resize (OO000O0OOO0O000OO ,OO000O0OO0O0O00OO ,OO000O0OO0O0O00OO )#line:2586
        O000OOOOO0O000OO0 .parent .images .append (O0000000OO0OO0O0O )#line:2587
        O000OOOOO0O000OO0 .organization_images ={}#line:2589
        O000OOOOO0O000OO0 .manufacturer_names =[]#line:2590
        O000OOOOO0O000OO0 .is_searching =False #line:2592
        O000OOOOO0O000OO0 .search_gif .lower ()#line:2593
        O000OOOOO0O000OO0 .search_gif .config (image ="")#line:2594
        for OO0OOOOO0OOOO000O in O000OOOOO0O000OO0 .data ["results"]:#line:2596
            OO0OO0000OOOO00OO =O000OOOOO0O000OO0 .i -1 #line:2598
            O000OOOOO0O000OO0 .intense_caverns_links .insert (OO0OO0000OOOO00OO ,None )#line:2599
            O000OOOOO0O000OO0 .intense_caverns_img_dir .insert (OO0OO0000OOOO00OO ,None )#line:2600
            O000OOOOO0O000OO0 .intense_caverns_thread_started .insert (OO0OO0000OOOO00OO ,False )#line:2601
            O0O0O000OOO0OO000 =threading .Thread (target =O000OOOOO0O000OO0 .get_intense_caverns_link ,args =(OO0OO0000OOOO00OO ,))#line:2602
            O0O0O000OOO0OO000 .setDaemon (True )#line:2603
            O0O0O000OOO0OO000 .start ()#line:2604
            if O000OOOOO0O000OO0 .i %2 ==0 :#line:2606
                OO0O0000000O0000O ="white"#line:2607
            else :#line:2608
                OO0O0000000O0000O ="white"#line:2610
            O0O000000O0O0OO00 =""#line:2611
            if any ([OO0OOOOO0OOOO000O ["has_footprint"],OO0OOOOO0OOOO000O ["has_datasheet"],OO0OOOOO0OOOO000O ["has_symbol"]]):#line:2615
                if OO0OOOOO0OOOO000O ["has_footprint"]:#line:2616
                    O0O000000O0O0OO00 +="Footprint, "#line:2617
                if OO0OOOOO0OOOO000O ["has_datasheet"]:#line:2618
                    O0O000000O0O0OO00 +="Datasheet, "#line:2619
                if OO0OOOOO0OOOO000O ["has_symbol"]:#line:2620
                    O0O000000O0O0OO00 +="Symbol"#line:2621
                if O0O000000O0O0OO00 .endswith (", "):#line:2622
                    O0O000000O0O0OO00 =O0O000000O0O0OO00 [:-2 ]#line:2623
            else :#line:2624
                O0O000000O0O0OO00 ="No Data"#line:2625
            O000OOOOO0O000OO0 .is_loading =False #line:2646
            if not O000OOOOO0O000OO0 .side_opened :#line:2648
                try :#line:2649
                    OOO0O00O00OO0O0O0 =OO0OOOOO0OOOO000O ["organization_image_100_20"]#line:2650
                    O0OO0O0OOOO0000OO =O000OOOOO0O000OO0 .download_image (OOO0O00O00OO0O0O0 )#line:2651
                    OO0000O00OO0OOO0O =tk .PhotoImage (file =O0OO0O0OOOO0000OO )#line:2652
                    O000O0OO000O0O0OO =O000OOOOO0O000OO0 .resize (OO0000O00OO0OOO0O ,100 ,20 )#line:2653
                    O000OOOOO0O000OO0 .parent .images .append (O000O0OO000O0O0OO )#line:2654
                    O000OOOOO0O000OO0 .organization_images [O000OOOOO0O000OO0 .i ]=O000O0OO000O0O0OO #line:2655
                    OO0O00OO0O00000O0 =tk .Label (O000OOOOO0O000OO0 .canvas_frame ,image =O000O0OO000O0O0OO ,bg =OO0O0000000O0000O ,font =("Open Sans",9 ),cursor ="hand2")#line:2656
                    OO0O00OO0O00000O0 .grid (row =O000OOOOO0O000OO0 .i ,column =0 ,columnspan =1 ,sticky ="NESW")#line:2657
                    OO0O00OO0O00000O0 .bind ("<Button-1>",lambda O0OOO00OOO0O0OO0O ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (O0OOO00OOO0O0OO0O ,index ))#line:2658
                except BaseException :#line:2659
                    print ("No Organization Image")#line:2660
                    O000OOOOO0O000OO0 .organization_image =None #line:2661
                    print (OO0OOOOO0OOOO000O )#line:2662
                    OO0O00OO0O00000O0 =tk .Label (O000OOOOO0O000OO0 .canvas_frame ,text =OO0OOOOO0OOOO000O ["manufacturer"],bg =OO0O0000000O0000O ,font =("Open Sans",9 ),cursor ="hand2")#line:2663
                    OO0O00OO0O00000O0 .grid (row =O000OOOOO0O000OO0 .i ,column =0 ,columnspan =1 ,sticky ="NESW")#line:2664
                    OO0O00OO0O00000O0 .bind ("<Button-1>",lambda OO0OO0OO0O0OOO000 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OO0OO0OO0O0OOO000 ,index ))#line:2665
                O000OOOOO0O000OO0 .manufacturer_labels .append (OO0O00OO0O00000O0 )#line:2666
            try :#line:2668
                OO0OO00OOO000OOOO =OO0OOOOO0OOOO000O ["coverart"][0 ]["url"]#line:2669
                O0OO0O0OOOO0000OO =O000OOOOO0O000OO0 .download_image (OO0OO00OOO000OOOO )#line:2670
                O0O0OO0O0000O00O0 =tk .PhotoImage (file =O0OO0O0OOOO0000OO )#line:2671
                OOO0OOO00OO0OOO0O =O000OOOOO0O000OO0 .resize (O0O0OO0O0000O00O0 ,55 ,55 )#line:2672
                O000OOOOO0O000OO0 .parent .images .append (OOO0OOO00OO0OOO0O )#line:2673
                OO000O0000OOO0O0O =tk .Label (O000OOOOO0O000OO0 .canvas_frame ,bg =OO0O0000000O0000O ,image =OOO0OOO00OO0OOO0O ,cursor ="hand2")#line:2674
                OO000O0000OOO0O0O .bind ("<Button-1>",lambda OOOO00O0OO00O00OO ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OOOO00O0OO00O00OO ,index ))#line:2675
                OO000O0000OOO0O0O .grid (row =O000OOOOO0O000OO0 .i ,column =1 ,columnspan =1 ,sticky ="NESW")#line:2676
            except BaseException :#line:2677
                print ("No Symbol Image")#line:2678
                OO000O0000OOO0O0O =tk .Label (O000OOOOO0O000OO0 .canvas_frame ,bg =OO0O0000000O0000O ,cursor ="hand2")#line:2679
                OO000O0000OOO0O0O .grid (row =O000OOOOO0O000OO0 .i ,column =1 ,columnspan =1 ,sticky ="NESW")#line:2680
                OO000O0000OOO0O0O .bind ("<Button-1>",lambda O000000OO00OO0O00 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (O000000OO00OO0O00 ,index ))#line:2681
            O000O000O00OO0O00 =tk .Frame (O000OOOOO0O000OO0 .canvas_frame ,bg =OO0O0000000O0000O ,cursor ="hand2")#line:2683
            O000O000O00OO0O00 .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:2684
            O000O000O00OO0O00 .grid_rowconfigure (1 ,weight =1 ,uniform ="foo")#line:2685
            O000O000O00OO0O00 .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:2686
            O000O000O00OO0O00 .grid (row =O000OOOOO0O000OO0 .i ,column =2 ,columnspan =2 ,sticky ="NEWS")#line:2687
            O000O000O00OO0O00 .bind ("<Button-1>",lambda O000O0O0O0OO0O000 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (O000O0O0O0OO0O000 ,index ))#line:2688
            O0OO00O0O00O000OO =tk .Label (O000O000O00OO0O00 ,text =OO0OOOOO0OOOO000O ["part_number"],fg ="#304E70",bg =OO0O0000000O0000O ,font =("Open Sans",9 ),cursor ="hand2")#line:2697
            O0OO00O0O00O000OO .grid (row =0 ,column =0 ,columnspan =2 ,sticky ="S")#line:2702
            O0OO00O0O00O000OO .bind ("<Button-1>",lambda O000000O0O0O0OOO0 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (O000000O0O0O0OOO0 ,index ))#line:2703
            OO00OOOOOO0O0O00O =tk .Label (O000O000O00OO0O00 ,text =OO0OOOOO0OOOO000O ["manufacturer"],bg =OO0O0000000O0000O ,font =("Open Sans",9 ),cursor ="hand2")#line:2711
            OO00OOOOOO0O0O00O .grid (row =1 ,column =0 ,sticky ="N")#line:2715
            OO00OOOOOO0O0O00O .bind ("<Button-1>",lambda OO00000OO000O00O0 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OO00000OO000O00O0 ,index ))#line:2716
            O000OOOOO0O000OO0 .manufacturer_names .append (OO00OOOOOO0O0O00O )#line:2717
            O00O0O0O00OOO0OOO =tk .Message (O000OOOOO0O000OO0 .canvas_frame ,bg =OO0O0000000O0000O ,cursor ="hand2")#line:2724
            O00O0O0O00OOO0OOO .grid (row =O000OOOOO0O000OO0 .i ,column =4 ,columnspan =1 ,sticky ="NEWS")#line:2725
            O00O0O0O00OOO0OOO .grid_columnconfigure (0 ,weight =1 )#line:2726
            O00O0O0O00OOO0OOO .grid_rowconfigure (0 ,weight =1 )#line:2727
            O00O0O0O00OOO0OOO .bind ("<Button-1>",lambda OO000OOOOOOO0O000 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OO000OOOOOOO0O000 ,index ))#line:2728
            OOOOOO0O0OO00OO00 =OO0OOOOO0OOOO000O ["short_description"]#line:2729
            if len (OOOOOO0O0OO00OO00 )>85 :#line:2730
                OOOOOO0O0OO00OO00 =OOOOOO0O0OO00OO00 [:50 ]+"..."#line:2731
            OO0OO0OOO0000000O =tk .Message (O00O0O0O00OOO0OOO ,bg =OO0O0000000O0000O ,text =OOOOOO0O0OO00OO00 ,font =("Open Sans",8 ),cursor ="hand2",justify =tk .LEFT )#line:2734
            OO0OO0OOO0000000O .grid (row =0 ,column =0 ,sticky ="W",padx =(15 ,0 ))#line:2735
            OO0OO0OOO0000000O .bind ("<Button-1>",lambda O000OO00OO00000O0 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (O000OO00OO00000O0 ,index ))#line:2736
            if OO0OOOOO0OOOO000O ["package"]["name"]=="--------":#line:2737
                OO0OOOOO0OOOO000O ["package"]["name"]="N/A"#line:2738
            OOOOOOOOOOOO0OO00 =tk .Label (O000OOOOO0O000OO0 .canvas_frame ,bg =OO0O0000000O0000O ,text =OO0OOOOO0OOOO000O ["package"]["name"],font =("Open Sans",9 ),cursor ="hand2")#line:2739
            OOOOOOOOOOOO0OO00 .grid (row =O000OOOOO0O000OO0 .i ,column =5 ,columnspan =1 ,sticky ="NESW")#line:2740
            OOOOOOOOOOOO0OO00 .bind ("<Button-1>",lambda OOOO00000000O0000 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OOOO00000000O0000 ,index ))#line:2741
            O0O0O00O000OOOOOO =tk .Frame (O000OOOOO0O000OO0 .canvas_frame ,bg =OO0O0000000O0000O )#line:2743
            O0O0O00O000OOOOOO .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:2744
            O0O0O00O000OOOOOO .grid_columnconfigure (1 ,weight =1 ,uniform ="foo")#line:2745
            O0O0O00O000OOOOOO .grid_columnconfigure (2 ,weight =1 ,uniform ="foo")#line:2746
            O0O0O00O000OOOOOO .grid_columnconfigure (3 ,weight =1 ,uniform ="foo")#line:2747
            O0O0O00O000OOOOOO .grid_rowconfigure (0 ,weight =1 )#line:2748
            O0O0O00O000OOOOOO .grid (row =O000OOOOO0O000OO0 .i ,column =6 ,columnspan =1 ,sticky ="NESW")#line:2749
            O0O0O00O000OOOOOO .bind ("<Button-1>",lambda OO0O0000000O000O0 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OO0O0000000O000O0 ,index ))#line:2750
            if OO0OOOOO0OOOO000O ["has_datasheet"]:#line:2752
                O0O0O0O00OOOO00O0 =tk .Label (O0O0O00O000OOOOOO ,bg =OO0O0000000O0000O ,image =OOOO00O00O0000OO0 ,cursor ="hand2")#line:2753
                O0O0O0O00OOOO00O0 .grid (row =0 ,column =0 ,sticky ="EW")#line:2754
                O0O0O0O00OOOO00O0 .bind ("<Button-1>",lambda OO000O00OO0O0OO00 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OO000O00OO0O0OO00 ,index ))#line:2755
            else :#line:2756
                O0O0O0O00OOOO00O0 =tk .Label (O0O0O00O000OOOOOO ,bg =OO0O0000000O0000O ,image =OO00OO000000O000O ,cursor ="hand2")#line:2757
                O0O0O0O00OOOO00O0 .grid (row =0 ,column =0 ,sticky ="EW")#line:2758
                O0O0O0O00OOOO00O0 .bind ("<Button-1>",lambda OOO00000000O00OOO ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OOO00000000O00OOO ,index ))#line:2759
            if OO0OOOOO0OOOO000O ["has_symbol"]:#line:2760
                O0O000000O0O0O00O =tk .Label (O0O0O00O000OOOOOO ,bg =OO0O0000000O0000O ,image =OO0O00000O00O0000 ,cursor ="hand2")#line:2761
                O0O000000O0O0O00O .grid (row =0 ,column =1 ,sticky ="EW")#line:2762
                O0O000000O0O0O00O .bind ("<Button-1>",lambda O00000O00O00OO00O ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (O00000O00O00OO00O ,index ))#line:2763
            else :#line:2764
                O0O000000O0O0O00O =tk .Label (O0O0O00O000OOOOOO ,bg =OO0O0000000O0000O ,image =O0000O00O000000O0 ,cursor ="hand2")#line:2765
                O0O000000O0O0O00O .grid (row =0 ,column =1 ,sticky ="EW")#line:2766
                O0O000000O0O0O00O .bind ("<Button-1>",lambda OOOO0OO00000OO000 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OOOO0OO00000OO000 ,index ))#line:2767
            if OO0OOOOO0OOOO000O ["has_footprint"]:#line:2768
                OO000O0O0O0O00OOO =tk .Label (O0O0O00O000OOOOOO ,bg =OO0O0000000O0000O ,image =O000OOO0OO000OOO0 ,cursor ="hand2")#line:2769
                OO000O0O0O0O00OOO .grid (row =0 ,column =2 ,sticky ="EW")#line:2770
                OO000O0O0O0O00OOO .bind ("<Button-1>",lambda O00OO0O000O0OOO0O ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (O00OO0O000O0OOO0O ,index ))#line:2771
            else :#line:2772
                OO000O0O0O0O00OOO =tk .Label (O0O0O00O000OOOOOO ,bg =OO0O0000000O0000O ,image =O0O0O0000O0000O00 ,cursor ="hand2")#line:2773
                OO000O0O0O0O00OOO .grid (row =0 ,column =2 ,sticky ="EW")#line:2774
                OO000O0O0O0O00OOO .bind ("<Button-1>",lambda OO0OOOO00O0O0000O ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OO0OOOO00O0O0000O ,index ))#line:2775
            OOOOO0OOO00O0O0O0 ='models'in OO0OOOOO0OOOO000O and len (OO0OOOOO0OOOO000O ["models"])>0 and '3dmodel_medium'in OO0OOOOO0OOOO000O ["models"][0 ]and 'url'in OO0OOOOO0OOOO000O ["models"][0 ]['3dmodel_medium']#line:2777
            if OOOOO0OOO00O0O0O0 :#line:2778
                O0O0OO0O000000OOO =tk .Label (O0O0O00O000OOOOOO ,bg =OO0O0000000O0000O ,image =OO0000O00O00O0000 ,cursor ="hand2")#line:2779
                O0O0OO0O000000OOO .grid (row =0 ,column =3 ,sticky ="EW")#line:2780
                O0O0OO0O000000OOO .bind ("<Button-1>",lambda OO0OO00000O00O000 ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OO0OO00000O00O000 ,index ))#line:2781
            else :#line:2782
                O0O0OO0O000000OOO =tk .Label (O0O0O00O000OOOOOO ,bg =OO0O0000000O0000O ,image =O0000000OO0OO0O0O ,cursor ="hand2")#line:2783
                O0O0OO0O000000OOO .grid (row =0 ,column =3 ,sticky ="EW")#line:2784
                O0O0OO0O000000OOO .bind ("<Button-1>",lambda OO000O0O0000O0O0O ,index =O000OOOOO0O000OO0 .i -1 :O000OOOOO0O000OO0 .on_tree_select (OO000O0O0000O0O0O ,index ))#line:2785
            O000OOOOO0O000OO0 .i =O000OOOOO0O000OO0 .i +1 #line:2788
        O0OO00O0OOOO000O0 =tk .PhotoImage (file =O000OOOOO0O000OO0 .prev_bg_dir )#line:2790
        OO0O00OOO00OO0OOO =O000OOOOO0O000OO0 .resize (O0OO00O0OOOO000O0 ,55 ,55 )#line:2791
        O000OOOOO0O000OO0 .parent .images .append (OO0O00OOO00OO0OOO )#line:2792
        OO0O0O00000OO0OOO =tk .PhotoImage (file =O000OOOOO0O000OO0 .next_bg_dir )#line:2793
        O00OO0OO0O0O0O0O0 =O000OOOOO0O000OO0 .resize (OO0O0O00000OO0OOO ,55 ,55 )#line:2794
        O000OOOOO0O000OO0 .parent .images .append (O00OO0OO0O0O0O0O0 )#line:2795
        O000OOOOO0O000OO0 .pages_frame =tk .Frame (O000OOOOO0O000OO0 .table_frame ,bg ="#E1E1E1")#line:2796
        O000OOOOO0O000OO0 .pages_frame .grid (row =6 ,column =0 ,sticky ="W",padx =(0 ,0 ))#line:2797
        O000OOOOO0O000OO0 .pages_frame .grid_rowconfigure (0 ,weight =1 )#line:2798
        O00OOO00OO000OOOO =tk .PhotoImage (file =O000OOOOO0O000OO0 .selected_page_dir )#line:2799
        OOOOOO0OO0OOO00OO =O000OOOOO0O000OO0 .resize (O00OOO00OO000OOOO ,25 ,25 )#line:2800
        O000OOOOO0O000OO0 .parent .images .append (OOOOOO0OO0OOO00OO )#line:2801
        O000OOOOO0O000OO0 .pages =[]#line:2802
        for O00O0O000000O0OOO in range (len (O000OOOOO0O000OO0 .page_names )):#line:2805
            O000OOOOO0O000OO0 .pages .append (tk .Label (O000OOOOO0O000OO0 .pages_frame ,bg ="white",text =str (O000OOOOO0O000OO0 .page_names [O00O0O000000O0OOO ]),fg ="#304E70",cursor ="hand2",font =("Open Sans","10","bold"),width =4 ,height =2 ))#line:2820
            O000OOOOO0O000OO0 .pages [O00O0O000000O0OOO ].grid (row =0 ,column =O00O0O000000O0OOO +1 ,sticky ="NEWS",pady =(1 ,1 ))#line:2821
            O000OOOOO0O000OO0 .pages [O00O0O000000O0OOO ].bind ("<Button-1>",lambda O000OOO0000O0O0O0 ,current_page =O000OOOOO0O000OO0 .page_names [O00O0O000000O0OOO ]:O000OOOOO0O000OO0 .search_data (O000OOO0000O0O0O0 ,current_page =current_page ))#line:2822
        if O000OOOOO0O000OO0 .side_opened :#line:2824
            for OO000O00OOOOO00O0 in O000OOOOO0O000OO0 .manufacturer_names :#line:2825
                OO000O00OOOOO00O0 .config (fg ="#999999")#line:2826
            for O0000O0O0000O0000 in O000OOOOO0O000OO0 .manufacturer_labels :#line:2827
                O0000O0O0000O0000 .grid_forget ()#line:2828
            for O0000O0O0000O0000 in O000OOOOO0O000OO0 .available_labels :#line:2829
                O0000O0O0000O0000 .grid_forget ()#line:2830
            O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (0 ,weight =0 )#line:2831
            O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (1 ,weight =2 )#line:2832
            O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (2 ,weight =2 )#line:2833
            O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (3 ,weight =0 )#line:2834
            O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (4 ,weight =2 )#line:2835
            O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (5 ,weight =1 )#line:2836
            O000OOOOO0O000OO0 .canvas_frame .grid_columnconfigure (6 ,weight =3 )#line:2837
        O000OOOOO0O000OO0 .pages [O000OOOOO0O000OO0 .selected_index ].config (bg ="#FF761B",fg ="white")#line:2839
        O000OOOOO0O000OO0 .prev_button =tk .Label (O000OOOOO0O000OO0 .pages_frame ,text ="   < Prev   ",fg ="#FF761B",bg ="white",cursor ="hand2",font =("Open Sans","11","bold"))#line:2840
        O000OOOOO0O000OO0 .prev_button .grid (row =0 ,column =0 ,sticky ="NEWS",padx =(1 ,0 ),pady =(1 ,1 ))#line:2841
        O000OOOOO0O000OO0 .prev_button .bind ("<Button-1>",O000OOOOO0O000OO0 .prev_page )#line:2842
        O000OOOOO0O000OO0 .next_button =tk .Label (O000OOOOO0O000OO0 .pages_frame ,text ="   Next >   ",fg ="#FF761B",bg ="white",cursor ="hand2",font =("Open Sans","11","bold"))#line:2843
        O000OOOOO0O000OO0 .next_button .grid (row =0 ,column =len (O000OOOOO0O000OO0 .page_names )+1 ,sticky ="NEWS",padx =(0 ,1 ),pady =(1 ,1 ))#line:2844
        O000OOOOO0O000OO0 .next_button .bind ("<Button-1>",O000OOOOO0O000OO0 .next_page )#line:2845
        O000OOOOO0O000OO0 .search_button .config (state ="normal")#line:2848
        O000OOOOO0O000OO0 .parent .after_cancel (O000OOOOO0O000OO0 .search_after )#line:2849
        O000OOOOO0O000OO0 .search_entry .config (state ="normal")#line:2850
class WelcomeScreen (tk .Frame ):#line:2859
    ""#line:2862
    def __init__ (OO00O00O00O00OOOO ,O0O0OOOOOOOO0O000 ):#line:2864
        tk .Frame .__init__ (OO00O00O00O00OOOO ,O0O0OOOOOOOO0O000 )#line:2865
        OO00O00O00O00OOOO .parent =O0O0OOOOOOOO0O000 #line:2866
        OO00O00O00O00OOOO .dir_path =os .path .dirname (os .path .realpath (__file__ ))#line:2867
        OO00O00O00O00OOOO .is_mac =platform .mac_ver ()[0 ]!=""#line:2868
        OO00O00O00O00OOOO .is_windows =(os .name =='nt')#line:2869
        if OO00O00O00O00OOOO .is_windows :#line:2870
            OO00O00O00O00OOOO .windata_dir =os .path .join (os .getenv ('HOMEDRIVE'),os .getenv ('HOMEPATH'),"SnapEDA Kicad Plugin")#line:2873
            OO00O00O00O00OOOO .flip_table_dir =os .path .join (os .getenv ('APPDATA'),'kicad','fp-lib-table')#line:2876
            OO00O00O00O00OOOO .appdata_dir =os .path .join (OO00O00O00O00OOOO .windata_dir ,"App")#line:2877
            if not os .path .exists (OO00O00O00O00OOOO .windata_dir ):#line:2878
                os .makedirs (OO00O00O00O00OOOO .windata_dir )#line:2879
            if not os .path .exists (OO00O00O00O00OOOO .appdata_dir ):#line:2880
                os .makedirs (OO00O00O00O00OOOO .appdata_dir )#line:2881
            OO00O00O00O00OOOO .kicad_library_dir =os .path .join (OO00O00O00O00OOOO .windata_dir ,'KiCad Library')#line:2882
            O000O00O0OO00OO00 =os .path .join (OO00O00O00O00OOOO .kicad_library_dir ,'SnapEDA Library.pretty')#line:2884
            if not os .path .exists (OO00O00O00O00OOOO .kicad_library_dir ):#line:2885
                os .makedirs (OO00O00O00O00OOOO .kicad_library_dir )#line:2886
            if not os .path .exists (O000O00O0OO00OO00 ):#line:2887
                os .makedirs (O000O00O0OO00OO00 )#line:2888
        elif OO00O00O00O00OOOO .is_mac :#line:2889
            OO00O00O00O00OOOO .macdata_dir =os .path .join (os .path .expanduser ("~"),"Documents","SnapEDA Kicad Plugin")#line:2890
            OO00O00O00O00OOOO .appdata_dir =os .path .join (OO00O00O00O00OOOO .macdata_dir ,"App")#line:2891
            if not os .path .exists (OO00O00O00O00OOOO .appdata_dir ):#line:2892
                os .makedirs (OO00O00O00O00OOOO .appdata_dir )#line:2893
        else :#line:2894
            OO00O00O00O00OOOO .appdata_dir =os .path .join (OO00O00O00O00OOOO .dir_path ,"assets")#line:2895
            if not os .path .exists (OO00O00O00O00OOOO .appdata_dir ):#line:2896
                os .makedirs (OO00O00O00O00OOOO .appdata_dir )#line:2897
            OO00O00O00O00OOOO .flip_table_dir =os .path .join (os .path .expanduser ("~"),'.config','kicad','fp-lib-table')#line:2901
            O0OOO0O00000OOOO0 =os .path .expanduser ("~")#line:2902
            OO00O00O00O00OOOO .kicad_library_dir =os .path .join (O0OOO0O00000OOOO0 ,'KiCad Library')#line:2903
            O000O00O0OO00OO00 =os .path .join (OO00O00O00O00OOOO .kicad_library_dir ,'SnapEDA Library.pretty')#line:2905
            if not os .path .exists (OO00O00O00O00OOOO .kicad_library_dir ):#line:2906
                os .makedirs (OO00O00O00O00OOOO .kicad_library_dir )#line:2907
            if not os .path .exists (O000O00O0OO00OO00 ):#line:2908
                os .makedirs (O000O00O0OO00OO00 )#line:2909
        OO00O00O00O00OOOO .icon_bitmap_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,"32x32.ico")#line:2911
        OO00O00O00O00OOOO .welcome_screen_001_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,"Mask+Group.png")#line:2912
        OO00O00O00O00OOOO .welcome_screen_002_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,"icon1.bbe45f7648f7.png")#line:2913
        OO00O00O00O00OOOO .welcome_screen_003_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,"ico_deadlines.8ba69c3f942a.png")#line:2914
        OO00O00O00O00OOOO .welcome_screen_004_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,"icon2.924b03ebfccc.png")#line:2915
        OO00O00O00O00OOOO .welcome_screen_005_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,"powered+by+snapEDA.png")#line:2916
        OO00O00O00O00OOOO .welcome_screen_006_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,"snapeda-transparent.png")#line:2917
        OO00O00O00O00OOOO .usb_type_c_button_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,"usb+type+c.png")#line:2918
        OO00O00O00O00OOOO .microcontroller_button_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,"usb+microcontroller.png")#line:2919
        OO00O00O00O00OOOO .how_it_works_menu_img_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,'how_it_works_menu.png')#line:2920
        OO00O00O00O00OOOO .info_menu_img_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,'info_menu.png')#line:2921
        OO00O00O00O00OOOO .settings_menu_img_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,'settings_menu.png')#line:2922
        if IS_UPDATED :#line:2924
            OO00O00O00O00OOOO .update_menu_img_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,'update_menu.png')#line:2925
        else :#line:2926
            OO00O00O00O00OOOO .update_menu_img_dir =os .path .join (OO00O00O00O00OOOO .appdata_dir ,'notif_update_menu+(2).png')#line:2927
        OO00O00O00O00OOOO .initialize_user_interface ()#line:2929
    def resize (O0O0O000O0000OOO0 ,O0OOO0O0O0O00OOOO ,OOOO0OO0OO0000OOO ,OO0O000O0000OO0O0 ):#line:2931
        ""#line:2935
        if sys .version_info [0 ]==3 :#line:2936
            O000O0OO0OOOOO000 =O0OOO0O0O0O00OOOO .width ()#line:2937
            O0OOOOOO0OO000000 =O0OOO0O0O0O00OOOO .height ()#line:2938
            O0O0O00O0O00O0OO0 =max (O000O0OO0OOOOO000 ,O0OOOOOO0OO000000 )#line:2939
            O0OOOO0OOOOO0O000 =max (OOOO0OO0OO0000OOO ,OO0O000O0000OO0O0 )#line:2940
            if O0O0O00O0O00O0OO0 >O0OOOO0OOOOO0O000 :#line:2941
                return O0OOO0O0O0O00OOOO .subsample (int (O0O0O00O0O00O0OO0 /O0OOOO0OOOOO0O000 ))#line:2942
            else :#line:2943
                return O0OOO0O0O0O00OOOO .zoom (int (O0OOOO0OOOOO0O000 /O0O0O00O0O00O0OO0 ))#line:2944
        else :#line:2945
            O000O0OO0OOOOO000 =O0OOO0O0O0O00OOOO .width ()#line:2946
            O0OOOOOO0OO000000 =O0OOO0O0O0O00OOOO .height ()#line:2947
            O0O0O00O0O00O0OO0 =max (O000O0OO0OOOOO000 ,O0OOOOOO0OO000000 )#line:2948
            O0OOOO0OOOOO0O000 =max (OOOO0OO0OO0000OOO ,OO0O000O0000OO0O0 )#line:2949
            if O0O0O00O0O00O0OO0 >O0OOOO0OOOOO0O000 :#line:2950
                return O0OOO0O0O0O00OOOO .subsample (O0O0O00O0O00O0OO0 /O0OOOO0OOOOO0O000 )#line:2951
            else :#line:2952
                return O0OOO0O0O0O00OOOO .zoom (O0OOOO0OOOOO0O000 /O0O0O00O0O00O0OO0 )#line:2953
    def welcome_screen_search_callback (OOO0O00O0OO00OOOO ,O0OOO00OOO00O00OO ):#line:2955
        O000OO0O0000OOOO0 =OOO0O00O0OO00OOOO .search_bar .get ()#line:2956
        if len (O000OO0O0000OOOO0 )>0 :#line:2957
            for O000O0O0O00OO00O0 in range (5 ):#line:2958
                for O00OOO0O00OO0O0OO in OOO0O00O0OO00OOOO .parent .grid_slaves (row =O000O0O0O00OO00O0 ,column =0 ):#line:2959
                    O00OOO0O00OO0O0OO .destroy ()#line:2960
            OOO0O00O0OO00OOOO .parent .search_datum =O000OO0O0000OOOO0 #line:2961
            OOO0O00O0OO00OOOO .search_bar .destroy ()#line:2963
            TableView (OOO0O00O0OO00OOOO .parent )#line:2964
    def usb_type_c_button_callback (OO00O0000O00O0O00 ,O0000OOOO0O00O0O0 ):#line:2966
        for O0OOO0000OO0O0000 in range (5 ):#line:2967
            for OOOO00OOOOOOOO0O0 in OO00O0000O00O0O00 .parent .grid_slaves (row =O0OOO0000OO0O0000 ,column =0 ):#line:2968
                OOOO00OOOOOOOO0O0 .destroy ()#line:2969
        OO00O0000O00O0O00 .parent .search_datum ="usb type c"#line:2970
        TableView (OO00O0000O00O0O00 .parent )#line:2971
    def microcontroller_button_callback (O0OO0OO0000O000O0 ,OO00O00O00O00O000 ):#line:2973
        for O00O00OOO0O0O0000 in range (5 ):#line:2974
            for O0O0O00000O0000OO in O0OO0OO0000O000O0 .parent .grid_slaves (row =O00O00OOO0O0O0000 ,column =0 ):#line:2975
                O0O0O00000O0000OO .destroy ()#line:2976
        O0OO0OO0000O000O0 .parent .search_datum ="microcontroller"#line:2977
        TableView (O0OO0OO0000O000O0 .parent )#line:2978
    def how_it_works_callback (O0OOOO000O000OO00 ,OO0OOO000O0OOOO0O ):#line:2980
        global IS_SETTING_WINDOW_OPEN #line:2981
        if IS_SETTING_WINDOW_OPEN is False :#line:2982
            O0OOOO000O000OO00 .parent .is_help_me_window =False #line:2983
            InfoView (O0OOOO000O000OO00 .parent )#line:2984
    def update_process (OOOO0O00OOO00O0O0 ):#line:2996
        OOOO0O00OOO00O0O0 .status_text .set ("Downloading update...")#line:2998
        OO000O00OO0O00OO0 =os .path .join (OOOO0O00OOO00O0O0 .kicad_library_dir ,'temp')#line:2999
        if not os .path .exists (OO000O00OO0O00OO0 ):#line:3000
                os .makedirs (OO000O00OO0O00OO0 )#line:3001
        if sys .version_info [0 ]==3 :#line:3002
            with urllib .request .urlopen ('https://snapeda.s3.amazonaws.com/plugins/kicad/SnapEDA-KiCad-Plugin.zip')as O000O0O00OO0O00O0 ,open (os .path .join (OO000O00OO0O00OO0 ,'SnapEDA-KiCad-Plugin.zip'),'wb')as OO0OOO0OO00OOO0O0 :#line:3003
                shutil .copyfileobj (O000O0O00OO0O00O0 ,OO0OOO0OO00OOO0O0 )#line:3004
        else :#line:3005
            O00000OOO0O0OO0O0 =urllib2 .urlopen ('https://snapeda.s3.amazonaws.com/plugins/kicad/SnapEDA-KiCad-Plugin.zip')#line:3006
            with open (os .path .join (OO000O00OO0O00OO0 ,'SnapEDA-KiCad-Plugin.zip'),"wb")as OOOO000OOO0000000 :#line:3007
                shutil .copyfileobj (O00000OOO0O0OO0O0 ,OOOO000OOO0000000 )#line:3008
        OOOO0O00OOO00O0O0 .status_text .set ("Extracting package...")#line:3010
        with zipfile .ZipFile (os .path .join (OO000O00OO0O00OO0 ,'SnapEDA-KiCad-Plugin.zip'))as O00O0OO0O00OO00OO :#line:3012
            O00O0OO0O00OO00OO .extractall (OO000O00OO0O00OO0 )#line:3013
        OOOO0O00OOO00O0O0 .status_text .set ("Copying files...")#line:3015
        for OO0OOO00000OOO000 in os .listdir (OO000O00OO0O00OO0 ):#line:3017
            if OO0OOO00000OOO000 .endswith (".py"):#line:3018
                copyfile (os .path .join (OO000O00OO0O00OO0 ,OO0OOO00000OOO000 ),os .path .join (os .path .dirname (os .path .realpath (__file__ )),OO0OOO00000OOO000 ))#line:3019
        shutil .rmtree (OO000O00OO0O00OO0 )#line:3021
        OOOO0O00OOO00O0O0 .status_text .set ("Update complete.")#line:3023
        OOOO0O00OOO00O0O0 .header_text .set ("UPDATE COMPLETE")#line:3025
        OOOO0O00OOO00O0O0 .subheader_text .set ("Update successful. Please restart SnapEDA, refresh the plugins, then open SnapEDA.")#line:3026
        OOOO0O00OOO00O0O0 .status_text .set ("")#line:3027
    def setting_callback (OO0O00O0O0O00O0O0 ,O00O0O000OO0O0O00 ):#line:3029
        global IS_SETTING_WINDOW_OPEN #line:3030
        if IS_SETTING_WINDOW_OPEN is False :#line:3031
            SettingsView (OO0O00O0O0O00O0O0 .parent )#line:3032
    def update_callback (O00000O0000OO0OO0 ,OO000O0000000O000 ):#line:3034
        try :#line:3036
            O0OO0OO0O0000O000 =os .getuid ()==0 #line:3037
        except AttributeError :#line:3038
            O0OO0OO0O0000O000 =ctypes .windll .shell32 .IsUserAnAdmin ()!=0 #line:3039
        if not O0OO0OO0O0000O000 :#line:3041
            if O00000O0000OO0OO0 .is_windows :#line:3042
                tkMessageBox .showwarning ("Update","Please restart KiCAD as administrator, then update again.")#line:3043
                return #line:3044
        O00000O0000OO0OO0 .update_container =tk .Frame (O00000O0000OO0OO0 .parent ,bg ="#ff761a")#line:3049
        O00000O0000OO0OO0 .update_container .grid (row =0 ,column =0 ,sticky ="NEWS")#line:3050
        O00000O0000OO0OO0 .update_container .grid_columnconfigure (0 ,weight =1 )#line:3051
        for O0OO0OO00O0O0O00O in range (4 ):#line:3052
            O00000O0000OO0OO0 .update_container .grid_rowconfigure (O0OO0OO00O0O0O00O ,weight =1 ,uniform ="foo")#line:3053
        O00000O0000OO0OO0 .header_container =tk .Frame (O00000O0000OO0OO0 .update_container ,bg ="#ff761a")#line:3055
        O00000O0000OO0OO0 .header_container .grid (row =1 ,column =0 ,columnspan =1 ,sticky ="NEWS")#line:3056
        O00000O0000OO0OO0 .header_container .grid_columnconfigure (0 ,weight =1 )#line:3057
        for O0OO0OO00O0O0O00O in range (3 ):#line:3058
            O00000O0000OO0OO0 .header_container .grid_rowconfigure (O0OO0OO00O0O0O00O ,weight =1 ,uniform ="foo")#line:3059
        O00000O0000OO0OO0 .header_text =tk .StringVar ()#line:3061
        O00000O0000OO0OO0 .header_text .set ("UPDATING...")#line:3062
        O00000O0000OO0OO0 .header_label =tk .Label (O00000O0000OO0OO0 .header_container ,bg ="#ff761a",fg ="white",textvariable =O00000O0000OO0OO0 .header_text ,justify =tk .CENTER ,font =("Open Sans","18","bold"))#line:3063
        O00000O0000OO0OO0 .header_label .grid (row =0 ,column =0 ,columnspan =1 ,sticky ="NEWS")#line:3064
        O00000O0000OO0OO0 .subheader_text =tk .StringVar ()#line:3066
        O00000O0000OO0OO0 .subheader_text .set ("This may take a while, about 3-5 minutes. Mind to have a coffee break?")#line:3067
        O00000O0000OO0OO0 .subheader_label =tk .Label (O00000O0000OO0OO0 .header_container ,textvariable =O00000O0000OO0OO0 .subheader_text ,fg ="white",bg ="#ff761a",font =("Open Sans","13"))#line:3068
        O00000O0000OO0OO0 .subheader_label .grid (row =1 ,column =0 ,sticky ="NEW")#line:3069
        O00000O0000OO0OO0 .status_text =tk .StringVar ()#line:3071
        O00000O0000OO0OO0 .status_text .set ("Starting update...")#line:3072
        O00000O0000OO0OO0 .status_label =tk .Label (O00000O0000OO0OO0 .header_container ,textvariable =O00000O0000OO0OO0 .status_text ,fg ="white",bg ="#ff761a",font =("Open Sans","13","italic"))#line:3073
        O00000O0000OO0OO0 .status_label .grid (row =2 ,column =0 ,sticky ="NEW")#line:3074
        O00000O0000OO0OO0 .update_thread =threading .Thread (target =O00000O0000OO0OO0 .update_process )#line:3076
        O00000O0000OO0OO0 .update_thread .setDaemon (True )#line:3077
        O00000O0000OO0OO0 .update_thread .start ()#line:3078
    def help_me_callback (O000000OOOO0OOOOO ,O000OO00OOOOO0OO0 ):#line:3081
        global IS_SETTING_WINDOW_OPEN #line:3082
        if IS_SETTING_WINDOW_OPEN is False :#line:3083
            O000000OOOO0OOOOO .parent .is_help_me_window =True #line:3084
            InfoView (O000000OOOO0OOOOO .parent )#line:3085
    def initialize_user_interface (OO00OO0O0OOOOOOOO ):#line:3090
        if OO00OO0O0OOOOOOOO .is_windows :#line:3091
            OO00OO0O0OOOOOOOO .parent .iconbitmap (OO00OO0O0OOOOOOOO .icon_bitmap_dir )#line:3092
        OO00OO0O0OOOOOOOO .parent .title ("SnapEDA v"+OO00OO0O0OOOOOOOO .parent .version )#line:3093
        OO00OO0O0OOOOOOOO .parent .geometry ("1150x828")#line:3094
        OO00OO0O0OOOOOOOO .parent .minsize (width =1150 ,height =828 )#line:3095
        OO00OO0O0OOOOOOOO .parent .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:3096
        OO00OO0O0OOOOOOOO .parent .grid_rowconfigure (0 ,weight =1 ,uniform ="foo")#line:3097
        OO00OO0O0OOOOOOOO .parent_container =tk .Frame (OO00OO0O0OOOOOOOO .parent ,bg ="white")#line:3098
        OO00OO0O0OOOOOOOO .parent_container .grid (row =0 ,column =0 ,sticky ="NEWS")#line:3099
        OO00OO0O0OOOOOOOO .parent_container .grid_columnconfigure (0 ,weight =1 ,uniform ="foo")#line:3100
        OO00OO0O0OOOOOOOO .parent_container .grid_rowconfigure (0 ,weight =1 )#line:3101
        OO00OO0O0OOOOOOOO .main_frame =tk .Frame (OO00OO0O0OOOOOOOO .parent_container ,bg ="white")#line:3102
        OO00OO0O0OOOOOOOO .main_frame .grid (row =0 ,column =0 ,columnspan =1 ,sticky ="NEWS")#line:3103
        for OO0O0OO0000O0000O in range (3 ):#line:3104
            OO00OO0O0OOOOOOOO .main_frame .grid_columnconfigure (OO0O0OO0000O0000O ,weight =1 ,uniform ="foo")#line:3105
        OO00OO0O0OOOOOOOO .main_frame .grid_rowconfigure (0 ,weight =1 )#line:3106
        OO00OO0O0OOOOOOOO .left_frame =tk .Frame (OO00OO0O0OOOOOOOO .main_frame ,bg ="white")#line:3108
        OO00OO0O0OOOOOOOO .left_frame .grid (row =0 ,column =0 ,columnspan =2 ,sticky ="NEWS")#line:3109
        OO00OO0O0OOOOOOOO .left_frame .grid_columnconfigure (0 ,weight =1 )#line:3110
        for OO0O0OO0000O0000O in range (5 ):#line:3111
            OO00OO0O0OOOOOOOO .left_frame .grid_rowconfigure (OO0O0OO0000O0000O ,weight =1 ,uniform ="foo")#line:3112
        OO00OO0O0OOOOOOOO .right_frame =tk .Frame (OO00OO0O0OOOOOOOO .main_frame ,bg ="white")#line:3114
        OO00OO0O0OOOOOOOO .right_frame .grid (row =0 ,column =2 ,columnspan =1 ,sticky ="NEWS")#line:3115
        OO00OO0O0OOOOOOOO .right_frame .grid_columnconfigure (0 ,weight =1 )#line:3116
        for OO0O0OO0000O0000O in range (5 ):#line:3117
            OO00OO0O0OOOOOOOO .right_frame .grid_rowconfigure (OO0O0OO0000O0000O ,weight =1 ,uniform ="foo")#line:3118
        OO0OOO0OO0O00OOO0 =tk .PhotoImage (file =os .path .join (OO00OO0O0OOOOOOOO .welcome_screen_006_dir ))#line:3121
        OO00OO0O0OOOOOOOO .navbar_container =tk .Frame (OO00OO0O0OOOOOOOO .left_frame ,bg ="white")#line:3122
        OO00OO0O0OOOOOOOO .navbar_container .grid (row =0 ,column =0 ,sticky ="NEWS")#line:3123
        OO00OO0O0OOOOOOOO .navbar_container .grid_columnconfigure (0 ,weight =1 )#line:3124
        for OO0O0OO0000O0000O in range (2 ):#line:3125
            OO00OO0O0OOOOOOOO .navbar_container .grid_rowconfigure (OO0O0OO0000O0000O ,weight =1 ,uniform ="foo")#line:3126
        OO00OO0O0OOOOOOOO .welcome_screen_006_image =OO00OO0O0OOOOOOOO .resize (OO0OOO0OO0O00OOO0 ,200 ,59 )#line:3128
        OO00OO0O0OOOOOOOO .welcome_screen_006_bg =tk .Label (OO00OO0O0OOOOOOOO .navbar_container ,image =OO00OO0O0OOOOOOOO .welcome_screen_006_image ,bg ="white")#line:3129
        OO00OO0O0OOOOOOOO .welcome_screen_006_bg .grid (row =0 ,column =0 ,sticky ="NW")#line:3130
        OO00OO0O0OOOOOOOO .navbar_menu_container =tk .Label (OO00OO0O0OOOOOOOO .navbar_container ,bg ="white")#line:3132
        OO00OO0O0OOOOOOOO .navbar_menu_container .grid (row =1 ,column =0 ,sticky ="NW")#line:3133
        OO00OO0O0OOOOOOOO .welcome_screen_header =tk .Label (OO00OO0O0OOOOOOOO .left_frame ,text ="Welcome to SnapEDA",bg ="white",font =("Open Sans","32","bold"))#line:3135
        OO00OO0O0OOOOOOOO .welcome_screen_header .grid (row =1 ,column =0 ,rowspan =1 ,sticky ="SEW")#line:3136
        OOO0O0OO0OO0O0OOO =tk .PhotoImage (file =os .path .join (OO00OO0O0OOOOOOOO .welcome_screen_001_dir ))#line:3138
        OO00OO0O0OOOOOOOO .welcome_screen_001_image =OO00OO0O0OOOOOOOO .resize (OOO0O0OO0OO0O0OOO ,297 ,333 )#line:3139
        OO00OO0O0OOOOOOOO .welcome_screen_001_bg =tk .Label (OO00OO0O0OOOOOOOO .right_frame ,image =OO00OO0O0OOOOOOOO .welcome_screen_001_image ,bg ="white")#line:3140
        OO00OO0O0OOOOOOOO .welcome_screen_001_bg .grid (row =0 ,column =0 ,sticky ="NE",rowspan =3 )#line:3141
        O0O00OOOO0OOOOOOO =tk .PhotoImage (file =os .path .join (OO00OO0O0OOOOOOOO .welcome_screen_005_dir ))#line:3143
        OO00OO0O0OOOOOOOO .welcome_screen_005_image =OO00OO0O0OOOOOOOO .resize (O0O00OOOO0OOOOOOO ,267 ,72 )#line:3144
        OO00OO0O0OOOOOOOO .welcome_screen_005_bg =tk .Label (OO00OO0O0OOOOOOOO .right_frame ,image =OO00OO0O0OOOOOOOO .welcome_screen_005_image ,bg ="white")#line:3145
        OO00OO0O0OOOOOOOO .welcome_screen_005_bg .grid (row =4 ,column =0 ,rowspan =1 ,sticky ="SE")#line:3146
        OO00OO0O0OOOOOOOO .welcome_container =tk .Frame (OO00OO0O0OOOOOOOO .left_frame ,bg ="white")#line:3149
        OO00OO0O0OOOOOOOO .welcome_container .grid (row =2 ,column =0 ,rowspan =2 ,sticky ="NEWS")#line:3150
        OO00OO0O0OOOOOOOO .welcome_container .grid_columnconfigure (0 ,weight =1 )#line:3151
        for OO0O0OO0000O0000O in range (5 ):#line:3152
            OO00OO0O0OOOOOOOO .welcome_container .grid_rowconfigure (OO0O0OO0000O0000O ,weight =1 ,uniform ="foo")#line:3153
        OO00OO0O0OOOOOOOO .welcome_screen_subheader =tk .Label (OO00OO0O0OOOOOOOO .welcome_container ,text ="Let's make your your design a snap. Download ready-to-use\nPCB footprints, schematic symbols, and 3D models.",bg ="white",font =("Open Sans","12"),justify =tk .LEFT )#line:3155
        OO00OO0O0OOOOOOOO .welcome_screen_subheader .grid (row =0 ,column =0 ,rowspan =1 ,sticky ="NEWS")#line:3156
        OO00OO0O0OOOOOOOO .welcome_screen_search_container =tk .Frame (OO00OO0O0OOOOOOOO .welcome_container ,bg ="white")#line:3158
        OO00OO0O0OOOOOOOO .welcome_screen_search_container .grid (row =1 ,column =0 ,rowspan =1 ,sticky ="NEW",padx =(40 ,40 ),pady =(20 ,0 ))#line:3159
        OO00OO0O0OOOOOOOO .welcome_screen_search_container .grid_columnconfigure (0 ,weight =1 )#line:3160
        OO00OO0O0OOOOOOOO .welcome_screen_search_container .grid_rowconfigure (0 ,weight =1 )#line:3161
        tk .Label (OO00OO0O0OOOOOOOO .welcome_screen_search_container ,bg ="#E1E1E1").grid (row =0 ,column =0 ,sticky ="NEWS")#line:3163
        tk .Label (OO00OO0O0OOOOOOOO .welcome_screen_search_container ,bg ="white").grid (row =0 ,column =0 ,sticky ="NEWS",padx =(1 ,1 ),pady =(1 ,1 ))#line:3164
        OO00OO0O0OOOOOOOO .search_bar =tk .Entry (OO00OO0O0OOOOOOOO .welcome_screen_search_container ,fg ="#696969",bg ="white",font =("Open Sans",13 ),borderwidth =0 ,highlightthickness =0 )#line:3165
        OO00OO0O0OOOOOOOO .search_bar .grid (row =0 ,column =0 ,sticky ="NEWS",padx =(25 ,25 ),pady =(1 ,1 ))#line:3166
        OO00OO0O0OOOOOOOO .welcome_screen_search_button_im =tk .PhotoImage (file =os .path .join (OO00OO0O0OOOOOOOO .appdata_dir ,"4i2efbui.png"))#line:3168
        OO00OO0O0OOOOOOOO .welcome_screen_search_button_image =OO00OO0O0OOOOOOOO .resize (OO00OO0O0OOOOOOOO .welcome_screen_search_button_im ,73 ,55 )#line:3169
        OO00OO0O0OOOOOOOO .welcome_screen_button =tk .Label (OO00OO0O0OOOOOOOO .welcome_screen_search_container ,height =50 ,bg ="#ff761a",text ="",image =OO00OO0O0OOOOOOOO .welcome_screen_search_button_image ,cursor ="hand2")#line:3170
        OO00OO0O0OOOOOOOO .welcome_screen_button .grid (row =0 ,column =0 ,sticky ="NE",padx =(0 ,0 ),pady =(0 ,0 ))#line:3171
        OO00OO0O0OOOOOOOO .welcome_screen_button .bind ("<Button-1>",OO00OO0O0OOOOOOOO .welcome_screen_search_callback )#line:3172
        OO00OO0O0OOOOOOOO .search_bar .bind ('<Return>',OO00OO0O0OOOOOOOO .welcome_screen_search_callback )#line:3173
        OO00OO0O0OOOOOOOO .example_frame =tk .Frame (OO00OO0O0OOOOOOOO .welcome_container ,bg ="white")#line:3175
        OO00OO0O0OOOOOOOO .example_frame .grid (row =2 ,column =0 ,columnspan =1 ,sticky ="NW",padx =(25 ,0 ),pady =(25 ,0 ))#line:3176
        for OO0O0OO0000O0000O in range (3 ):#line:3177
            OO00OO0O0OOOOOOOO .example_frame .grid_columnconfigure (OO0O0OO0000O0000O ,weight =1 ,uniform ="foo")#line:3178
        OO00OO0O0OOOOOOOO .example_frame .grid_rowconfigure (0 ,weight =1 )#line:3179
        OO00OO0O0OOOOOOOO .see_example_label =tk .Label (OO00OO0O0OOOOOOOO .example_frame ,text ="Or see examples",bg ="white",font =("Open Sans","10","bold"))#line:3181
        OO00OO0O0OOOOOOOO .see_example_label .grid (row =0 ,column =0 )#line:3182
        OO00OO0O0OOOOOOOO .usb_type_c_button_im =tk .PhotoImage (file =OO00OO0O0OOOOOOOO .usb_type_c_button_dir )#line:3184
        OO00OO0O0OOOOOOOO .usb_type_c_button_image =OO00OO0O0OOOOOOOO .resize (OO00OO0O0OOOOOOOO .usb_type_c_button_im ,89 ,21 )#line:3185
        OO00OO0O0OOOOOOOO .usb_type_c_button =tk .Label (OO00OO0O0OOOOOOOO .example_frame ,bg ="white",text ="",image =OO00OO0O0OOOOOOOO .usb_type_c_button_image ,cursor ="hand2")#line:3186
        OO00OO0O0OOOOOOOO .usb_type_c_button .grid (row =0 ,column =1 ,padx =(0 ,0 ),pady =(0 ,0 ))#line:3187
        OO00OO0O0OOOOOOOO .usb_type_c_button .bind ('<Button-1>',OO00OO0O0OOOOOOOO .usb_type_c_button_callback )#line:3188
        OO00OO0O0OOOOOOOO .microcontroller_button_im =tk .PhotoImage (file =OO00OO0O0OOOOOOOO .microcontroller_button_dir )#line:3190
        OO00OO0O0OOOOOOOO .microcontroller_button_image =OO00OO0O0OOOOOOOO .resize (OO00OO0O0OOOOOOOO .microcontroller_button_im ,89 ,21 )#line:3191
        OO00OO0O0OOOOOOOO .microcontroller_button =tk .Label (OO00OO0O0OOOOOOOO .example_frame ,bg ="white",text ="",image =OO00OO0O0OOOOOOOO .microcontroller_button_image ,cursor ="hand2")#line:3192
        OO00OO0O0OOOOOOOO .microcontroller_button .grid (row =0 ,column =2 ,padx =(0 ,0 ),pady =(0 ,0 ))#line:3193
        OO00OO0O0OOOOOOOO .microcontroller_button .bind ('<Button-1>',OO00OO0O0OOOOOOOO .microcontroller_button_callback )#line:3194
        OO00OO0O0OOOOOOOO .left_003_frame =tk .Frame (OO00OO0O0OOOOOOOO .left_frame ,bg ="white")#line:3196
        OO00OO0O0OOOOOOOO .left_003_frame .grid (row =3 ,column =0 ,rowspan =2 ,sticky ="NEWS",pady =(70 ,0 ))#line:3197
        for OO0O0OO0000O0000O in range (3 ):#line:3198
            OO00OO0O0OOOOOOOO .left_003_frame .grid_columnconfigure (OO0O0OO0000O0000O ,weight =1 ,uniform ="foo")#line:3199
        for OO0O0OO0000O0000O in range (2 ):#line:3200
            OO00OO0O0OOOOOOOO .left_003_frame .grid_rowconfigure (OO0O0OO0000O0000O ,weight =1 )#line:3201
        O00O0OO00O00O0O00 =tk .PhotoImage (file =os .path .join (OO00OO0O0OOOOOOOO .welcome_screen_002_dir ))#line:3204
        OO00OO0O0OOOOOOOO .welcome_screen_002_image =OO00OO0O0OOOOOOOO .resize (O00O0OO00O00O0O00 ,100 ,113 )#line:3205
        OO00OO0O0OOOOOOOO .welcome_screen_002_bg =tk .Label (OO00OO0O0OOOOOOOO .left_003_frame ,image =OO00OO0O0OOOOOOOO .welcome_screen_002_image ,bg ="white")#line:3206
        OO00OO0O0OOOOOOOO .welcome_screen_002_bg .grid (row =0 ,column =0 ,padx =(30 ,25 ),sticky ="S")#line:3207
        OO00OO0O0OOOOOOOO .label_001 =tk .Label (OO00OO0O0OOOOOOOO .left_003_frame ,text ="Focus on Design",bg ="white",font =("Open Sans","10","bold"))#line:3209
        OO00OO0O0OOOOOOOO .label_001 .grid (row =1 ,column =0 ,padx =(30 ,25 ),sticky ="N")#line:3210
        O0OOOO000OOO00OOO =tk .PhotoImage (file =os .path .join (OO00OO0O0OOOOOOOO .welcome_screen_003_dir ))#line:3212
        OO00OO0O0OOOOOOOO .welcome_screen_003_image =OO00OO0O0OOOOOOOO .resize (O0OOOO000OOO00OOO ,100 ,113 )#line:3213
        OO00OO0O0OOOOOOOO .welcome_screen_003_bg =tk .Label (OO00OO0O0OOOOOOOO .left_003_frame ,image =OO00OO0O0OOOOOOOO .welcome_screen_003_image ,bg ="white")#line:3214
        OO00OO0O0OOOOOOOO .welcome_screen_003_bg .grid (row =0 ,column =1 ,padx =(25 ,25 ),sticky ="S")#line:3215
        OO00OO0O0OOOOOOOO .label_002 =tk .Label (OO00OO0O0OOOOOOOO .left_003_frame ,text ="Crush Deadlines",bg ="white",font =("Open Sans","10","bold"))#line:3217
        OO00OO0O0OOOOOOOO .label_002 .grid (row =1 ,column =1 ,padx =(30 ,25 ),sticky ="N")#line:3218
        OO00OO000000OO0O0 =tk .PhotoImage (file =os .path .join (OO00OO0O0OOOOOOOO .welcome_screen_004_dir ))#line:3220
        OO00OO0O0OOOOOOOO .welcome_screen_004_image =OO00OO0O0OOOOOOOO .resize (OO00OO000000OO0O0 ,100 ,113 )#line:3221
        OO00OO0O0OOOOOOOO .welcome_screen_004_bg =tk .Label (OO00OO0O0OOOOOOOO .left_003_frame ,image =OO00OO0O0OOOOOOOO .welcome_screen_004_image ,bg ="white")#line:3222
        OO00OO0O0OOOOOOOO .welcome_screen_004_bg .grid (row =0 ,column =2 ,padx =(25 ,30 ),sticky ="S")#line:3223
        OO00OO0O0OOOOOOOO .label_003 =tk .Label (OO00OO0O0OOOOOOOO .left_003_frame ,text ="Prevent Errors",bg ="white",font =("Open Sans","10","bold"))#line:3225
        OO00OO0O0OOOOOOOO .label_003 .grid (row =1 ,column =2 ,padx =(30 ,25 ),sticky ="N")#line:3226
        OO00OO0O0OOOOOOOO .settings_menu_img =tk .PhotoImage (file =OO00OO0O0OOOOOOOO .settings_menu_img_dir )#line:3229
        OO00OO0O0OOOOOOOO .how_it_works_menu_img =tk .PhotoImage (file =OO00OO0O0OOOOOOOO .how_it_works_menu_img_dir )#line:3230
        OO00OO0O0OOOOOOOO .update_menu_img =tk .PhotoImage (file =OO00OO0O0OOOOOOOO .update_menu_img_dir )#line:3231
        OO00OO0O0OOOOOOOO .info_menu_img =tk .PhotoImage (file =OO00OO0O0OOOOOOOO .info_menu_img_dir )#line:3232
        OO00OO0O0OOOOOOOO .how_it_works_button =tk .Label (OO00OO0O0OOOOOOOO .navbar_menu_container ,fg ="#FF761B",bg ="white",image =OO00OO0O0OOOOOOOO .how_it_works_menu_img ,text ="How it works",cursor ="hand2",font =("Open Sans","8","bold","underline"))#line:3235
        OO00OO0O0OOOOOOOO .update_button =tk .Label (OO00OO0O0OOOOOOOO .navbar_menu_container ,fg ="#FF761B",bg ="white",image =OO00OO0O0OOOOOOOO .update_menu_img ,text ="Update",cursor ="hand2",font =("Open Sans","8","bold","underline"))#line:3236
        OO00OO0O0OOOOOOOO .help_me_button =tk .Label (OO00OO0O0OOOOOOOO .navbar_menu_container ,fg ="#FF761B",bg ="white",image =OO00OO0O0OOOOOOOO .info_menu_img ,text ="Help Me",cursor ="hand2",font =("Open Sans","8","bold","underline"))#line:3237
        OO00OO0O0OOOOOOOO .how_it_works_button .bind ("<Button-1>",OO00OO0O0OOOOOOOO .setting_callback )#line:3240
        OO00OO0O0OOOOOOOO .update_button .bind ("<Button-1>",OO00OO0O0OOOOOOOO .update_callback )#line:3241
        OO00OO0O0OOOOOOOO .help_me_button .bind ("<Button-1>",OO00OO0O0OOOOOOOO .how_it_works_callback )#line:3242
        OO00OO0O0OOOOOOOO .help_me_button .grid (row =0 ,column =2 ,padx =(0 ,0 ),sticky ="W")#line:3244
        OO00OO0O0OOOOOOOO .update_button .grid (row =0 ,column =1 ,padx =(0 ,15 ),sticky ="W")#line:3245
        OO00OO0O0OOOOOOOO .how_it_works_button .grid (row =0 ,column =0 ,padx =(10 ,15 ),sticky ="W")#line:3246
class LoginScreen (tk .Frame ):#line:3250
    ""#line:3256
    def __init__ (OOO00000OOO0O0O00 ,O0OOO0OO00OO00O00 ):#line:3258
        tk .Frame .__init__ (OOO00000OOO0O0O00 ,O0OOO0OO00OO00O00 )#line:3259
        OOO00000OOO0O0O00 .parent =O0OOO0OO00OO00O00 #line:3260
        OOO00000OOO0O0O00 .parent .geometry (CONST_LOGIN_GEOMETRY )#line:3261
        OOO00000OOO0O0O00 .parent .minsize (width =CONST_LOGIN_WINDOW_WIDTH ,height =CONST_LOGIN_GEOMETRY_HEIGHT )#line:3262
        OOO00000OOO0O0O00 .dir_path =os .path .dirname (os .path .realpath (__file__ ))#line:3265
        OOO00000OOO0O0O00 .is_mac =platform .mac_ver ()[0 ]!=""#line:3278
        OOO00000OOO0O0O00 .is_windows =(os .name =='nt')#line:3279
        OO0OO00OO0000OO0O =''#line:3280
        try :#line:3281
            if OOO00000OOO0O0O00 .is_windows :#line:3282
                OOO00000OOO0O0O00 .windata_dir =os .path .join (os .getenv ('HOMEDRIVE'),os .getenv ('HOMEPATH'),"SnapEDA Kicad Plugin")#line:3285
                OOO00000OOO0O0O00 .appdata_dir =os .path .join (OOO00000OOO0O0O00 .windata_dir ,"App")#line:3286
                with open (os .path .join (OOO00000OOO0O0O00 .appdata_dir ,".token"),"r")as OO00OO0000OOO000O :#line:3287
                    OO0OO00OO0000OO0O =str (OO00OO0000OOO000O .readline ())#line:3288
                    OO00OO0000OOO000O .close ()#line:3289
            elif OOO00000OOO0O0O00 .is_mac :#line:3290
                OOO00000OOO0O0O00 .macdata_dir =os .path .join (os .path .expanduser ("~"),"Documents","SnapEDA Kicad Plugin")#line:3291
                OOO00000OOO0O0O00 .appdata_dir =os .path .join (OOO00000OOO0O0O00 .macdata_dir ,"App")#line:3292
                with open (os .path .join (OOO00000OOO0O0O00 .appdata_dir ,".token"),"r")as OO00OO0000OOO000O :#line:3293
                    OO0OO00OO0000OO0O =str (OO00OO0000OOO000O .readline ())#line:3294
                    OO00OO0000OOO000O .close ()#line:3295
            else :#line:3296
                OOO00000OOO0O0O00 .dir_path =os .path .dirname (os .path .realpath (__file__ ))#line:3297
                with open (os .path .join (OOO00000OOO0O0O00 .dir_path ,".token"),"r")as OO00OO0000OOO000O :#line:3298
                    OO0OO00OO0000OO0O =str (OO00OO0000OOO000O .readline ())#line:3299
                    OO00OO0000OOO000O .close ()#line:3300
        except :#line:3301
            OO0OO00OO0000OO0O =''#line:3302
        try :#line:3304
            OO0O00O0O000O0O0O ={'User-Agent':"Kicad"}#line:3305
            O000OO00000O0OO00 ="https://www.snapeda.com/api/v1/parts/search?q=%s&token=%s"%("test-search",OO0OO00OO0000OO0O )#line:3306
            if sys .version_info [0 ]==3 :#line:3308
                O0O000OO0OOOOOO0O =urllib .request .Request (O000OO00000O0OO00 ,headers =OO0O00O0O000O0O0O )#line:3309
                O0O0OO00O00O0OOOO =urllib .request .urlopen (O0O000OO0OOOOOO0O ,timeout =5 ).read ()#line:3310
            else :#line:3311
                O0O000OO0OOOOOO0O =urllib2 .Request (O000OO00000O0OO00 ,headers =OO0O00O0O000O0O0O )#line:3312
                O0O0OO00O00O0OOOO =urllib2 .urlopen (O0O000OO0OOOOOO0O ,timeout =5 ).read ()#line:3313
            O0OO00O0000OOOOO0 =json .loads (O0O0OO00O00O0OOOO )#line:3314
            if (O0OO00O0000OOOOO0 ['error']==None ):#line:3315
                for OO0OOO0O0O0O000OO in range (5 ):#line:3316
                    for OO0O0OO000OOO0O0O in OOO00000OOO0O0O00 .parent .grid_slaves (row =OO0OOO0O0O0O000OO ,column =0 ):#line:3317
                        OO0O0OO000OOO0O0O .destroy ()#line:3318
                WelcomeScreen (OOO00000OOO0O0O00 .parent )#line:3319
                return #line:3320
        except :#line:3321
            pass #line:3322
        if OOO00000OOO0O0O00 .is_windows :#line:3325
            OOO00000OOO0O0O00 .windata_dir =os .path .join (os .getenv ('HOMEDRIVE'),os .getenv ('HOMEPATH'),"SnapEDA Kicad Plugin")#line:3328
            OOO00000OOO0O0O00 .appdata_dir =os .path .join (OOO00000OOO0O0O00 .windata_dir ,"App")#line:3329
            OOO00000OOO0O0O00 .flip_table_dir =os .path .join (os .getenv ('APPDATA'),'kicad','fp-lib-table')#line:3332
            OOO00000OOO0O0O00 .kicad_common_dir =os .path .join (os .getenv ('APPDATA'),'kicad','kicad_common')#line:3335
            OOO00000OOO0O0O00 .kicad_library_dir =os .path .join (OOO00000OOO0O0O00 .windata_dir ,'KiCad Library')#line:3336
            OOO00000OOO0O0O00 .snapeda_library_dir =os .path .join (OOO00000OOO0O0O00 .kicad_library_dir ,'SnapEDA Library')#line:3339
            OOO00000OOO0O0O00 .snapeda_library_abs_dir =os .path .join (OOO00000OOO0O0O00 .kicad_library_dir ,'SnapEDA Library.pretty')#line:3341
            if not os .path .exists (OOO00000OOO0O0O00 .windata_dir ):#line:3343
                os .makedirs (OOO00000OOO0O0O00 .windata_dir )#line:3344
            if not os .path .exists (OOO00000OOO0O0O00 .appdata_dir ):#line:3345
                os .makedirs (OOO00000OOO0O0O00 .appdata_dir )#line:3346
            if not os .path .exists (OOO00000OOO0O0O00 .kicad_library_dir ):#line:3347
                os .makedirs (OOO00000OOO0O0O00 .kicad_library_dir )#line:3348
            if not os .path .exists (OOO00000OOO0O0O00 .snapeda_library_dir ):#line:3349
                os .makedirs (OOO00000OOO0O0O00 .snapeda_library_dir )#line:3350
            if not os .path .exists (OOO00000OOO0O0O00 .snapeda_library_abs_dir ):#line:3351
                os .makedirs (OOO00000OOO0O0O00 .snapeda_library_abs_dir )#line:3352
        elif OOO00000OOO0O0O00 .is_mac :#line:3353
            OOO00000OOO0O0O00 .macdata_dir =os .path .join (os .path .expanduser ("~"),"Documents","SnapEDA Kicad Plugin")#line:3354
            OOO00000OOO0O0O00 .appdata_dir =os .path .join (OOO00000OOO0O0O00 .macdata_dir ,"App")#line:3355
            OOO00000OOO0O0O00 .flip_table_dir =os .path .join (os .getenv ('HOME'),'library','preferences','kicad','fp-lib-table')#line:3356
            OOO00000OOO0O0O00 .kicad_common_dir =os .path .join (os .getenv ('HOME'),'library','preferences','kicad','kicad_common')#line:3357
            OOO00000OOO0O0O00 .kicad_library_dir =os .path .join (OOO00000OOO0O0O00 .macdata_dir ,'KiCad Library')#line:3358
            OOO00000OOO0O0O00 .snapeda_library_dir =os .path .join (OOO00000OOO0O0O00 .kicad_library_dir ,'SnapEDA Library')#line:3360
            OOO00000OOO0O0O00 .snapeda_library_abs_dir =os .path .join (OOO00000OOO0O0O00 .kicad_library_dir ,'SnapEDA Library.pretty')#line:3362
            if not os .path .exists (OOO00000OOO0O0O00 .appdata_dir ):#line:3364
                os .makedirs (OOO00000OOO0O0O00 .appdata_dir )#line:3365
            if not os .path .exists (OOO00000OOO0O0O00 .kicad_library_dir ):#line:3366
                os .makedirs (OOO00000OOO0O0O00 .kicad_library_dir )#line:3367
            if not os .path .exists (OOO00000OOO0O0O00 .snapeda_library_dir ):#line:3368
                os .makedirs (OOO00000OOO0O0O00 .snapeda_library_dir )#line:3369
            if not os .path .exists (OOO00000OOO0O0O00 .snapeda_library_abs_dir ):#line:3370
                os .makedirs (OOO00000OOO0O0O00 .snapeda_library_abs_dir )#line:3371
        else :#line:3372
            OOO00000OOO0O0O00 .appdata_dir =os .path .join (OOO00000OOO0O0O00 .dir_path ,"assets")#line:3373
            OOO00000OOO0O0O00 .flip_table_dir =os .path .join (os .path .expanduser ("~"),'.config','kicad','fp-lib-table')#line:3377
            OOO00000OOO0O0O00 .kicad_common_dir =os .path .join (os .path .expanduser ("~"),'.config','kicad','kicad_common')#line:3381
            O0000O0OO0OOO000O =os .path .expanduser ("~")#line:3382
            OOO00000OOO0O0O00 .kicad_library_dir =os .path .join (O0000O0OO0OOO000O ,'KiCad Library')#line:3383
            OOO00000OOO0O0O00 .snapeda_library_dir =os .path .join (OOO00000OOO0O0O00 .kicad_library_dir ,'SnapEDA Library')#line:3385
            OOO00000OOO0O0O00 .snapeda_library_abs_dir =os .path .join (OOO00000OOO0O0O00 .kicad_library_dir ,'SnapEDA Library.pretty')#line:3387
            if not os .path .exists (OOO00000OOO0O0O00 .appdata_dir ):#line:3388
                os .makedirs (OOO00000OOO0O0O00 .appdata_dir )#line:3389
            if not os .path .exists (OOO00000OOO0O0O00 .kicad_library_dir ):#line:3390
                os .makedirs (OOO00000OOO0O0O00 .kicad_library_dir )#line:3391
            if not os .path .exists (OOO00000OOO0O0O00 .snapeda_library_dir ):#line:3392
                os .makedirs (OOO00000OOO0O0O00 .snapeda_library_dir )#line:3393
            if not os .path .exists (OOO00000OOO0O0O00 .snapeda_library_abs_dir ):#line:3394
                os .makedirs (OOO00000OOO0O0O00 .snapeda_library_abs_dir )#line:3395
        OOO00000OOO0O0O00 .login_bg_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"Group+292.png")#line:3397
        OOO00000OOO0O0O00 .username_bg_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"3xm843ff.png")#line:3398
        OOO00000OOO0O0O00 .password_bg_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"ek8owdjt.png")#line:3399
        OOO00000OOO0O0O00 .login_button_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"g4pik2y2.png")#line:3400
        OOO00000OOO0O0O00 .logo_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"lkeixquo.png")#line:3401
        OOO00000OOO0O0O00 .loading_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"jwhk6qck.gif")#line:3402
        OOO00000OOO0O0O00 .cover_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"RefDesign.png")#line:3403
        OOO00000OOO0O0O00 .symbol_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"Symbol.png")#line:3404
        OOO00000OOO0O0O00 .package_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"Footprint.png")#line:3406
        if not os .path .exists (OOO00000OOO0O0O00 .logo_image_dir ):#line:3407
            tkMessageBox .showwarning ("Installation","Installation is started, please click OK and wait for the complete."+"It may take a time, login screen will be opened when the installation is completed."+"After the installation is completed, you have to restart the plugin, Pcbnew and KiCad.")#line:3410
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/lkeixquo.png")#line:3411
        if not os .path .exists (OOO00000OOO0O0O00 .loading_image_dir ):#line:3413
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/jwhk6qck.gif")#line:3414
        if not os .path .exists (OOO00000OOO0O0O00 .cover_image_dir ):#line:3415
            OOO00000OOO0O0O00 .download_image ("https://s3.amazonaws.com/snapeda/ulp/RefDesign.png")#line:3417
        if not os .path .exists (OOO00000OOO0O0O00 .symbol_image_dir ):#line:3418
            OOO00000OOO0O0O00 .download_image ("https://s3.amazonaws.com/snapeda/ulp/Symbol.png")#line:3420
        if not os .path .exists (OOO00000OOO0O0O00 .package_image_dir ):#line:3421
            OOO00000OOO0O0O00 .download_image ("https://s3.amazonaws.com/snapeda/ulp/Footprint.png")#line:3423
        if not os .path .exists (OOO00000OOO0O0O00 .login_bg_image_dir ):#line:3424
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/Group+292.png")#line:3426
        if not os .path .exists (OOO00000OOO0O0O00 .username_bg_image_dir ):#line:3427
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/3xm843ff.png")#line:3429
        if not os .path .exists (OOO00000OOO0O0O00 .password_bg_image_dir ):#line:3430
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/ek8owdjt.png")#line:3432
        if not os .path .exists (OOO00000OOO0O0O00 .login_button_image_dir ):#line:3433
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/g4pik2y2.png")#line:3435
        OOO00000OOO0O0O00 .welcome_screen_001_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"Mask+Group.png")#line:3438
        OOO00000OOO0O0O00 .welcome_screen_002_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"icon1.bbe45f7648f7.png")#line:3439
        OOO00000OOO0O0O00 .welcome_screen_003_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"ico_deadlines.8ba69c3f942a.png")#line:3440
        OOO00000OOO0O0O00 .welcome_screen_004_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"icon2.924b03ebfccc.png")#line:3441
        OOO00000OOO0O0O00 .welcome_screen_005_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"powered+by+snapEDA.png")#line:3442
        OOO00000OOO0O0O00 .welcome_screen_006_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"snapeda-transparent.png")#line:3443
        OOO00000OOO0O0O00 .usb_type_c_button_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"usb+type+c.png")#line:3444
        OOO00000OOO0O0O00 .microcontroller_button_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"usb+microcontroller.png")#line:3445
        if not os .path .exists (OOO00000OOO0O0O00 .welcome_screen_001_dir ):#line:3447
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Designs+-+API/Mask+Group.png")#line:3449
        if not os .path .exists (OOO00000OOO0O0O00 .welcome_screen_002_dir ):#line:3450
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/icon1.bbe45f7648f7.png")#line:3452
        if not os .path .exists (OOO00000OOO0O0O00 .welcome_screen_003_dir ):#line:3453
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/ico_deadlines.8ba69c3f942a.png")#line:3455
        if not os .path .exists (OOO00000OOO0O0O00 .welcome_screen_004_dir ):#line:3456
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/icon2.924b03ebfccc.png")#line:3458
        if not os .path .exists (OOO00000OOO0O0O00 .welcome_screen_005_dir ):#line:3459
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Designs+-+API/powered+by+snapEDA.png")#line:3461
        if not os .path .exists (OOO00000OOO0O0O00 .welcome_screen_006_dir ):#line:3462
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/snapeda-transparent.png")#line:3464
        if not os .path .exists (OOO00000OOO0O0O00 .usb_type_c_button_dir ):#line:3465
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/usb+type+c.png")#line:3467
        if not os .path .exists (OOO00000OOO0O0O00 .microcontroller_button_dir ):#line:3468
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/usb+microcontroller.png")#line:3470
        OOO00000OOO0O0O00 .filter_button_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"neeo2s8g.png")#line:3472
        OOO00000OOO0O0O00 .settings_button_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"7svfoe57.png")#line:3473
        OOO00000OOO0O0O00 .about_button_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"2kdtezsl.png")#line:3474
        OOO00000OOO0O0O00 .passive_components_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"t3gwhnzh.png")#line:3475
        OOO00000OOO0O0O00 .all_button_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"dsyrvfl9.png")#line:3476
        OOO00000OOO0O0O00 .powered_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"orb6glbv.png")#line:3477
        OOO00000OOO0O0O00 .datasheet_button_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"oxfarxz8.png")#line:3478
        OOO00000OOO0O0O00 .datasheet_available_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"m4lamm2w.png")#line:3479
        OOO00000OOO0O0O00 .datasheet_not_available_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"4cnn9kkf.png")#line:3480
        OOO00000OOO0O0O00 .symbol_available_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"huaxvbtm.png")#line:3481
        OOO00000OOO0O0O00 .symbol_not_available_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"tmuhgmxh.png")#line:3482
        OOO00000OOO0O0O00 .footprint_available_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"3ruuehki.png")#line:3483
        OOO00000OOO0O0O00 .footprint_not_available_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"footprint_outline.cebd715affd8.png")#line:3484
        OOO00000OOO0O0O00 .available_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"uku4ceuv.png")#line:3485
        OOO00000OOO0O0O00 .not_available_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"zah3n8r4.png")#line:3486
        OOO00000OOO0O0O00 .prev_bg_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"iu2ma3jp.png")#line:3487
        OOO00000OOO0O0O00 .next_bg_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"witafnjf.png")#line:3488
        OOO00000OOO0O0O00 .selected_page_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"izif2qd8.png")#line:3489
        OOO00000OOO0O0O00 .download_button_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"download+orange.png")#line:3490
        OOO00000OOO0O0O00 .view_button_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"viewonsnapeda+white.png")#line:3491
        OOO00000OOO0O0O00 .search_button_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"4i2efbui.png")#line:3492
        OOO00000OOO0O0O00 .loading_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"jwhk6qck.gif")#line:3493
        OOO00000OOO0O0O00 .icon_bitmap_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"32x32.ico")#line:3494
        if not os .path .exists (OOO00000OOO0O0O00 .filter_button_image_dir ):#line:3495
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/neeo2s8g.png")#line:3496
        if not os .path .exists (OOO00000OOO0O0O00 .settings_button_image_dir ):#line:3497
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/7svfoe57.png")#line:3498
        if not os .path .exists (OOO00000OOO0O0O00 .about_button_image_dir ):#line:3499
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/2kdtezsl.png")#line:3500
        if not os .path .exists (OOO00000OOO0O0O00 .passive_components_image_dir ):#line:3501
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/t3gwhnzh.png")#line:3502
        if not os .path .exists (OOO00000OOO0O0O00 .all_button_image_dir ):#line:3503
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/dsyrvfl9.png")#line:3504
        if not os .path .exists (OOO00000OOO0O0O00 .powered_image_dir ):#line:3505
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/orb6glbv.png")#line:3506
        if not os .path .exists (OOO00000OOO0O0O00 .datasheet_button_dir ):#line:3507
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/oxfarxz8.png")#line:3508
        if not os .path .exists (OOO00000OOO0O0O00 .datasheet_available_dir ):#line:3509
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/m4lamm2w.png")#line:3510
        if not os .path .exists (OOO00000OOO0O0O00 .datasheet_not_available_dir ):#line:3511
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/4cnn9kkf.png")#line:3512
        if not os .path .exists (OOO00000OOO0O0O00 .symbol_available_dir ):#line:3513
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/huaxvbtm.png")#line:3514
        if not os .path .exists (OOO00000OOO0O0O00 .symbol_not_available_dir ):#line:3515
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/tmuhgmxh.png")#line:3516
        if not os .path .exists (OOO00000OOO0O0O00 .footprint_available_dir ):#line:3517
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/3ruuehki.png")#line:3518
        if not os .path .exists (OOO00000OOO0O0O00 .footprint_not_available_dir ):#line:3519
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/62r7iuz7.png")#line:3520
        if not os .path .exists (OOO00000OOO0O0O00 .available_dir ):#line:3521
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/uku4ceuv.png")#line:3522
        if not os .path .exists (OOO00000OOO0O0O00 .not_available_dir ):#line:3523
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/zah3n8r4.png")#line:3524
        if not os .path .exists (OOO00000OOO0O0O00 .prev_bg_dir ):#line:3525
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/iu2ma3jp.png")#line:3526
        if not os .path .exists (OOO00000OOO0O0O00 .next_bg_dir ):#line:3527
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/witafnjf.png")#line:3528
        if not os .path .exists (OOO00000OOO0O0O00 .selected_page_dir ):#line:3529
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/izif2qd8.png")#line:3530
        if not os .path .exists (OOO00000OOO0O0O00 .download_button_dir ):#line:3531
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/download+orange.png")#line:3532
        if not os .path .exists (OOO00000OOO0O0O00 .view_button_dir ):#line:3533
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/viewonsnapeda+white.png")#line:3534
        if not os .path .exists (OOO00000OOO0O0O00 .search_button_image_dir ):#line:3535
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/4i2efbui.png")#line:3536
        if not os .path .exists (OOO00000OOO0O0O00 .icon_bitmap_dir ):#line:3537
            OOO00000OOO0O0O00 .download_ico ("https://snapeda.s3.amazonaws.com/Kicadplugin/32x32.ico")#line:3538
        OOO00000OOO0O0O00 .avatar_image_dir =os .path .join (OOO00000OOO0O0O00 .appdata_dir ,"avatar1.png")#line:3540
        if not os .path .exists (OOO00000OOO0O0O00 .avatar_image_dir ):#line:3541
            OOO00000OOO0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/avatar1.png")#line:3542
        OOO00000OOO0O0O00 .parent .grid_columnconfigure (0 ,weight =1 )#line:3544
        print ('Login screen initialized.')#line:3555
        OOO00000OOO0O0O00 .initialize_user_interface ()#line:3556
    def download_ico (OO00OO00O0OOOO0OO ,OO00O00O00OOO0O00 ):#line:3558
        if sys .version_info [0 ]==3 :#line:3559
            urllib .request .urlretrieve (OO00O00O00OOO0O00 ,OO00OO00O0OOOO0OO .icon_bitmap_dir )#line:3560
        else :#line:3561
            urllib .urlretrieve (OO00O00O00OOO0O00 ,OO00OO00O0OOOO0OO .icon_bitmap_dir )#line:3562
    def download_image (O0OO00OOO0O0000O0 ,O000O00OOOO000000 ):#line:3564
        OO000000OOOOO00O0 =O000O00OOOO000000 [O000O00OOOO000000 .rfind ('/')+1 :]#line:3566
        OOOOO0000OOO0O00O =os .path .join (O0OO00OOO0O0000O0 .appdata_dir ,OO000000OOOOO00O0 )#line:3567
        O0OO0OOOO0000O00O =OOOOO0000OOO0O00O [:-3 ]+"png"#line:3568
        if OOOOO0000OOO0O00O [-3 :]=="gif"or OOOOO0000OOO0O00O [-3 :]=="GIF":#line:3569
            O0OO0OOOO0000O00O =OOOOO0000OOO0O00O #line:3570
        if not os .path .exists (O0OO0OOOO0000O00O )and not O0OO00OOO0O0000O0 .is_mac :#line:3571
            if O0OO00OOO0O0000O0 .is_windows :#line:3572
                OO00OOOO00OOO0O00 =os .path .join (os .path .dirname (__file__ ),"imagemagick","convert")#line:3573
                subprocess .check_call ([OO00OOOO00OOO0O00 ,O000O00OOOO000000 .replace ("https","http"),O0OO0OOOO0000O00O ],shell =True )#line:3574
            else :#line:3575
                subprocess .call ("convert "+O000O00OOOO000000 .replace ("https","http")+" "+O0OO0OOOO0000O00O ,shell =True )#line:3576
        if O0OO00OOO0O0000O0 .is_mac :#line:3577
            if not os .path .exists (O0OO0OOOO0000O00O ):#line:3578
                with open (OOOOO0000OOO0O00O ,"wb")as OOO00O0OO0O000OO0 :#line:3579
                    if sys .version_info [0 ]==3 :#line:3580
                        OOOOO000O0000O00O =urllib .request .urlopen (O000O00OOOO000000 ).read ()#line:3581
                    else :#line:3582
                        OOOOO000O0000O00O =urllib2 .urlopen (O000O00OOOO000000 ).read ()#line:3583
                    OOO00O0OO0O000OO0 .write (OOOOO000O0000O00O )#line:3584
                    OOO00O0OO0O000OO0 .close ()#line:3585
                    subprocess .check_call (["sips","-s","format","gif","%s"%OOOOO0000OOO0O00O ,"--out","%s"%O0OO0OOOO0000O00O ],shell =True )#line:3586
        return O0OO0OOOO0000O00O #line:3587
    def on_entry_click_username (OOOOO0OOOO00OOOO0 ,OOOOO000OO00000OO ):#line:3590
        if OOOOO0OOOO00OOOO0 .username_entry .get ()=="Username or Email":#line:3591
            OOOOO0OOOO00OOOO0 .username_entry .delete (0 ,"end")#line:3592
            OOOOO0OOOO00OOOO0 .username_entry .insert (0 ,'')#line:3593
            OOOOO0OOOO00OOOO0 .username_entry .config (fg ='black')#line:3594
    def on_focusout_username (O00O0O00000O0OOOO ,OOO00OO00OOO0O000 ):#line:3596
        if O00O0O00000O0OOOO .username_entry .get ()=='':#line:3597
            O00O0O00000O0OOOO .username_entry .insert (0 ,"Username or Email")#line:3598
            O00O0O00000O0OOOO .username_entry .config (fg ='black')#line:3599
    def on_entry_click_password (OO0OO00OOO0000OOO ,O00000O00OOOOOO00 ):#line:3601
        if OO0OO00OOO0000OOO .password_entry .get ()=='Password':#line:3602
            OO0OO00OOO0000OOO .password_entry .delete (0 ,"end")#line:3603
            OO0OO00OOO0000OOO .password_entry .insert (0 ,'')#line:3604
            OO0OO00OOO0000OOO .password_entry .config (fg ='black',show ="*")#line:3605
    def on_focusout_password (OOO0OOOO00OO00O0O ,OO0O0O0O000OO00OO ):#line:3607
        if OOO0OOOO00OO00O0O .password_entry .get ()=='':#line:3608
            OOO0OOOO00OO00O0O .password_entry .insert (0 ,'Password')#line:3609
            OOO0OOOO00OO00O0O .password_entry .config (fg ='black',show ="")#line:3610
    def check_login_thread (O000O000O0O0OOOO0 ,OOOOO0OO0O00O000O ):#line:3613
        O000O000O0O0OOOO0 .login_button .config (state ="disabled",text ="")#line:3614
        O000O000O0O0OOOO0 .login_thread =threading .Thread (target =O000O000O0O0OOOO0 .check_login )#line:3615
        O000O000O0O0OOOO0 .login_thread .start ()#line:3616
    def check_login (O00O0OO0O00O0OOO0 ):#line:3618
        O00O00000OOO0OOOO ={'User-Agent':"Kicad"}#line:3619
        O0OO00O00000OO000 ="https://www.snapeda.com/account/api-login/"#line:3620
        O0O0OOOOOO000OO0O ={'username':O00O0OO0O00O0OOO0 .username_entry .get (),'password':O00O0OO0O00O0OOO0 .password_entry .get (),'ref':"kicad-plugin",}#line:3625
        if sys .version_info [0 ]==3 :#line:3626
            OO00O0O000OOO00O0 =urllib .parse .urlencode (O0O0OOOOOO000OO0O ).encode ("utf-8")#line:3627
            OO00OOOO00000O0OO =urllib .request .Request (O0OO00O00000OO000 ,OO00O0O000OOO00O0 ,headers =O00O00000OOO0OOOO )#line:3628
            OOO000OO0OOOO00OO =urllib .request .urlopen (OO00OOOO00000O0OO ).read ()#line:3629
        else :#line:3630
            OO00O0O000OOO00O0 =urllib .urlencode (O0O0OOOOOO000OO0O )#line:3631
            OO00OOOO00000O0OO =urllib2 .Request (O0OO00O00000OO000 ,OO00O0O000OOO00O0 ,headers =O00O00000OOO0OOOO )#line:3632
            OOO000OO0OOOO00OO =urllib2 .urlopen (OO00OOOO00000O0OO ).read ()#line:3633
        O00O0OO0O00O0OOO0 .data =json .loads (OOO000OO0OOOO00OO )#line:3634
        if O00O0OO0O00O0OOO0 .data ["status"]=="logged_in":#line:3636
            if O00O0OO0O00O0OOO0 .is_windows or O00O0OO0O00O0OOO0 .is_mac :#line:3637
                O00OOO00OOOO0OOOO =os .path .join (O00O0OO0O00O0OOO0 .appdata_dir ,"info.json")#line:3639
                with open (O00OOO00OOOO0OOOO )as O00OOO0O00OO0OO0O :#line:3640
                    OO00O0O000OOO00O0 =json .load (O00OOO0O00OO0OO0O )#line:3641
                OO00O0O000OOO00O0 ['username']=O00O0OO0O00O0OOO0 .username_entry .get ()#line:3642
                with open (O00OOO00OOOO0OOOO ,'w')as O0OOO00OOO0000O00 :#line:3643
                    json .dump (OO00O0O000OOO00O0 ,O0OOO00OOO0000O00 )#line:3644
                with open (os .path .join (O00O0OO0O00O0OOO0 .appdata_dir ,".token"),"w")as OOO0OOOOO0OOOO0O0 :#line:3646
                    OOO0OOOOO0OOOO0O0 .write (O00O0OO0O00O0OOO0 .data ["token"])#line:3647
                    OOO0OOOOO0OOOO0O0 .close ()#line:3648
            else :#line:3649
                O00OOO00OOOO0OOOO =os .path .join (O00O0OO0O00O0OOO0 .appdata_dir ,"info.json")#line:3651
                with open (O00OOO00OOOO0OOOO )as O00OOO0O00OO0OO0O :#line:3652
                    OO00O0O000OOO00O0 =json .load (O00OOO0O00OO0OO0O )#line:3653
                OO00O0O000OOO00O0 ['username']=O00O0OO0O00O0OOO0 .username_entry .get ()#line:3654
                with open (O00OOO00OOOO0OOOO ,'w')as O0OOO00OOO0000O00 :#line:3655
                    json .dump (OO00O0O000OOO00O0 ,O0OOO00OOO0000O00 )#line:3656
                with open (os .path .join (O00O0OO0O00O0OOO0 .dir_path ,".token"),"w")as OOO0OOOOO0OOOO0O0 :#line:3658
                    OOO0OOOOO0OOOO0O0 .write (O00O0OO0O00O0OOO0 .data ["token"])#line:3659
                    OOO0OOOOO0OOOO0O0 .close ()#line:3660
            for O0OOOO0OOO0OO0O0O in range (5 ):#line:3662
                for OOO0OOOOOO00OOO00 in O00O0OO0O00O0OOO0 .parent .grid_slaves (row =O0OOOO0OOO0OO0O0O ,column =0 ):#line:3663
                    OOO0OOOOOO00OOO00 .destroy ()#line:3664
            WelcomeScreen (O00O0OO0O00O0OOO0 .parent )#line:3666
        else :#line:3667
            O00O0OO0O00O0OOO0 .label .config (text ="The username/email or password you specified are not correct.")#line:3668
            O00O0OO0O00O0OOO0 .login_button .config (state ="normal",text ="")#line:3669
    def resize (OO000000000O0O0O0 ,OOOO00O0OOO00000O ,OO0O00O00000OO00O ,O00OOO000000OO0OO ):#line:3671
        ""#line:3675
        if sys .version_info [0 ]==3 :#line:3676
            O0O00OOO0O0O0OO00 =OOOO00O0OOO00000O .width ()#line:3677
            O0OO0OOOOOOO00OOO =OOOO00O0OOO00000O .height ()#line:3678
            OOOOO0OO00OO000O0 =max (O0O00OOO0O0O0OO00 ,O0OO0OOOOOOO00OOO )#line:3679
            O0O0O0000OOO0OOO0 =max (OO0O00O00000OO00O ,O00OOO000000OO0OO )#line:3680
            if OOOOO0OO00OO000O0 >O0O0O0000OOO0OOO0 :#line:3681
                return OOOO00O0OOO00000O .subsample (int (OOOOO0OO00OO000O0 /O0O0O0000OOO0OOO0 ))#line:3682
            else :#line:3683
                return OOOO00O0OOO00000O .zoom (int (O0O0O0000OOO0OOO0 /OOOOO0OO00OO000O0 ))#line:3684
        else :#line:3685
            O0O00OOO0O0O0OO00 =OOOO00O0OOO00000O .width ()#line:3686
            O0OO0OOOOOOO00OOO =OOOO00O0OOO00000O .height ()#line:3687
            OOOOO0OO00OO000O0 =max (O0O00OOO0O0O0OO00 ,O0OO0OOOOOOO00OOO )#line:3688
            O0O0O0000OOO0OOO0 =max (OO0O00O00000OO00O ,O00OOO000000OO0OO )#line:3689
            if OOOOO0OO00OO000O0 >O0O0O0000OOO0OOO0 :#line:3690
                return OOOO00O0OOO00000O .subsample (OOOOO0OO00OO000O0 /O0O0O0000OOO0OOO0 )#line:3691
            else :#line:3692
                return OOOO00O0OOO00000O .zoom (O0O0O0000OOO0OOO0 /OOOOO0OO00OO000O0 )#line:3693
    def forgot_callback (O0OOO00O00000OO0O ,OOOOO00OOOO0OOO00 ):#line:3695
        webbrowser .open ("https://www.snapeda.com/account/password_reset/",new =2 )#line:3696
    def register_callback (OO0OO0O00O00OOOOO ,O0000OOOOO000OOO0 ):#line:3698
        webbrowser .open ("https://www.snapeda.com/account/signup/",new =2 )#line:3699
    def initialize_user_interface (OO000000OO0O0000O ):#line:3702
        if OO000000OO0O0000O .is_windows :#line:3703
            OO000000OO0O0000O .parent .iconbitmap (OO000000OO0O0000O .icon_bitmap_dir )#line:3704
        OO000000OO0O0000O .parent .title ("SnapEDA v"+OO000000OO0O0000O .parent .version )#line:3705
        OO000000OO0O0000O .login_frame =tk .Frame (OO000000OO0O0000O .parent ,bg ="white")#line:3706
        OO000000OO0O0000O .login_frame .grid (row =0 ,column =0 ,sticky ="NEWS")#line:3707
        O0O0O0O0OO0O00OO0 =tk .PhotoImage (file =os .path .join (OO000000OO0O0000O .login_bg_image_dir ))#line:3709
        OO000000OO0O0000O .login_bg_image =OO000000OO0O0000O .resize (O0O0O0O0OO0O00OO0 ,458 ,721 )#line:3710
        OO000000OO0O0000O .login_bg =tk .Label (OO000000OO0O0000O .login_frame ,image =OO000000OO0O0000O .login_bg_image ,bg ="white")#line:3711
        OO000000OO0O0000O .login_bg .grid (row =0 ,column =0 ,sticky ="NEWS",rowspan =6 ,columnspan =2 )#line:3712
        for O0OO00OOO0O0O0OO0 in range (6 ):#line:3713
            if O0OO00OOO0O0O0OO0 <2 :#line:3714
                OO000000OO0O0000O .login_frame .grid_columnconfigure (O0OO00OOO0O0O0OO0 ,weight =1 ,uniform ="foo")#line:3715
            OO000000OO0O0000O .login_frame .grid_rowconfigure (O0OO00OOO0O0O0OO0 ,weight =1 )#line:3716
        OO000000OO0O0000O .label =tk .Label (OO000000OO0O0000O .login_frame ,text ="",bg ="white")#line:3729
        OO000000OO0O0000O .label .grid (row =0 ,column =0 ,columnspan =2 ,sticky ="S",pady =(250 ,0 ))#line:3730
        OO000000OO0O0000O .userpass_frame =tk .Frame (OO000000OO0O0000O .login_frame ,bg ="white")#line:3732
        OO000000OO0O0000O .userpass_frame .grid (row =1 ,column =0 ,columnspan =2 )#line:3733
        OO0OO0OOOOOO00O00 =tk .PhotoImage (file =os .path .join (OO000000OO0O0000O .username_bg_image_dir ))#line:3735
        OO000000OO0O0000O .username_bg_image =OO000000OO0O0000O .resize (OO0OO0OOOOOO00O00 ,229 ,34 )#line:3736
        OO000000OO0O0000O .username_image =tk .Label (OO000000OO0O0000O .userpass_frame ,image =OO000000OO0O0000O .username_bg_image ,bg ="white")#line:3737
        OO000000OO0O0000O .username_image .grid (row =0 ,column =0 ,sticky ="W")#line:3738
        OO000000OO0O0000O .username_entry =tk .Entry (OO000000OO0O0000O .userpass_frame ,font =("Open Sans","10"),bg ="#C4C4C4",borderwidth =0 ,highlightthickness =0 )#line:3739
        OO000000OO0O0000O .username_entry .insert (0 ,"Username or Email")#line:3740
        OO000000OO0O0000O .username_entry .grid (row =0 ,column =0 ,padx =(5 ,0 ))#line:3741
        OO000000OO0O0000O .username_entry .bind ('<FocusIn>',OO000000OO0O0000O .on_entry_click_username )#line:3742
        OO000000OO0O0000O .username_entry .bind ('<FocusOut>',OO000000OO0O0000O .on_focusout_username )#line:3743
        OO000000OO0O0000O .username_entry .config (fg ='black')#line:3744
        O0OOO0000O00O0OOO =tk .PhotoImage (file =os .path .join (OO000000OO0O0000O .password_bg_image_dir ))#line:3747
        OO000000OO0O0000O .password_bg_image =OO000000OO0O0000O .resize (O0OOO0000O00O0OOO ,229 ,34 )#line:3748
        OO000000OO0O0000O .password_image =tk .Label (OO000000OO0O0000O .userpass_frame ,image =OO000000OO0O0000O .password_bg_image ,bg ="white")#line:3749
        OO000000OO0O0000O .password_image .grid (row =1 ,column =0 ,sticky ="W",pady =(20 ,0 ))#line:3750
        OO000000OO0O0000O .password_entry =tk .Entry (OO000000OO0O0000O .userpass_frame ,font =("Open Sans","10"),bg ="#C4C4C4",borderwidth =0 ,highlightthickness =0 )#line:3751
        OO000000OO0O0000O .password_entry .insert (0 ,"Password")#line:3752
        OO000000OO0O0000O .password_entry .grid (row =1 ,column =0 ,padx =(5 ,0 ),pady =(20 ,0 ))#line:3753
        OO000000OO0O0000O .password_entry .bind ('<FocusIn>',OO000000OO0O0000O .on_entry_click_password )#line:3754
        OO000000OO0O0000O .password_entry .bind ('<FocusOut>',OO000000OO0O0000O .on_focusout_password )#line:3755
        OO000000OO0O0000O .password_entry .config (fg ='black')#line:3756
        OO000000OO0O0000O .username_entry .bind ('<Return>',OO000000OO0O0000O .check_login_thread )#line:3759
        OO000000OO0O0000O .password_entry .bind ('<Return>',OO000000OO0O0000O .check_login_thread )#line:3760
        OO000000OO0O0000O .forgot_password =tk .Label (OO000000OO0O0000O .userpass_frame ,text ="Forgot Password?",fg ="#696969",cursor ="hand2",bg ="white")#line:3763
        OO000000OO0O0000O .forgot_password .grid (row =2 ,column =0 ,pady =(11 ,0 ))#line:3764
        OO000000OO0O0000O .forgot_password .bind ("<Button-1>",OO000000OO0O0000O .forgot_callback )#line:3765
        OO0OO00OOO0O0OO00 =tk .PhotoImage (file =os .path .join (OO000000OO0O0000O .login_button_image_dir ))#line:3768
        OO000000OO0O0000O .login_button_image =OO000000OO0O0000O .resize (OO0OO00OOO0O0OO00 ,173 ,42 )#line:3769
        OO000000OO0O0000O .login_button =tk .Label (OO000000OO0O0000O .login_frame ,text ="",cursor ="hand2",bg ="white",image =OO000000OO0O0000O .login_button_image )#line:3774
        OO000000OO0O0000O .login_button .grid (row =2 ,column =0 ,columnspan =2 ,pady =(15 ,4 ))#line:3775
        OO000000OO0O0000O .login_button .bind ("<Button-1>",OO000000OO0O0000O .check_login_thread )#line:3776
        OO000000OO0O0000O .register_frame =tk .Frame (OO000000OO0O0000O .login_frame ,bg ="white")#line:3778
        OO000000OO0O0000O .register_frame .grid (row =2 ,column =0 ,columnspan =2 ,sticky ="S")#line:3779
        OOO00OO0O0OO0OOO0 =tk .Label (OO000000OO0O0000O .register_frame ,bg ="white",fg ="#696969",text ="Don't have an account?",font =("Open Sans","8"))#line:3780
        OOO00OO0O0OO0OOO0 .grid (row =0 ,column =0 ,sticky ="N")#line:3781
        OO000000OO0O0000O .register_button =tk .Label (OO000000OO0O0000O .register_frame ,text ="Register",fg ="#FF761B",cursor ="hand2",bg ="white",font =("Open Sans","8","bold"))#line:3791
        OO000000OO0O0000O .register_button .grid (row =0 ,column =1 ,pady =(0 ,0 ),sticky ="N")#line:3792
        OO000000OO0O0000O .register_button .bind ("<Button-1>",OO000000OO0O0000O .register_callback )#line:3793
class InstallScreen (tk .Frame ):#line:3795
    ""#line:3801
    def __init__ (O0OOOO00000OOOOOO ,O0000O00000O00OOO ):#line:3803
        tk .Frame .__init__ (O0OOOO00000OOOOOO ,O0000O00000O00OOO )#line:3804
        O0OOOO00000OOOOOO .parent =O0000O00000O00OOO #line:3805
        O0OOOO00000OOOOOO .version =O0000O00000O00OOO .version #line:3806
        O0OOOO00000OOOOOO .parent .geometry (CONST_INSTALL_WINDOW_GEOMETRY )#line:3807
        O0OOOO00000OOOOOO .parent .minsize (width =CONST_INSTALL_WINDOW_WIDTH ,height =CONST_INSTALL_GEOMETRY_HEIGHT )#line:3808
        O0OOOO00000OOOOOO .parent .grid_columnconfigure (0 ,weight =1 )#line:3809
        O0OOOO00000OOOOOO .parent .grid_rowconfigure (0 ,weight =1 )#line:3810
        O0OOOO00000OOOOOO .initialize_user_interface ()#line:3811
    def image_return (O0O00O00OOOOO0O0O ,O00O0OO0OOOOOO000 ):#line:3813
        return O00O0OO0OOOOOO000 #line:3814
    def download_ico (O0OO0O0O00OO00000 ,O00OO00O00OOO0000 ):#line:3816
        if sys .version_info [0 ]==3 :#line:3817
            urllib .request .urlretrieve (O00OO00O00OOO0000 ,O0OO0O0O00OO00000 .icon_bitmap_dir )#line:3818
        else :#line:3819
            urllib .urlretrieve (O00OO00O00OOO0000 ,O0OO0O0O00OO00000 .icon_bitmap_dir )#line:3820
    def download_image (O0OOOO00OOOOO0O00 ,O0O00O0OO0O00000O ):#line:3822
        OOOO000OO000O0OOO =O0O00O0OO0O00000O [O0O00O0OO0O00000O .rfind ('/')+1 :]#line:3823
        OO0OO00OOOO000O00 =os .path .join (O0OOOO00OOOOO0O00 .appdata_dir ,OOOO000OO000O0OOO )#line:3824
        OOO0OO00OO00OOOO0 =OO0OO00OOOO000O00 [:-3 ]+"png"#line:3825
        O000OO0OO0O0000OO =threading .Timer (2 ,O0OOOO00OOOOO0O00 .image_return ,args =(OOO0OO00OO00OOOO0 ,))#line:3826
        O000OO0OO0O0000OO .start ()#line:3827
        if not os .path .exists (OOO0OO00OO00OOOO0 )and not O0OOOO00OOOOO0O00 .is_mac :#line:3828
            if O0OOOO00OOOOO0O00 .is_windows :#line:3829
                O00OO00O00OOO0OO0 =os .path .join (os .path .dirname (__file__ ),"imagemagick","convert")#line:3830
                subprocess .check_call ([O00OO00O00OOO0OO0 ,O0O00O0OO0O00000O .replace ("https","http"),OOO0OO00OO00OOOO0 ],shell =True )#line:3831
            else :#line:3832
                subprocess .call ("convert "+O0O00O0OO0O00000O .replace ("https","http")+" "+OOO0OO00OO00OOOO0 ,shell =True )#line:3833
        if O0OOOO00OOOOO0O00 .is_mac :#line:3834
            if not os .path .exists (OOO0OO00OO00OOOO0 ):#line:3835
                with open (OO0OO00OOOO000O00 ,"wb")as O000OO000000O0OOO :#line:3836
                    if sys .version_info [0 ]==3 :#line:3837
                        O0O000000O0OOOO00 =urllib .request .urlopen (O0O00O0OO0O00000O ).read ()#line:3838
                    else :#line:3839
                        O0O000000O0OOOO00 =urllib2 .urlopen (O0O00O0OO0O00000O ).read ()#line:3840
                    O000OO000000O0OOO .write (O0O000000O0OOOO00 )#line:3841
                    O000OO000000O0OOO .close ()#line:3842
                    subprocess .check_call (["sips","-s","format","gif","%s"%OO0OO00OOOO000O00 ,"--out","%s"%OOO0OO00OO00OOOO0 ],shell =True )#line:3843
        return OOO0OO00OO00OOOO0 #line:3844
    def setup_dirs (O00000000O0000O0O ):#line:3846
        ""#line:3849
        O00000000O0000O0O .dir_path =os .path .dirname (os .path .realpath (__file__ ))#line:3850
        O00000000O0000O0O .is_mac =platform .mac_ver ()[0 ]!=""#line:3851
        O00000000O0000O0O .is_windows =(os .name =='nt')#line:3852
        if O00000000O0000O0O .is_windows :#line:3853
            O00000000O0000O0O .windata_dir =os .path .join (os .getenv ('HOMEDRIVE'),os .getenv ('HOMEPATH'),"SnapEDA Kicad Plugin")#line:3856
            O00000000O0000O0O .appdata_dir =os .path .join (O00000000O0000O0O .windata_dir ,"App")#line:3857
            O00000000O0000O0O .flip_table_dir =os .path .join (os .getenv ('APPDATA'),'kicad','fp-lib-table')#line:3860
            O00000000O0000O0O .kicad_common_dir =os .path .join (os .getenv ('APPDATA'),'kicad','kicad_common')#line:3863
            O00000000O0000O0O .kicad_library_dir =os .path .join (O00000000O0000O0O .windata_dir ,'KiCad Library')#line:3864
            O00000000O0000O0O .snapeda_library_dir =os .path .join (O00000000O0000O0O .kicad_library_dir ,'SnapEDA Library')#line:3867
            O00000000O0000O0O .snapeda_library_abs_dir =os .path .join (O00000000O0000O0O .kicad_library_dir ,'SnapEDA Library.pretty')#line:3869
            O00000000O0000O0O .snapeda_threedee_models_dir =os .path .join (O00000000O0000O0O .kicad_library_dir ,'SnapEDA 3D Models')#line:3871
            if not os .path .exists (O00000000O0000O0O .windata_dir ):#line:3873
                os .makedirs (O00000000O0000O0O .windata_dir )#line:3874
            if not os .path .exists (O00000000O0000O0O .appdata_dir ):#line:3875
                os .makedirs (O00000000O0000O0O .appdata_dir )#line:3876
            if not os .path .exists (O00000000O0000O0O .kicad_library_dir ):#line:3877
                os .makedirs (O00000000O0000O0O .kicad_library_dir )#line:3878
            if not os .path .exists (O00000000O0000O0O .snapeda_library_dir ):#line:3879
                os .makedirs (O00000000O0000O0O .snapeda_library_dir )#line:3880
            if not os .path .exists (O00000000O0000O0O .snapeda_library_abs_dir ):#line:3881
                os .makedirs (O00000000O0000O0O .snapeda_library_abs_dir )#line:3882
            if not os .path .exists (O00000000O0000O0O .snapeda_threedee_models_dir ):#line:3883
                os .makedirs (O00000000O0000O0O .snapeda_threedee_models_dir )#line:3884
        elif O00000000O0000O0O .is_mac :#line:3885
            O00000000O0000O0O .macdata_dir =os .path .join (os .path .expanduser ("~"),"Documents","SnapEDA Kicad Plugin")#line:3886
            O00000000O0000O0O .appdata_dir =os .path .join (O00000000O0000O0O .macdata_dir ,"App")#line:3887
            O00000000O0000O0O .flip_table_dir =os .path .join (os .getenv ('HOME'),'library','preferences','kicad','fp-lib-table')#line:3888
            O00000000O0000O0O .kicad_common_dir =os .path .join (os .getenv ('HOME'),'library','preferences','kicad','kicad_common')#line:3889
            O00000000O0000O0O .kicad_library_dir =os .path .join (O00000000O0000O0O .macdata_dir ,'KiCad Library')#line:3890
            O00000000O0000O0O .snapeda_library_dir =os .path .join (O00000000O0000O0O .kicad_library_dir ,'SnapEDA Library')#line:3892
            O00000000O0000O0O .snapeda_library_abs_dir =os .path .join (O00000000O0000O0O .kicad_library_dir ,'SnapEDA Library.pretty')#line:3894
            O00000000O0000O0O .snapeda_threedee_models_dir =os .path .join (O00000000O0000O0O .kicad_library_dir ,'SnapEDA 3D Models')#line:3896
            if not os .path .exists (O00000000O0000O0O .appdata_dir ):#line:3898
                os .makedirs (O00000000O0000O0O .appdata_dir )#line:3899
            if not os .path .exists (O00000000O0000O0O .kicad_library_dir ):#line:3900
                os .makedirs (O00000000O0000O0O .kicad_library_dir )#line:3901
            if not os .path .exists (O00000000O0000O0O .snapeda_library_dir ):#line:3902
                os .makedirs (O00000000O0000O0O .snapeda_library_dir )#line:3903
            if not os .path .exists (O00000000O0000O0O .snapeda_library_abs_dir ):#line:3904
                os .makedirs (O00000000O0000O0O .snapeda_library_abs_dir )#line:3905
            if not os .path .exists (O00000000O0000O0O .snapeda_threedee_models_dir ):#line:3906
                os .makedirs (O00000000O0000O0O .snapeda_threedee_models_dir )#line:3907
        else :#line:3908
            O00000000O0000O0O .appdata_dir =os .path .join (O00000000O0000O0O .dir_path ,"assets")#line:3909
            O00000000O0000O0O .flip_table_dir =os .path .join (os .path .expanduser ("~"),'.config','kicad','fp-lib-table')#line:3913
            O00000000O0000O0O .kicad_common_dir =os .path .join (os .path .expanduser ("~"),'.config','kicad','kicad_common')#line:3917
            O0O00OOO00O000O0O =os .path .expanduser ("~")#line:3918
            O00000000O0000O0O .kicad_library_dir =os .path .join (O0O00OOO00O000O0O ,'KiCad Library')#line:3919
            O00000000O0000O0O .snapeda_library_dir =os .path .join (O00000000O0000O0O .kicad_library_dir ,'SnapEDA Library')#line:3921
            O00000000O0000O0O .snapeda_library_abs_dir =os .path .join (O00000000O0000O0O .kicad_library_dir ,'SnapEDA Library.pretty')#line:3923
            O00000000O0000O0O .snapeda_threedee_models_dir =os .path .join (O00000000O0000O0O .kicad_library_dir ,'SnapEDA 3D Models')#line:3925
            if not os .path .exists (O00000000O0000O0O .appdata_dir ):#line:3926
                os .makedirs (O00000000O0000O0O .appdata_dir )#line:3927
            if not os .path .exists (O00000000O0000O0O .kicad_library_dir ):#line:3928
                os .makedirs (O00000000O0000O0O .kicad_library_dir )#line:3929
            if not os .path .exists (O00000000O0000O0O .snapeda_library_dir ):#line:3930
                os .makedirs (O00000000O0000O0O .snapeda_library_dir )#line:3931
            if not os .path .exists (O00000000O0000O0O .snapeda_library_abs_dir ):#line:3932
                os .makedirs (O00000000O0000O0O .snapeda_library_abs_dir )#line:3933
            if not os .path .exists (O00000000O0000O0O .snapeda_threedee_models_dir ):#line:3934
                os .makedirs (O00000000O0000O0O .snapeda_threedee_models_dir )#line:3935
        OO00000O0OO0000O0 =os .path .join (O00000000O0000O0O .appdata_dir ,"info.json")#line:3938
        try :#line:3939
            with open (OO00000O0OO0000O0 )as OOO0OOOOOO0O000O0 :#line:3940
                OOO0OO0OOOOO00O0O =json .load (OOO0OOOOOO0O000O0 )#line:3941
            if not OOO0OO0OOOOO00O0O ['version']==O00000000O0000O0O .version :#line:3942
                OOO0OO0OOOOO00O0O ['version']=O00000000O0000O0O .version #line:3943
                OOO0OO0OOOOO00O0O ['kicad_library_dir']=O00000000O0000O0O .kicad_library_dir #line:3944
                OOO0OO0OOOOO00O0O ['kicad_library_name']='SnapEDA Library'#line:3945
                with open (OO00000O0OO0000O0 ,'w')as O00OO0OOO0O00000O :#line:3946
                    json .dump (OOO0OO0OOOOO00O0O ,O00OO0OOO0O00000O )#line:3947
                print ('Replacing new version...')#line:3948
                O00000000O0000O0O .is_installing =True #line:3949
        except :#line:3950
            OOO0OO0OOOOO00O0O ={}#line:3951
            OOO0OO0OOOOO00O0O ['version']=O00000000O0000O0O .version #line:3952
            OOO0OO0OOOOO00O0O ['kicad_library_dir']=O00000000O0000O0O .kicad_library_dir #line:3953
            OOO0OO0OOOOO00O0O ['kicad_library_name']='SnapEDA Library'#line:3954
            with open (OO00000O0OO0000O0 ,'w')as O00OO0OOO0O00000O :#line:3955
                json .dump (OOO0OO0OOOOO00O0O ,O00OO0OOO0O00000O )#line:3956
            print ('Installing new version...')#line:3957
            O00000000O0000O0O .is_installing =True #line:3958
        with open (O00000000O0000O0O .kicad_common_dir ,"r+")as O000O0OOO0OOOOOO0 :#line:3962
            OO0OOOOO00OOOOO00 =O000O0OOO0OOOOOO0 .read ()#line:3963
            if ("SNAPEDA_3D_MOD="+O00000000O0000O0O .snapeda_threedee_models_dir )not in OO0OOOOO00OOOOO00 :#line:3964
                O00OOO0OO00000O0O ='\nSNAPEDA_3D_MOD='+O00000000O0000O0O .snapeda_threedee_models_dir +'\n'#line:3965
                O00OOO0OO00000O0O =O00OOO0OO00000O0O .replace ("'","")#line:3966
                O000OO00OOOOOOO0O =OO0OOOOO00OOOOO00 [:-2 ]+O00OOO0OO00000O0O #line:3967
                O000O0OOO0OOOOOO0 .seek (0 )#line:3968
                O000O0OOO0OOOOOO0 .write (O000OO00OOOOOOO0O )#line:3969
                O000O0OOO0OOOOOO0 .truncate ()#line:3970
    def continue_installation_callback (O0OOOO00O00OOO0O0 ,O000OOO0O0O00OOO0 ):#line:3994
        for OOO0OOOO0O00OO00O in O0OOOO00O00OOO0O0 .parent .grid_slaves ():#line:3995
            OOO0OOOO0O00OO00O .destroy ()#line:3996
        LoginScreen (O0OOOO00O00OOO0O0 .parent )#line:3997
    def installation_process (OOO000OOO0O0O0O00 ):#line:3999
        try :#line:4001
            if OOO000OOO0O0O0O00 .is_windows or OOO000OOO0O0O0O00 .is_mac :#line:4002
                os .remove (os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'.token'))#line:4003
            else :#line:4004
                os .remove (os .path .join (OOO000OOO0O0O0O00 .dir_path ,".token"))#line:4005
        except :#line:4006
            pass #line:4007
        OOO000OOO0O0O0O00 .login_bg_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"Group+292.png")#line:4009
        OOO000OOO0O0O0O00 .username_bg_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"3xm843ff.png")#line:4010
        OOO000OOO0O0O0O00 .password_bg_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"ek8owdjt.png")#line:4011
        OOO000OOO0O0O0O00 .login_button_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"g4pik2y2.png")#line:4012
        OOO000OOO0O0O0O00 .logo_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"lkeixquo.png")#line:4013
        OOO000OOO0O0O0O00 .loading_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"jwhk6qck.gif")#line:4014
        OOO000OOO0O0O0O00 .cover_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"RefDesign.png")#line:4015
        OOO000OOO0O0O0O00 .symbol_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"Symbol.png")#line:4016
        OOO000OOO0O0O0O00 .package_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"Footprint.png")#line:4018
        if not os .path .exists (OOO000OOO0O0O0O00 .logo_image_dir ):#line:4019
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/lkeixquo.png")#line:4020
        if not os .path .exists (OOO000OOO0O0O0O00 .loading_image_dir ):#line:4022
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/jwhk6qck.gif")#line:4023
        if not os .path .exists (OOO000OOO0O0O0O00 .cover_image_dir ):#line:4024
            OOO000OOO0O0O0O00 .download_image ("https://s3.amazonaws.com/snapeda/ulp/RefDesign.png")#line:4026
        if not os .path .exists (OOO000OOO0O0O0O00 .symbol_image_dir ):#line:4027
            OOO000OOO0O0O0O00 .download_image ("https://s3.amazonaws.com/snapeda/ulp/Symbol.png")#line:4029
        if not os .path .exists (OOO000OOO0O0O0O00 .package_image_dir ):#line:4030
            OOO000OOO0O0O0O00 .download_image ("https://s3.amazonaws.com/snapeda/ulp/Footprint.png")#line:4032
        if not os .path .exists (OOO000OOO0O0O0O00 .login_bg_image_dir ):#line:4033
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/Group+292.png")#line:4035
        if not os .path .exists (OOO000OOO0O0O0O00 .username_bg_image_dir ):#line:4036
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/3xm843ff.png")#line:4038
        if not os .path .exists (OOO000OOO0O0O0O00 .password_bg_image_dir ):#line:4039
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/ek8owdjt.png")#line:4041
        if not os .path .exists (OOO000OOO0O0O0O00 .login_button_image_dir ):#line:4042
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/g4pik2y2.png")#line:4044
        OOO000OOO0O0O0O00 .welcome_screen_001_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"Mask+Group.png")#line:4047
        OOO000OOO0O0O0O00 .welcome_screen_002_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"icon1.bbe45f7648f7.png")#line:4048
        OOO000OOO0O0O0O00 .welcome_screen_003_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"ico_deadlines.8ba69c3f942a.png")#line:4049
        OOO000OOO0O0O0O00 .welcome_screen_004_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"icon2.924b03ebfccc.png")#line:4050
        OOO000OOO0O0O0O00 .welcome_screen_005_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"powered+by+snapEDA.png")#line:4051
        OOO000OOO0O0O0O00 .welcome_screen_006_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"snapeda-transparent.png")#line:4052
        OOO000OOO0O0O0O00 .usb_type_c_button_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"usb+type+c.png")#line:4053
        OOO000OOO0O0O0O00 .microcontroller_button_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"usb+microcontroller.png")#line:4054
        if not os .path .exists (OOO000OOO0O0O0O00 .welcome_screen_001_dir ):#line:4056
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Designs+-+API/Mask+Group.png")#line:4058
        if not os .path .exists (OOO000OOO0O0O0O00 .welcome_screen_002_dir ):#line:4059
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/icon1.bbe45f7648f7.png")#line:4061
        if not os .path .exists (OOO000OOO0O0O0O00 .welcome_screen_003_dir ):#line:4062
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/ico_deadlines.8ba69c3f942a.png")#line:4064
        if not os .path .exists (OOO000OOO0O0O0O00 .welcome_screen_004_dir ):#line:4065
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/icon2.924b03ebfccc.png")#line:4067
        if not os .path .exists (OOO000OOO0O0O0O00 .welcome_screen_005_dir ):#line:4068
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Designs+-+API/powered+by+snapEDA.png")#line:4070
        if not os .path .exists (OOO000OOO0O0O0O00 .welcome_screen_006_dir ):#line:4071
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/snapeda-transparent.png")#line:4073
        if not os .path .exists (OOO000OOO0O0O0O00 .usb_type_c_button_dir ):#line:4074
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/usb+type+c.png")#line:4076
        if not os .path .exists (OOO000OOO0O0O0O00 .microcontroller_button_dir ):#line:4077
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/usb+microcontroller.png")#line:4079
        OOO000OOO0O0O0O00 .filter_button_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"neeo2s8g.png")#line:4081
        OOO000OOO0O0O0O00 .settings_button_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"7svfoe57.png")#line:4082
        OOO000OOO0O0O0O00 .about_button_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"2kdtezsl.png")#line:4083
        OOO000OOO0O0O0O00 .passive_components_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"t3gwhnzh.png")#line:4084
        OOO000OOO0O0O0O00 .all_button_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"dsyrvfl9.png")#line:4085
        OOO000OOO0O0O0O00 .powered_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"orb6glbv.png")#line:4086
        OOO000OOO0O0O0O00 .datasheet_button_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"oxfarxz8.png")#line:4087
        OOO000OOO0O0O0O00 .datasheet_available_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"m4lamm2w.png")#line:4088
        OOO000OOO0O0O0O00 .datasheet_not_available_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"4cnn9kkf.png")#line:4089
        OOO000OOO0O0O0O00 .symbol_available_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"huaxvbtm.png")#line:4090
        OOO000OOO0O0O0O00 .symbol_not_available_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"tmuhgmxh.png")#line:4091
        OOO000OOO0O0O0O00 .footprint_available_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"3ruuehki.png")#line:4092
        OOO000OOO0O0O0O00 .footprint_not_available_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"footprint_outline.cebd715affd8.png")#line:4093
        OOO000OOO0O0O0O00 .available_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"uku4ceuv.png")#line:4094
        OOO000OOO0O0O0O00 .not_available_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"zah3n8r4.png")#line:4095
        OOO000OOO0O0O0O00 .prev_bg_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"iu2ma3jp.png")#line:4096
        OOO000OOO0O0O0O00 .next_bg_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"witafnjf.png")#line:4097
        OOO000OOO0O0O0O00 .selected_page_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"izif2qd8.png")#line:4098
        OOO000OOO0O0O0O00 .download_button_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"download+orange.png")#line:4099
        OOO000OOO0O0O0O00 .view_button_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"viewonsnapeda+white.png")#line:4100
        OOO000OOO0O0O0O00 .search_button_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"4i2efbui.png")#line:4101
        OOO000OOO0O0O0O00 .loading_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"jwhk6qck.gif")#line:4102
        OOO000OOO0O0O0O00 .icon_bitmap_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"32x32.ico")#line:4103
        if not os .path .exists (OOO000OOO0O0O0O00 .filter_button_image_dir ):#line:4104
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/neeo2s8g.png")#line:4105
        if not os .path .exists (OOO000OOO0O0O0O00 .settings_button_image_dir ):#line:4106
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/7svfoe57.png")#line:4107
        if not os .path .exists (OOO000OOO0O0O0O00 .about_button_image_dir ):#line:4108
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/2kdtezsl.png")#line:4109
        if not os .path .exists (OOO000OOO0O0O0O00 .passive_components_image_dir ):#line:4110
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/t3gwhnzh.png")#line:4111
        if not os .path .exists (OOO000OOO0O0O0O00 .all_button_image_dir ):#line:4112
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/dsyrvfl9.png")#line:4113
        if not os .path .exists (OOO000OOO0O0O0O00 .powered_image_dir ):#line:4114
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/orb6glbv.png")#line:4115
        if not os .path .exists (OOO000OOO0O0O0O00 .datasheet_button_dir ):#line:4116
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/oxfarxz8.png")#line:4117
        if not os .path .exists (OOO000OOO0O0O0O00 .datasheet_available_dir ):#line:4118
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/m4lamm2w.png")#line:4119
        if not os .path .exists (OOO000OOO0O0O0O00 .datasheet_not_available_dir ):#line:4120
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/4cnn9kkf.png")#line:4121
        if not os .path .exists (OOO000OOO0O0O0O00 .symbol_available_dir ):#line:4122
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/huaxvbtm.png")#line:4123
        if not os .path .exists (OOO000OOO0O0O0O00 .symbol_not_available_dir ):#line:4124
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/tmuhgmxh.png")#line:4125
        if not os .path .exists (OOO000OOO0O0O0O00 .footprint_available_dir ):#line:4126
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/3ruuehki.png")#line:4127
        if not os .path .exists (OOO000OOO0O0O0O00 .footprint_not_available_dir ):#line:4128
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/62r7iuz7.png")#line:4129
        if not os .path .exists (OOO000OOO0O0O0O00 .available_dir ):#line:4130
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/uku4ceuv.png")#line:4131
        if not os .path .exists (OOO000OOO0O0O0O00 .not_available_dir ):#line:4132
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/zah3n8r4.png")#line:4133
        if not os .path .exists (OOO000OOO0O0O0O00 .prev_bg_dir ):#line:4134
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/iu2ma3jp.png")#line:4135
        if not os .path .exists (OOO000OOO0O0O0O00 .next_bg_dir ):#line:4136
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/witafnjf.png")#line:4137
        if not os .path .exists (OOO000OOO0O0O0O00 .selected_page_dir ):#line:4138
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/izif2qd8.png")#line:4139
        if not os .path .exists (OOO000OOO0O0O0O00 .download_button_dir ):#line:4140
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/download+orange.png")#line:4141
        if not os .path .exists (OOO000OOO0O0O0O00 .view_button_dir ):#line:4142
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/viewonsnapeda+white.png")#line:4143
        if not os .path .exists (OOO000OOO0O0O0O00 .search_button_image_dir ):#line:4144
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/4i2efbui.png")#line:4145
        if not os .path .exists (OOO000OOO0O0O0O00 .icon_bitmap_dir ):#line:4146
            OOO000OOO0O0O0O00 .download_ico ("https://snapeda.s3.amazonaws.com/Kicadplugin/32x32.ico")#line:4147
        OOO000OOO0O0O0O00 .avatar_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"avatar1.png")#line:4149
        if not os .path .exists (OOO000OOO0O0O0O00 .avatar_image_dir ):#line:4150
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/avatar1.png")#line:4151
        OOO000OOO0O0O0O00 .home_menu_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'home_menu.png')#line:4153
        OOO000OOO0O0O0O00 .how_it_works_menu_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'how_it_works_menu.png')#line:4154
        OOO000OOO0O0O0O00 .info_menu_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'info_menu.png')#line:4155
        OOO000OOO0O0O0O00 .logout_menu_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'logout_menu.png')#line:4156
        OOO000OOO0O0O0O00 .settings_menu_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'settings_menu.png')#line:4157
        OOO000OOO0O0O0O00 .update_menu_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'update_menu.png')#line:4158
        OOO000OOO0O0O0O00 .info_label_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'info_button.png')#line:4159
        OOO000OOO0O0O0O00 .info_placeholder_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'info_placeholder.png')#line:4160
        OOO000OOO0O0O0O00 .ok_button_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'ok_button.png')#line:4161
        OOO000OOO0O0O0O00 .setting_placeholder_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'settings_placeholder.png')#line:4162
        OOO000OOO0O0O0O00 .settings_input_placeholder_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'settings_input_placeholder.png')#line:4163
        OOO000OOO0O0O0O00 .settings_label_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'settings_button.png')#line:4164
        OOO000OOO0O0O0O00 .save_button_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'save_button.png')#line:4165
        OOO000OOO0O0O0O00 .folder_label_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'folder_label.png')#line:4166
        OOO000OOO0O0O0O00 .not_available_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'not_available.png')#line:4167
        OOO000OOO0O0O0O00 .request_now_button_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'request_now_button.png')#line:4168
        OOO000OOO0O0O0O00 .talk_to_us_button_image_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'talk_to_us_button.png')#line:4169
        OOO000OOO0O0O0O00 .update_notif_button_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,'notif_update_menu+(2).png')#line:4170
        OOO000OOO0O0O0O00 .threedee_model_not_available_img_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"3d_model_not_available_img.png")#line:4171
        if not os .path .exists (OOO000OOO0O0O0O00 .talk_to_us_button_image_dir ):#line:4173
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/talk_to_us_button.png")#line:4174
        if not os .path .exists (OOO000OOO0O0O0O00 .update_menu_img_dir ):#line:4175
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/update_menu.png")#line:4176
        if not os .path .exists (OOO000OOO0O0O0O00 .setting_placeholder_img_dir ):#line:4177
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/settings_placeholder.png")#line:4178
        if not os .path .exists (OOO000OOO0O0O0O00 .how_it_works_menu_img_dir ):#line:4179
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/how_it_works_menu.png")#line:4180
        if not os .path .exists (OOO000OOO0O0O0O00 .home_menu_img_dir ):#line:4181
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/home_menu.png")#line:4182
        if not os .path .exists (OOO000OOO0O0O0O00 .settings_menu_img_dir ):#line:4183
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/settings_menu.png")#line:4184
        if not os .path .exists (OOO000OOO0O0O0O00 .settings_input_placeholder_dir ):#line:4185
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/settings_input_placeholder.png")#line:4186
        if not os .path .exists (OOO000OOO0O0O0O00 .settings_label_img_dir ):#line:4187
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/settings_button.png")#line:4188
        if not os .path .exists (OOO000OOO0O0O0O00 .save_button_img_dir ):#line:4189
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/save_button.png")#line:4190
        if not os .path .exists (OOO000OOO0O0O0O00 .ok_button_img_dir ):#line:4191
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/ok_button.png")#line:4192
        if not os .path .exists (OOO000OOO0O0O0O00 .logout_menu_img_dir ):#line:4193
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/logout_menu.png")#line:4194
        if not os .path .exists (OOO000OOO0O0O0O00 .info_placeholder_img_dir ):#line:4195
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/info_placeholder.png")#line:4196
        if not os .path .exists (OOO000OOO0O0O0O00 .info_menu_img_dir ):#line:4197
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/info_menu.png")#line:4198
        if not os .path .exists (OOO000OOO0O0O0O00 .info_label_img_dir ):#line:4199
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/info_button.png")#line:4200
        if not os .path .exists (OOO000OOO0O0O0O00 .folder_label_img_dir ):#line:4201
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/folder_label.png")#line:4202
        if not os .path .exists (OOO000OOO0O0O0O00 .not_available_img_dir ):#line:4203
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/not_available.png")#line:4204
        if not os .path .exists (OOO000OOO0O0O0O00 .request_now_button_img_dir ):#line:4205
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/request_now_button.png")#line:4206
        if not os .path .exists (OOO000OOO0O0O0O00 .update_notif_button_img_dir ):#line:4207
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/notif_update_menu+(2).png")#line:4208
        if not os .path .exists (OOO000OOO0O0O0O00 .threedee_model_not_available_img_dir ):#line:4209
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/3d_model_not_available_img.png")#line:4210
        OOO000OOO0O0O0O00 .threedee_available_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"threedee_model_available.png")#line:4212
        OOO000OOO0O0O0O00 .threedee_unavailable_dir =os .path .join (OOO000OOO0O0O0O00 .appdata_dir ,"threedee_model_unavailable.png")#line:4213
        if not os .path .exists (OOO000OOO0O0O0O00 .threedee_available_dir ):#line:4214
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/threedee_model_available.png")#line:4215
        if not os .path .exists (OOO000OOO0O0O0O00 .threedee_unavailable_dir ):#line:4216
            OOO000OOO0O0O0O00 .download_image ("https://snapeda.s3.amazonaws.com/Kicadplugin/threedee_model_unavailable.png")#line:4217
        OOO000OOO0O0O0O00 .instruction_header_label .set ("INSTALLATION COMPLETE")#line:4242
        OOO000OOO0O0O0O00 .install_frame .config (cursor ="hand2")#line:4243
        OOO000OOO0O0O0O00 .instruction_label .set ("Click screen to complete installation.\n Directing to login in screen in ")#line:4244
        OOO000OOO0O0O0O00 .install_frame .bind ("<Button-1>",OOO000OOO0O0O0O00 .continue_installation_callback )#line:4245
        for O0OOO00O0OO00OOO0 in range (5 ,0 ,-1 ):#line:4247
            tk .Label (OOO000OOO0O0O0O00 .install_frame ,text =O0OOO00O0OO00OOO0 ,fg ="white",bg ="#ff761a",font =("Open Sans","20","bold")).grid (row =2 ,column =0 ,sticky ="SEW")#line:4248
            time .sleep (1 )#line:4249
        for O0OOOO0OO0OOOOO00 in OOO000OOO0O0O0O00 .parent .grid_slaves ():#line:4251
            O0OOOO0OO0OOOOO00 .destroy ()#line:4252
        LoginScreen (OOO000OOO0O0O0O00 .parent )#line:4253
    def initialize_user_interface (OOO0OO0O0000000OO ):#line:4255
        OOO0OO0O0000000OO .is_installing =False #line:4256
        OOO0OO0O0000000OO .setup_dirs ()#line:4257
        if OOO0OO0O0000000OO .is_installing :#line:4259
            OOO0OO0O0000000OO .parent .title ("SnapEDA v"+OOO0OO0O0000000OO .parent .version )#line:4260
            OOO0OO0O0000000OO .parent .geometry (CONST_INSTALL_WINDOW_GEOMETRY )#line:4261
            OOO0OO0O0000000OO .parent .minsize (width =CONST_INSTALL_WINDOW_WIDTH ,height =CONST_INSTALL_GEOMETRY_HEIGHT )#line:4262
            O000OOOO0OO0OO00O ="#ff761a"#line:4263
            OOO0OO0O0000000OO .install_frame =tk .Frame (OOO0OO0O0000000OO .parent ,bg =O000OOOO0OO0OO00O )#line:4264
            for OOO00O0000OOO0OOO in range (6 ):#line:4265
                OOO0OO0O0000000OO .install_frame .grid_rowconfigure (OOO00O0000OOO0OOO ,weight =1 ,uniform ="foo")#line:4266
            OOO0OO0O0000000OO .install_frame .grid_columnconfigure (0 ,weight =1 )#line:4267
            OOO0OO0O0000000OO .install_frame .grid (row =0 ,column =0 ,sticky ="NEWS")#line:4268
            OOO0OO0O0000000OO .instruction_label =tk .StringVar ()#line:4269
            OOO0OO0O0000000OO .instruction_label .set ("Installation is starting.\nPlease wait for the installation to complete.")#line:4270
            OOO0OO0O0000000OO .instruction_header_label =tk .StringVar ()#line:4271
            OOO0OO0O0000000OO .instruction_header_label .set ("INSTALLING...")#line:4272
            OOO0OO0O0000000OO .install_title_label =tk .Label (OOO0OO0O0000000OO .install_frame ,textvariable =OOO0OO0O0000000OO .instruction_header_label ,fg ="white",bg =O000OOOO0OO0OO00O ,font =("Open Sans","18","bold"))#line:4273
            OOO0OO0O0000000OO .install_title_label .grid (row =1 ,column =0 ,sticky ="SEW")#line:4274
            OOO0OO0O0000000OO .install_instructions_label =tk .Label (OOO0OO0O0000000OO .install_frame ,textvariable =OOO0OO0O0000000OO .instruction_label ,fg ="white",bg =O000OOOO0OO0OO00O ,justify =tk .CENTER ,font =("Open Sans","13"))#line:4275
            OOO0OO0O0000000OO .install_instructions_label .grid (row =2 ,column =0 ,sticky ="NEW")#line:4276
            OOO0O00OO000OO0O0 =threading .Thread (target =OOO0OO0O0000000OO .installation_process )#line:4278
            OOO0O00OO000OO0O0 .start ()#line:4279
        else :#line:4280
            LoginScreen (OOO0OO0O0000000OO .parent )#line:4281
def boot_plugin ():#line:4283
    O00OOOOO00O00OO00 =tk .Tk ()#line:4284
    O00OOOOO00O00OO00 .geometry (CONST_DEFAULT_GEOMETRY )#line:4285
    O00OOOOO00O00OO00 .minsize (width =CONST_DEFAULT_WINDOW_WIDTH ,height =CONST_DEFAULT_GEOMETRY_HEIGHT )#line:4286
    O00OOOOO00O00OO00 .version =version #line:4287
    InstallScreen (O00OOOOO00O00OO00 )#line:4288
    tk .mainloop ()#line:4289
for_production =True #line:4291
version ='0.0.5.4'#line:4292
ssl ._create_default_https_context =ssl ._create_unverified_context #line:4293
try :#line:4295
    if sys .version_info [0 ]==3 :#line:4296
        request =urllib .request .urlopen ("https://snapeda.s3.amazonaws.com/Kicadplugin/kicad_snapeda_plugin.json")#line:4297
    else :#line:4298
        try :#line:4299
            request =urllib2 .urlopen ("https://snapeda.s3.amazonaws.com/Kicadplugin/kicad_snapeda_plugin.json")#line:4300
        except :#line:4301
            request =urllib2 .urlopen ("https://snapeda.s3.amazonaws.com/Kicadplugin/kicad_snapeda_plugin.json")#line:4302
    data =json .load (request )#line:4303
    print (data )#line:4304
    release_version =data ['current_version_release']#line:4305
    if version >=release_version :#line:4306
        IS_UPDATED =True #line:4307
    try :#line:4309
        if sys .argv [1 ]=='standalone':#line:4310
            for_production =False #line:4311
    except :#line:4312
        pass #line:4313
except :#line:4314
    pass #line:4315
if for_production :#line:4317
    import pcbnew #line:4318
    import wx #line:4319
    class SnapEDAPlugin (pcbnew .ActionPlugin ):#line:4321
        def defaults (OO0O000OO0OO000OO ):#line:4322
            OO0O000OO0OO000OO .name ="SnapEDA"#line:4323
            OO0O000OO0OO000OO .category ="SnapEDA Plugin"#line:4324
            OO0O000OO0OO000OO .description ="Design faster with SnapEDA. Download CAD models for millions of electronic components, including schematic symbols, PCB footprints, and 3D models."#line:4325
            OO0O000OO0OO000OO .show_toolbar_button =False #line:4326
        def Run (OOO0OO0O000O00O00 ):#line:4328
            OO0O000O0OO0O00O0 =threading .Thread (target =boot_plugin )#line:4331
            OO0O000O0OO0O00O0 .setDaemon (True )#line:4332
            OO0O000O0OO0O00O0 .start ()#line:4333
    SnapEDAPlugin ().register ()#line:4335
else :#line:4336
    boot_plugin ()